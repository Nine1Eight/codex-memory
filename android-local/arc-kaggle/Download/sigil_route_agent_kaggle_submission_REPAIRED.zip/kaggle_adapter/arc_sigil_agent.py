
from __future__ import annotations
import random
from dataclasses import dataclass
from typing import Any, Optional
import numpy as np
from sigil_route_agent.agent import SigilRouteAgent

try:
    from arcengine import GameAction
except Exception:
    GameAction = None

@dataclass
class ArcSigilConfig:
    max_plan_steps: int = 128
    contemplation_budget_tokens: int = 10000
    save_debug: bool = False
    safe_fallback: bool = True

class ArcSigilAgent:
    def __init__(self, config: Optional[ArcSigilConfig] = None):
        self.config = config or ArcSigilConfig()
        self.agent = SigilRouteAgent(
            contemplation_budget_tokens=self.config.contemplation_budget_tokens,
            max_plan_steps=self.config.max_plan_steps,
        )
        self.step_index = 0
        self.last_action_name = None

    def reset(self):
        self.agent.reset()
        self.step_index = 0
        self.last_action_name = None

    def act(self, obs: Any = None, env: Any = None):
        frame = self._extract_frame(obs, env)
        decision = self.agent.act_from_frame(frame, step_index=self.step_index, previous_action=self.last_action_name)
        action_name = str(decision.get("action", "WAIT")).upper()
        self.last_action_name = action_name
        self.step_index += 1
        return self._map_action(action_name, env)

    def _extract_frame(self, obs, env=None):
        candidates = []
        if obs is not None:
            if isinstance(obs, dict):
                candidates.extend(obs.get(k) for k in ("frame","image","rgb","pixels","observation") if k in obs)
            for attr in ("frame","image","rgb","pixels","observation"):
                if hasattr(obs, attr): candidates.append(getattr(obs, attr))
        if env is not None:
            for attr in ("frame","image","rgb","pixels","last_frame"):
                if hasattr(env, attr): candidates.append(getattr(env, attr))
            if hasattr(env, "render"):
                try: candidates.append(env.render())
                except Exception: pass
        for item in candidates:
            try:
                arr = np.asarray(item)
                if arr.ndim == 2: arr = np.stack([arr,arr,arr], axis=-1)
                if arr.ndim == 3 and arr.shape[-1] >= 3: return arr[..., :3].astype(np.uint8)
            except Exception:
                pass
        return None

    def _map_action(self, action_name: str, env=None):
        # If ARC's GameAction exists, map symbolic directions to generic actions.
        if GameAction is not None:
            mapping = {"UP":"ACTION1", "DOWN":"ACTION2", "LEFT":"ACTION3", "RIGHT":"ACTION4", "WAIT":"ACTION5", "ACT":"ACTION6"}
            target = mapping.get(action_name, "ACTION5")
            for method in ("from_name",):
                if hasattr(GameAction, method):
                    try: return getattr(GameAction, method)(target)
                    except Exception: pass
            if hasattr(GameAction, target):
                return getattr(GameAction, target)
        if env is not None and hasattr(env, "action_space"):
            try:
                actions = [a for a in list(env.action_space) if "RESET" not in str(a).upper()]
                if actions: return random.choice(actions)
            except Exception: pass
        return action_name
