
from __future__ import annotations
import os
from kaggle_adapter.arc_sigil_agent import ArcSigilAgent, ArcSigilConfig

try:
    import arc_agi
    from arc_agi import OperationMode
except Exception:
    arc_agi = None
    OperationMode = None

class KaggleSigilRouteAgent:
    def __init__(self):
        self.agent = ArcSigilAgent(ArcSigilConfig(
            max_plan_steps=int(os.getenv("SIGIL_MAX_PLAN_STEPS", "128")),
            contemplation_budget_tokens=int(os.getenv("SIGIL_REASONING_TOKENS", "10000")),
        ))
    def reset(self):
        self.agent.reset()
    def act(self, obs=None, env=None):
        return self.agent.act(obs, env)

def run_competition():
    if arc_agi is None:
        print("arc_agi not installed; running import smoke only.")
        return None
    mode = getattr(OperationMode, "COMPETITION", None) or getattr(OperationMode, "OFFLINE", None)
    arc = arc_agi.Arcade(operation_mode=mode)
    agent = KaggleSigilRouteAgent()
    games = ["ls20"]
    for game in games:
        try:
            env = arc.make(game)
            obs = None
            for _ in range(100):
                action = agent.act(obs, env)
                obs = env.step(action)
        except Exception as exc:
            print("game loop skipped/error:", repr(exc))
    try:
        return arc.get_scorecard()
    except Exception:
        return None

if __name__ == "__main__":
    print(run_competition())
