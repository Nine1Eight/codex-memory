
from __future__ import annotations
from pathlib import Path
from typing import Any, Tuple
import numpy as np
from PIL import Image
from .schema import GameObject, GameState, ObjectType

COLOR_MAP = {
    (40, 120, 255): (ObjectType.AGENT, "#2878ff"),
    (255, 0, 0): (ObjectType.AGENT, "#ff0000"),
    (0, 0, 0): (ObjectType.WALL, "#000000"),
    (250, 220, 40): (ObjectType.KEY, "#fadc28"),
    (255, 215, 0): (ObjectType.KEY, "#ffd700"),
    (220, 140, 35): (ObjectType.DOOR, "#dc8c23"),
    (60, 220, 90): (ObjectType.GOAL, "#3cdc5a"),
    (0, 255, 0): (ObjectType.GOAL, "#00ff00"),
}

def _nearest(rgb):
    best = None
    br = 10**9
    arr = np.array(rgb, dtype=np.int32)
    for k, v in COLOR_MAP.items():
        d = int(np.sum((arr - np.array(k, dtype=np.int32)) ** 2))
        if d < br:
            br = d
            best = v
    return best if br <= 5000 else (ObjectType.UNKNOWN, "#{:02x}{:02x}{:02x}".format(*[int(x) for x in rgb]))

class FrameGridExtractor:
    def __init__(self, cell_size: int = 20):
        self.cell_size = cell_size

    def extract_grid(self, frame_path: str) -> Tuple[np.ndarray, GameState]:
        img = Image.open(frame_path).convert("RGB")
        pixels = np.array(img)
        h_px, w_px, _ = pixels.shape
        gw = max(1, w_px // self.cell_size)
        gh = max(1, h_px // self.cell_size)
        grid = np.zeros((gh, gw, 3), dtype=np.uint8)
        objects = []
        for y in range(gh):
            for x in range(gw):
                # Use center pixel so small objects are not erased by background averaging.
                cx = min(w_px - 1, x * self.cell_size + self.cell_size // 2)
                cy = min(h_px - 1, y * self.cell_size + self.cell_size // 2)
                rgb = tuple(int(v) for v in pixels[cy, cx])
                grid[y, x] = rgb
                typ, color = _nearest(rgb)
                if typ != ObjectType.UNKNOWN:
                    props = {"locked": True} if typ == ObjectType.DOOR else {}
                    objects.append(GameObject(typ, color, (x, y), props))
        return grid, GameState(width=gw, height=gh, objects=objects)

    def extract(self, frame: Any = None, frame_id: int = 0, **kwargs) -> GameState:
        if isinstance(frame, (str, Path)):
            _, state = self.extract_grid(str(frame))
            state.frame_id = frame_id
            return state
        # Safe fallback synthetic state if ARC frame extraction is unavailable.
        w = int(kwargs.get("grid_width", 8)); h = int(kwargs.get("grid_height", 6))
        return GameState(width=w, height=h, objects=[
            GameObject(ObjectType.AGENT, "#2878ff", (1,1)),
            GameObject(ObjectType.GOAL, "#3cdc5a", (w-2,h-2)),
        ], frame_id=frame_id)
