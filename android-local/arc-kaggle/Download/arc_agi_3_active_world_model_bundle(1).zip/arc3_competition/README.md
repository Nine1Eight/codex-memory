# ARC-AGI-3 Active Object World Model scored run

This package contains a Kaggle competition notebook and the exact `MyAgent` source embedded in it.
The notebook uses the official hidden-rerun gateway contract, writes a canonical validation
`submission.parquet`, and lets the gateway write the real scored parquet during a competition rerun.

## Files

- `arc_agi_3_active_world_model_scored_run.ipynb` — upload or push this notebook to Kaggle.
- `agent.py` — exact source written to `/tmp/my_agent.py` and `/kaggle/working/agent.py` by the notebook.
- `kernel-metadata.json` — Kaggle CLI metadata that attaches the competition, vLLM wheelhouse, and
  Qwen 3.6 27B FP8 snapshot.

## Kaggle settings

- Accelerator: one H100 or RTX PRO 6000-class GPU is recommended for the attached 27B FP8 model.
- Internet: off.
- Competition: `arc-prize-2026-arc-agi-3`.
- Do not run the agent directly. Save a version, then submit that version so Kaggle triggers
  `KAGGLE_IS_COMPETITION_RERUN=1` and the official gateway.

## Logged trace phases

`LOAD`, `OBSERVE`, `OBJECTS`, `CANDIDATES`, `WORLD`, `GOAL`, `REASON`, `EXECUTE`, `RESULT`,
`REPLAN`, and `LEVEL` are printed for every environment. Logs record concise testable reasoning
summaries rather than hidden chain-of-thought.

## Architecture

The agent segments each settled frame into same-color four-connected components, hashes shapes,
tracks matched components across transitions, estimates which object is controllable, maintains
per-action change/risk/progress statistics, and ranks short move combinations. A local Qwen planner
selects among those validated candidates and updates compact world/goal hypotheses. Plans stop
immediately on a no-op, level boundary, `GAME_OVER`, or `WIN`, preventing queued actions from
crossing state boundaries.

Before any scored environment action, the notebook sends a schema-validation request to the local
chat-completions server. The agent accepts standard message content, content-part arrays, tool-call
arguments, text completions, and Responses-style output. An incompatible or empty response disables
model planning immediately and uses the deterministic heuristic path; transient transport failures
retain the bounded three-failure retry policy. A RESET-only action space is handled explicitly.

## Public-work synthesis used in this build

- Kaggle's score-sorted public code list showed a Qwen 3.6 Duck notebook at `1.33`, ahead of the
  public notebooks found at `1.22`, `0.86`, `0.84`, `0.81`, and `0.62` on 2026-08-16.
- Duck Harness contributed the local Qwen/vLLM, compact object representation, concurrent official
  runner, and short-context tool-agent pattern.
- Tycho contributed explicit competing world/goal hypotheses, transition verification, active
  abstraction, and plan invalidation when observations diverge.
- Prime Agent contributed programmatic frame inspection, component tracking, strict action-shape
  validation, bounded action batches, and immediate re-grounding at level/reset boundaries.
- OpenAI's ARC-AGI-3 harness study contributed persistent reasoning summaries and compacted memory
  instead of rolling away early evidence.

Public scores are evidence about those notebook versions, not a promised score for this new agent.
