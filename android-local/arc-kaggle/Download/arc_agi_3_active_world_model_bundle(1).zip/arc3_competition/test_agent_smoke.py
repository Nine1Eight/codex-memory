from __future__ import annotations

import importlib.util
import json
import sys
import types
from enum import Enum
from pathlib import Path

import numpy as np


class GameState(Enum):
    NOT_PLAYED = 0
    PLAYING = 1
    GAME_OVER = 2
    WIN = 3


class GameAction(Enum):
    RESET = 0
    ACTION1 = 1
    ACTION2 = 2
    ACTION3 = 3
    ACTION4 = 4
    ACTION5 = 5
    ACTION6 = 6
    ACTION7 = 7

    @classmethod
    def from_id(cls, value: int) -> "GameAction":
        return cls(value)

    @classmethod
    def from_name(cls, value: str) -> "GameAction":
        return cls[str(value)]


class FrameData:
    def __init__(self, grid: np.ndarray, state: GameState = GameState.PLAYING, levels: int = 0) -> None:
        self.frame = [grid.tolist()]
        self.state = state
        self.levels_completed = levels
        self.available_actions = [1, 2, 3, 4, 5, 6]


class Agent:
    def __init__(self, *args, **kwargs) -> None:
        self.game_id = kwargs.get("game_id", "fake")
        self.arc_env = kwargs.get("arc_env")
        self.action_counter = 0
        self.frames = []

    def append_frame(self, frame) -> None:
        self.frames.append(frame)

    def _convert_raw_frame_data(self, raw):
        return raw


class FakeEnvironment:
    def __init__(self, frame: FrameData) -> None:
        self.observation_space = frame
        self.action_space = [GameAction.ACTION1, GameAction.ACTION2, GameAction.ACTION3, GameAction.ACTION4, GameAction.ACTION5, GameAction.ACTION6]
        self.calls = []

    def step(self, action, data=None, reasoning=None):
        self.calls.append((action, dict(data or {}), dict(reasoning or {})))
        self.observation_space = FrameData(make_grid(9, 10))
        return self.observation_space


arcengine = types.ModuleType("arcengine")
arcengine.FrameData = FrameData
arcengine.GameAction = GameAction
arcengine.GameState = GameState
agents = types.ModuleType("agents")
agents_agent = types.ModuleType("agents.agent")
agents_agent.Agent = Agent
sys.modules["arcengine"] = arcengine
sys.modules["agents"] = agents
sys.modules["agents.agent"] = agents_agent

agent_path = Path(__file__).with_name("agent.py")
spec = importlib.util.spec_from_file_location("competition_agent", agent_path)
assert spec is not None and spec.loader is not None
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)


def make_grid(player_row: int, player_col: int) -> np.ndarray:
    grid = np.zeros((64, 64), dtype=np.int8)
    grid[player_row : player_row + 2, player_col : player_col + 2] = 9
    grid[40:43, 50:53] = 14
    grid[63, 4:45] = 11
    return grid


def main() -> None:
    before_frame = FrameData(make_grid(10, 10))
    after_frame = FrameData(make_grid(9, 10))
    before = module.analyze_frame(before_frame, 0)
    after = module.analyze_frame(after_frame, 1)
    assert before.background == 0
    assert len(before.components) == 3
    assert any(component.hud_like for component in before.components)

    world = module.GameWorldModel("fake")
    evidence = world.record_transition(before, after, module.ActionSpec("ACTION1"))
    assert evidence.changed_cells == 4
    assert evidence.moved
    assert world.role_votes
    player = world.player_component(after)
    assert player is not None and player.color == 9

    candidates = world.generate_candidates(
        after,
        {"RESET", "ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5", "ACTION6"},
    )
    assert candidates
    assert any(candidate.actions[0].name == "ACTION6" for candidate in candidates)
    assert all(len(candidate.actions) <= module.MAX_PLAN_LENGTH for candidate in candidates)

    planner = module.LocalModelPlanner("fake", world)
    planner.disabled = True
    decision = planner.choose(after, candidates, {"ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5", "ACTION6"})
    assert decision.selected
    assert decision.source == "heuristic"

    parsed = planner._parse_json('<think>private reasoning</think> {"selected_candidate": 0, "world_model": "m", "goal_model": "g", "reasoning_summary": "r"}')
    assert parsed["selected_candidate"] == 0

    reset_only = planner.choose(after, [], {"RESET"})
    assert reset_only.selected == (module.ActionSpec("RESET"),)

    standard_content = planner._extract_model_content(
        {"choices": [{"message": {"content": '{"selected_candidate": 0}'}}]}
    )
    assert json.loads(standard_content)["selected_candidate"] == 0
    tool_content = planner._extract_model_content(
        {
            "choices": [
                {
                    "message": {
                        "content": None,
                        "tool_calls": [
                            {"function": {"arguments": '{"selected_candidate": 0}'}}
                        ],
                    }
                }
            ]
        }
    )
    assert json.loads(tool_content)["selected_candidate"] == 0

    class InvalidSchemaResponse:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def read(self):
            return b'{}'

    protocol_planner = module.LocalModelPlanner("fake", world)
    original_urlopen = module.urllib.request.urlopen
    module.urllib.request.urlopen = lambda *args, **kwargs: InvalidSchemaResponse()
    try:
        protocol_decision = protocol_planner.choose(
            after,
            candidates,
            {"ACTION1", "ACTION2", "ACTION3", "ACTION4", "ACTION5", "ACTION6"},
        )
    finally:
        module.urllib.request.urlopen = original_urlopen
    assert protocol_decision.source == "heuristic"
    assert protocol_planner.disabled

    fake_env = FakeEnvironment(before_frame)
    competition_agent = module.MyAgent(game_id="fake", arc_env=fake_env, card_id="card", agent_name="myagent", ROOT_URL="http://gateway", record=False)
    competition_agent.planner.disabled = True
    chosen = competition_agent.choose_action([], before_frame)
    result = competition_agent.do_action_request(chosen)
    competition_agent.append_frame(result)
    assert fake_env.calls
    assert fake_env.calls[0][0].name.startswith("ACTION")
    assert "world_model" in fake_env.calls[0][2]
    print("agent smoke tests passed")


if __name__ == "__main__":
    main()
