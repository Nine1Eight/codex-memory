from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
AGENT_SOURCE = (ROOT / "agent.py").read_text(encoding="utf-8")
NOTEBOOK_PATH = ROOT / "arc_agi_3_active_world_model_scored_run.ipynb"


def markdown(source: str) -> dict:
    return {"cell_type": "markdown", "metadata": {}, "source": source.splitlines(keepends=True)}


def code(source: str) -> dict:
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": source.splitlines(keepends=True),
    }


cells = [
    markdown(
        """# Nine1Eight ARC-AGI-3 — Active Object World Model scored run

This is a **run-only competition notebook**. It does not train, replay known solutions, inspect
environment source, or fabricate a score. During Kaggle's hidden scoring rerun it:

1. starts an offline Qwen 3.6 27B FP8 model through vLLM;
2. writes and registers `MyAgent` with the official ARC-AGI-3 gateway runner;
3. loads every environment exactly once through the official `Swarm`;
4. logs environment loading, connected-object detection, world/goal hypotheses, ranked move
   combinations, the selected plan, each real move, and each observed transition;
5. lets the gateway produce the real `/kaggle/working/submission.parquet`.

The visible validation run writes only the required four-column gate parquet. The same notebook also
exports `/kaggle/working/agent.py` for inspection. The included Kaggle metadata attaches the competition,
Tufa Labs' public vLLM wheelhouse, and the public `vrfai/Qwen3.6-27B-FP8` snapshot.
"""
    ),
    markdown("## 1. Install the official offline ARC runtime"),
    code(
        """import os
import subprocess
import sys
from pathlib import Path

WORKING = Path('/kaggle/working')
WORKING.mkdir(parents=True, exist_ok=True)
COMP_ROOT = Path('/kaggle/input/competitions/arc-prize-2026-arc-agi-3')
ARC_WHEELS = COMP_ROOT / 'arc_agi_3_wheels'
TRUE_SUBMISSION = os.environ.get('KAGGLE_IS_COMPETITION_RERUN', '').strip().lower() in {'1', 'true'}

subprocess.check_call([
    sys.executable, '-m', 'pip', 'install', '--quiet', '--no-index',
    '--disable-pip-version-check', '--find-links', str(ARC_WHEELS),
    'arc-agi', 'python-dotenv',
])
print(f'[BOOT] competition_rerun={TRUE_SUBMISSION} arc_wheels={ARC_WHEELS}')
"""
    ),
    markdown("## 2. Write the complete competition agent"),
    code(
        "from pathlib import Path\n\n"
        + f"AGENT_SOURCE = {AGENT_SOURCE!r}\n"
        + "Path('/tmp/my_agent.py').write_text(AGENT_SOURCE, encoding='utf-8')\n"
        + "Path('/kaggle/working/agent.py').write_text(AGENT_SOURCE, encoding='utf-8')\n"
        + "compile(AGENT_SOURCE, '/tmp/my_agent.py', 'exec')\n"
        + "print(f'[AGENT] wrote /tmp/my_agent.py and /kaggle/working/agent.py ({len(AGENT_SOURCE.splitlines())} lines)')\n"
    ),
    markdown("## 3. Start the local reasoning model only for the hidden scored rerun"),
    code(
        r'''import json
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


def find_vllm_wheelhouse() -> Path:
    candidates = []
    for wheel in Path('/kaggle/input').rglob('vllm*.whl'):
        text = str(wheel.parent).lower()
        score = 0
        score += 10 if 'wheelhouse' in text else 0
        score += 5 if 'h100' in text or 'cuda' in text else 0
        candidates.append((score, wheel.parent))
    if not candidates:
        raise FileNotFoundError('No attached vLLM wheelhouse was found under /kaggle/input.')
    return max(candidates, key=lambda item: item[0])[1]


def model_score(path: Path, config: dict) -> int:
    text = (str(path) + ' ' + json.dumps(config)).lower()
    score = 0
    score += 80 if 'qwen3.6' in text else 0
    score += 50 if '27b' in text else 0
    score += 35 if 'fp8' in text else 0
    score += 10 if 'qwen' in text else 0
    score -= 100 if any(word in text for word in ('embedding', 'reranker', 'tokenizer-only')) else 0
    return score


def find_model_snapshot() -> Path:
    candidates = []
    for config_path in Path('/kaggle/input').rglob('config.json'):
        model_dir = config_path.parent
        if str(model_dir).startswith(str(COMP_ROOT)):
            continue
        has_weights = any(model_dir.glob('*.safetensors')) or any(model_dir.glob('*.bin'))
        has_index = any(model_dir.glob('*.index.json'))
        if not (has_weights or has_index):
            continue
        try:
            config = json.loads(config_path.read_text(encoding='utf-8'))
        except Exception:
            continue
        candidates.append((model_score(model_dir, config), model_dir))
    if not candidates:
        raise FileNotFoundError('No attached local language-model snapshot with weights was found.')
    score, path = max(candidates, key=lambda item: item[0])
    if score < 50:
        raise RuntimeError(f'Attached models do not include the expected Qwen 3.6 27B FP8 snapshot; best={path}.')
    return path


def wait_for_url(url: str, timeout_s: float, label: str) -> None:
    deadline = time.monotonic() + timeout_s
    last_error = ''
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=10) as response:
                if response.status < 500:
                    print(f'[{label}] ready: {url}', flush=True)
                    return
        except Exception as exc:
            last_error = f'{type(exc).__name__}: {exc}'
        time.sleep(5)
    raise RuntimeError(f'{label} did not become ready within {timeout_s:.0f}s: {last_error}')


def validate_chat_schema(url: str) -> None:
    payload = {
        'model': 'arc3-local',
        'messages': [
            {'role': 'system', 'content': 'Return only strict JSON.'},
            {'role': 'user', 'content': '{"selected_candidate":0}'},
        ],
        'temperature': 0,
        'max_tokens': 64,
        'stream': False,
    }
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'Authorization': 'Bearer arc3-local'},
        method='POST',
    )
    with urllib.request.urlopen(request, timeout=180) as response:
        raw_body = response.read().decode('utf-8')
    try:
        body = json.loads(raw_body)
        choices = body['choices']
        message = choices[0]['message']
    except (json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
        raise RuntimeError('Model endpoint is not chat-completions compatible.') from exc
    content = message.get('content') if isinstance(message, dict) else None
    tool_calls = message.get('tool_calls') if isinstance(message, dict) else None
    if not ((isinstance(content, str) and content.strip()) or (isinstance(tool_calls, list) and tool_calls)):
        raise RuntimeError('Model endpoint returned neither message content nor tool-call arguments.')
    print(f'[MODEL] chat schema validated: choices={len(choices)}', flush=True)


VLLM_PROCESS = None
MODEL_PROTOCOL_OK = False
if TRUE_SUBMISSION:
    try:
        import vllm  # noqa: F401
        print('[MODEL] vLLM is already installed')
    except Exception:
        wheelhouse = find_vllm_wheelhouse()
        print(f'[MODEL] installing vLLM from {wheelhouse}', flush=True)
        subprocess.check_call([
            sys.executable, '-m', 'pip', 'install', '--quiet', '--no-index',
            '--disable-pip-version-check', '--find-links', str(wheelhouse), 'vllm',
        ])

    model_path = find_model_snapshot()
    print(f'[MODEL] selected snapshot: {model_path}', flush=True)
    model_log = (WORKING / 'vllm.log').open('w', encoding='utf-8')
    server_env = os.environ.copy()
    server_env.update({
        'HF_HUB_OFFLINE': '1',
        'TRANSFORMERS_OFFLINE': '1',
        'TOKENIZERS_PARALLELISM': 'true',
        'VLLM_WORKER_MULTIPROC_METHOD': 'spawn',
    })
    command = [
        sys.executable, '-m', 'vllm.entrypoints.openai.api_server',
        '--model', str(model_path),
        '--served-model-name', 'arc3-local',
        '--host', '127.0.0.1',
        '--port', '1234',
        '--tensor-parallel-size', '1',
        '--dtype', 'auto',
        '--gpu-memory-utilization', '0.92',
        '--max-model-len', '32768',
        '--max-num-seqs', '16',
        '--enable-prefix-caching',
        '--trust-remote-code',
        '--generation-config', 'vllm',
    ]
    print('[MODEL] launching: ' + ' '.join(command), flush=True)
    VLLM_PROCESS = subprocess.Popen(command, stdout=model_log, stderr=subprocess.STDOUT, env=server_env)
    try:
        wait_for_url('http://127.0.0.1:1234/v1/models', 1200, 'MODEL')
    except Exception:
        model_log.flush()
        tail = (WORKING / 'vllm.log').read_text(encoding='utf-8', errors='replace').splitlines()[-120:]
        print('[MODEL] startup log tail:\n' + '\n'.join(tail), flush=True)
        raise
    try:
        validate_chat_schema('http://127.0.0.1:1234/v1/chat/completions')
        MODEL_PROTOCOL_OK = True
    except Exception as exc:
        print(
            f'[MODEL] preflight failed; disabling model planner before environment actions: '
            f'{type(exc).__name__}: {exc}',
            flush=True,
        )
else:
    print('[MODEL] validation mode: model startup intentionally skipped')
'''
    ),
    markdown("## 4. Run through the official Kaggle gateway and validate the artifact"),
    code(
        r'''import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import pandas as pd


def wait_for_gateway(timeout_s: float = 600.0) -> None:
    deadline = time.monotonic() + timeout_s
    last_error = ''
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen('http://gateway:8001/api/games', timeout=10) as response:
                if response.status < 500:
                    games = json.loads(response.read().decode('utf-8'))
                    print(f'[GATEWAY] ready; environments={len(games)}', flush=True)
                    return
        except Exception as exc:
            last_error = f'{type(exc).__name__}: {exc}'
        time.sleep(5)
    raise RuntimeError(f'Kaggle gateway did not become ready: {last_error}')


SUBMISSION_PATH = WORKING / 'submission.parquet'
if TRUE_SUBMISSION:
    source_repo = COMP_ROOT / 'ARC-AGI-3-Agents'
    runtime_repo = WORKING / 'ARC-AGI-3-Agents'
    wait_for_gateway()
    if runtime_repo.exists():
        shutil.rmtree(runtime_repo)
    shutil.copytree(source_repo, runtime_repo)
    shutil.copy2('/tmp/my_agent.py', runtime_repo / 'agents/templates/my_agent.py')

    registry_source = """from typing import Type
from dotenv import load_dotenv
from .agent import Agent, Playback
from .swarm import Swarm
from .templates.random_agent import Random
from .templates.my_agent import MyAgent

load_dotenv()

AVAILABLE_AGENTS: dict[str, Type[Agent]] = {
    "random": Random,
    "myagent": MyAgent,
}

__all__ = ["Agent", "Playback", "Swarm", "Random", "MyAgent", "AVAILABLE_AGENTS"]
"""
    (runtime_repo / 'agents/__init__.py').write_text(registry_source, encoding='utf-8')
    (runtime_repo / '.env').write_text(
        'SCHEME=http\n'
        'HOST=gateway\n'
        'PORT=8001\n'
        'ARC_API_KEY=test-key-123\n'
        'ARC_BASE_URL=http://gateway:8001/\n'
        'OPERATION_MODE=online\n'
        'ENVIRONMENTS_DIR=\n'
        'RECORDINGS_DIR=/kaggle/working/server_recording\n',
        encoding='utf-8',
    )
    run_env = os.environ.copy()
    run_env.update({
        'ARC3_MODEL_ENDPOINT': 'http://127.0.0.1:1234/v1/chat/completions',
        'ARC3_MODEL_NAME': 'arc3-local',
        'ARC3_MODEL_CONCURRENCY': '12',
        'ARC3_MODEL_TIMEOUT_S': '240',
        'ARC3_DISABLE_MODEL': '0' if MODEL_PROTOCOL_OK else '1',
        'ARC3_MAX_ACTIONS': '320',
        'ARC3_MAX_PLAN_LENGTH': '8',
        'PYTHONUNBUFFERED': '1',
    })
    print('[RUN] starting official main.py --agent myagent; detailed traces follow', flush=True)
    try:
        subprocess.run(
            [sys.executable, 'main.py', '--agent', 'myagent'],
            cwd=runtime_repo,
            env=run_env,
            check=True,
        )
    finally:
        if VLLM_PROCESS is not None and VLLM_PROCESS.poll() is None:
            VLLM_PROCESS.terminate()
            try:
                VLLM_PROCESS.wait(timeout=30)
            except subprocess.TimeoutExpired:
                VLLM_PROCESS.kill()
else:
    pd.DataFrame(
        data=[['1_0', '1', True, 1]],
        columns=['row_id', 'game_id', 'end_of_game', 'score'],
    ).to_parquet(SUBMISSION_PATH, index=False)
    print('[RUN] validation mode: wrote canonical gate parquet; no game or training run was executed')

if not SUBMISSION_PATH.is_file():
    raise FileNotFoundError(f'Required artifact was not produced: {SUBMISSION_PATH}')
submission = pd.read_parquet(SUBMISSION_PATH)
required_columns = ['row_id', 'game_id', 'end_of_game', 'score']
if list(submission.columns) != required_columns:
    raise ValueError(f'Wrong submission schema: {list(submission.columns)} != {required_columns}')
if submission.empty:
    raise ValueError('submission.parquet is empty')
print(f'[ARTIFACT] {SUBMISSION_PATH} rows={len(submission)} bytes={SUBMISSION_PATH.stat().st_size}')
print(submission.head(20).to_string(index=False))
'''
    ),
]

notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.12"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

NOTEBOOK_PATH.write_text(json.dumps(notebook, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
print(NOTEBOOK_PATH)
