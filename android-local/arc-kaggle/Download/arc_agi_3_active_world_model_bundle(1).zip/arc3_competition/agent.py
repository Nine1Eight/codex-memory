from __future__ import annotations

import hashlib
import json
import os
import re
import statistics
import threading
import time
import urllib.request
from collections import Counter, deque
from dataclasses import dataclass, field
from itertools import product
from typing import Any, Iterable, Optional

import numpy as np
from arcengine import FrameData, GameAction, GameState

from agents.agent import Agent


PRINT_LOCK = threading.Lock()
MODEL_SEMAPHORE = threading.BoundedSemaphore(
    max(1, int(os.environ.get("ARC3_MODEL_CONCURRENCY", "12")))
)
MODEL_ENDPOINT = os.environ.get(
    "ARC3_MODEL_ENDPOINT", "http://127.0.0.1:1234/v1/chat/completions"
)
MODEL_NAME = os.environ.get("ARC3_MODEL_NAME", "arc3-local")
MODEL_TIMEOUT_S = float(os.environ.get("ARC3_MODEL_TIMEOUT_S", "240"))
MAX_PLAN_LENGTH = max(1, int(os.environ.get("ARC3_MAX_PLAN_LENGTH", "8")))

ACTION_ALIASES = {
    "UP": "ACTION1",
    "DOWN": "ACTION2",
    "LEFT": "ACTION3",
    "RIGHT": "ACTION4",
    "SPACE": "ACTION5",
    "INTERACT": "ACTION5",
    "CLICK": "ACTION6",
    "MOUSE": "ACTION6",
    "UNDO": "ACTION7",
    "RESET": "RESET",
}
DIRECTION_DELTA = {
    "ACTION1": (-1, 0),
    "ACTION2": (1, 0),
    "ACTION3": (0, -1),
    "ACTION4": (0, 1),
}
INVERSE_ACTION = {
    "ACTION1": "ACTION2",
    "ACTION2": "ACTION1",
    "ACTION3": "ACTION4",
    "ACTION4": "ACTION3",
}
COLOR_SYMBOLS = "0123456789ABCDEF"


def log(game_id: str, phase: str, message: str) -> None:
    stamp = time.strftime("%H:%M:%S")
    with PRINT_LOCK:
        print(f"[{stamp}][ARC3][{game_id}][{phase}] {message}", flush=True)


def clip_text(value: Any, limit: int = 600) -> str:
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    return text[:limit].rstrip() + f" ...[{len(text) - limit} chars omitted]"


def normalize_action_name(value: Any) -> str:
    name = getattr(value, "name", value)
    name = str(name or "").strip().upper()
    return ACTION_ALIASES.get(name, name)


def grid_from_frame(frame: FrameData | Any) -> np.ndarray:
    frames = getattr(frame, "frame", None)
    if frames is None or len(frames) == 0:
        return np.zeros((64, 64), dtype=np.int8)
    grid = np.asarray(frames[-1], dtype=np.int8)
    if grid.ndim != 2:
        return np.zeros((64, 64), dtype=np.int8)
    return grid


def grid_signature(grid: np.ndarray) -> str:
    return hashlib.blake2s(grid.tobytes(), digest_size=8).hexdigest()


@dataclass(frozen=True)
class ActionSpec:
    name: str
    x: Optional[int] = None
    y: Optional[int] = None

    def __post_init__(self) -> None:
        normalized = normalize_action_name(self.name)
        object.__setattr__(self, "name", normalized)
        if normalized == "ACTION6":
            if self.x is None or self.y is None:
                raise ValueError("ACTION6 requires x and y")
            object.__setattr__(self, "x", max(0, min(63, int(self.x))))
            object.__setattr__(self, "y", max(0, min(63, int(self.y))))
        else:
            object.__setattr__(self, "x", None)
            object.__setattr__(self, "y", None)

    @property
    def key(self) -> str:
        if self.name == "ACTION6":
            return f"ACTION6({self.x},{self.y})"
        return self.name

    @property
    def data(self) -> dict[str, int]:
        if self.name == "ACTION6":
            return {"x": int(self.x), "y": int(self.y)}
        return {}

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"action": self.name}
        if self.name == "ACTION6":
            result.update(self.data)
        return result


@dataclass(frozen=True)
class Component:
    object_id: int
    color: int
    pixels: int
    top: int
    left: int
    bottom: int
    right: int
    row: float
    col: float
    shape_hash: str
    touches_edge: bool
    hud_like: bool

    @property
    def height(self) -> int:
        return self.bottom - self.top + 1

    @property
    def width(self) -> int:
        return self.right - self.left + 1

    @property
    def role_key(self) -> str:
        return f"c{self.color}:{self.shape_hash}"

    def compact(self) -> str:
        flags = []
        if self.touches_edge:
            flags.append("edge")
        if self.hud_like:
            flags.append("hud")
        suffix = f"/{','.join(flags)}" if flags else ""
        return (
            f"o{self.object_id}:c{self.color} n={self.pixels} "
            f"box=({self.top},{self.left})-({self.bottom},{self.right}) "
            f"ctr=({self.row:.1f},{self.col:.1f}) sh={self.shape_hash}{suffix}"
        )


@dataclass(frozen=True)
class FrameView:
    step: int
    level: int
    state_name: str
    grid: np.ndarray
    signature: str
    background: int
    color_counts: dict[int, int]
    components: tuple[Component, ...]

    def component_by_role(self, role_key: str) -> Optional[Component]:
        matches = [component for component in self.components if component.role_key == role_key]
        if not matches:
            return None
        return min(matches, key=lambda component: (component.hud_like, component.pixels))


@dataclass
class ActionStats:
    attempts: int = 0
    changes: int = 0
    noops: int = 0
    game_overs: int = 0
    level_completions: int = 0
    changed_cells_total: int = 0
    displacements: list[tuple[int, int]] = field(default_factory=list)

    @property
    def change_rate(self) -> float:
        return (self.changes + 1.0) / (self.attempts + 2.0)

    @property
    def risk_rate(self) -> float:
        return (self.game_overs + 0.2) / (self.attempts + 2.0)

    @property
    def progress_rate(self) -> float:
        return (self.level_completions + 0.1) / (self.attempts + 4.0)


@dataclass(frozen=True)
class TransitionEvidence:
    step: int
    action: ActionSpec
    before_sig: str
    after_sig: str
    changed_cells: int
    changed_bbox: Optional[tuple[int, int, int, int]]
    color_delta: tuple[str, ...]
    moved: tuple[str, ...]
    level_before: int
    level_after: int
    state_after: str

    @property
    def level_completed(self) -> bool:
        return self.level_after > self.level_before

    def compact(self) -> str:
        moved = ",".join(self.moved[:4]) if self.moved else "none"
        bbox = str(self.changed_bbox) if self.changed_bbox is not None else "none"
        delta = ",".join(self.color_delta) if self.color_delta else "none"
        return (
            f"t{self.step} {self.action.key} changed={self.changed_cells} "
            f"bbox={bbox} colors={delta} moved={moved} level={self.level_before}->{self.level_after} "
            f"state={self.state_after}"
        )


@dataclass(frozen=True)
class ComboCandidate:
    actions: tuple[ActionSpec, ...]
    score: float
    rationale: str

    @property
    def key(self) -> str:
        return ">".join(action.key for action in self.actions)

    def compact(self) -> str:
        return f"{self.key} score={self.score:.3f} because {self.rationale}"


@dataclass(frozen=True)
class ModelDecision:
    selected: tuple[ActionSpec, ...]
    world_model: str
    goal_model: str
    reasoning_summary: str
    source: str


def analyze_frame(frame: FrameData | Any, step: int) -> FrameView:
    grid = grid_from_frame(frame)
    values, counts = np.unique(grid, return_counts=True)
    color_counts = {int(value): int(count) for value, count in zip(values, counts, strict=True)}
    background = max(color_counts, key=color_counts.get) if color_counts else 0
    rows, cols = grid.shape
    visited = np.zeros(grid.shape, dtype=np.bool_)
    components: list[Component] = []

    for start_row in range(rows):
        for start_col in range(cols):
            if visited[start_row, start_col] or int(grid[start_row, start_col]) == background:
                continue
            color = int(grid[start_row, start_col])
            stack = [(start_row, start_col)]
            visited[start_row, start_col] = True
            cells: list[tuple[int, int]] = []
            while stack:
                row, col = stack.pop()
                cells.append((row, col))
                for next_row, next_col in (
                    (row - 1, col),
                    (row + 1, col),
                    (row, col - 1),
                    (row, col + 1),
                ):
                    if not (0 <= next_row < rows and 0 <= next_col < cols):
                        continue
                    if visited[next_row, next_col] or int(grid[next_row, next_col]) != color:
                        continue
                    visited[next_row, next_col] = True
                    stack.append((next_row, next_col))

            cell_rows = [cell[0] for cell in cells]
            cell_cols = [cell[1] for cell in cells]
            top, bottom = min(cell_rows), max(cell_rows)
            left, right = min(cell_cols), max(cell_cols)
            normalized = sorted((row - top, col - left) for row, col in cells)
            shape_bytes = json.dumps(normalized, separators=(",", ":")).encode("ascii")
            shape_hash = hashlib.blake2s(shape_bytes, digest_size=4).hexdigest()
            touches_edge = top == 0 or left == 0 or bottom == rows - 1 or right == cols - 1
            height = bottom - top + 1
            width = right - left + 1
            long_thin = (height <= 2 and width >= max(8, cols // 3)) or (
                width <= 2 and height >= max(8, rows // 3)
            )
            hud_like = touches_edge and long_thin
            components.append(
                Component(
                    object_id=len(components),
                    color=color,
                    pixels=len(cells),
                    top=top,
                    left=left,
                    bottom=bottom,
                    right=right,
                    row=float(sum(cell_rows)) / len(cells),
                    col=float(sum(cell_cols)) / len(cells),
                    shape_hash=shape_hash,
                    touches_edge=touches_edge,
                    hud_like=hud_like,
                )
            )

    state_name = normalize_action_name(getattr(getattr(frame, "state", None), "name", "UNKNOWN"))
    level = int(getattr(frame, "levels_completed", 0) or 0)
    return FrameView(
        step=step,
        level=level,
        state_name=state_name,
        grid=grid,
        signature=grid_signature(grid),
        background=background,
        color_counts=color_counts,
        components=tuple(components),
    )


def match_component_motion(before: FrameView, after: FrameView) -> list[tuple[Component, Component, int, int]]:
    result: list[tuple[Component, Component, int, int]] = []
    used: set[int] = set()
    for old in before.components:
        candidates = [
            new
            for new in after.components
            if new.object_id not in used
            and new.color == old.color
            and new.shape_hash == old.shape_hash
        ]
        if not candidates:
            continue
        new = min(candidates, key=lambda item: abs(item.row - old.row) + abs(item.col - old.col))
        used.add(new.object_id)
        delta_row = int(round(new.row - old.row))
        delta_col = int(round(new.col - old.col))
        if delta_row != 0 or delta_col != 0:
            result.append((old, new, delta_row, delta_col))
    return result


def rle_scene(view: FrameView, max_rows: int = 64, max_runs: int = 220) -> str:
    grid = view.grid
    rows, cols = grid.shape
    lines: list[str] = []
    run_count = 0
    for row in range(min(rows, max_rows)):
        runs: list[str] = []
        col = 0
        while col < cols:
            color = int(grid[row, col])
            start = col
            while col + 1 < cols and int(grid[row, col + 1]) == color:
                col += 1
            if color != view.background:
                position = str(start) if start == col else f"{start}-{col}"
                symbol = COLOR_SYMBOLS[color] if 0 <= color < len(COLOR_SYMBOLS) else str(color)
                runs.append(f"{position}:{symbol}")
                run_count += 1
                if run_count >= max_runs:
                    break
            col += 1
        if runs:
            lines.append(f"r{row}:" + ",".join(runs))
        if run_count >= max_runs:
            lines.append("[scene truncated after exact non-background run limit]")
            break
    return "\n".join(lines) if lines else "[no non-background cells]"


class GameWorldModel:
    def __init__(self, game_id: str) -> None:
        self.game_id = game_id
        self.action_stats: dict[str, ActionStats] = {}
        self.role_votes: Counter[str] = Counter()
        self.combo_visits: Counter[str] = Counter()
        self.click_visits: Counter[str] = Counter()
        self.transitions: deque[TransitionEvidence] = deque(maxlen=24)
        self.world_model_text = "Unknown mechanics; collecting controlled transition evidence."
        self.goal_model_text = "Unknown objective; prefer information gain without repeating no-ops."
        self.cross_level_notes: deque[str] = deque(maxlen=8)
        self.last_view: Optional[FrameView] = None
        self.last_level = 0

    def _stats(self, name: str) -> ActionStats:
        if name not in self.action_stats:
            self.action_stats[name] = ActionStats()
        return self.action_stats[name]

    def record_transition(
        self,
        before: FrameView,
        after: FrameView,
        action: ActionSpec,
    ) -> TransitionEvidence:
        changed_bbox: Optional[tuple[int, int, int, int]] = None
        color_delta: tuple[str, ...] = ()
        if before.grid.shape == after.grid.shape:
            changed_mask = before.grid != after.grid
            changed_cells = int(np.count_nonzero(changed_mask))
            if changed_cells:
                changed_rows, changed_cols = np.nonzero(changed_mask)
                changed_bbox = (
                    int(changed_rows.min()),
                    int(changed_cols.min()),
                    int(changed_rows.max()),
                    int(changed_cols.max()),
                )
                before_colors = Counter(int(value) for value in before.grid[changed_mask])
                after_colors = Counter(int(value) for value in after.grid[changed_mask])
                deltas = []
                for color in sorted(set(before_colors) | set(after_colors)):
                    delta = after_colors[color] - before_colors[color]
                    if delta:
                        deltas.append(f"c{color}:{delta:+d}")
                color_delta = tuple(deltas)
        else:
            changed_cells = int(before.grid.size + after.grid.size)
        motions = match_component_motion(before, after)
        moved_descriptions = tuple(
            f"{old.role_key}:{delta_row:+d},{delta_col:+d}"
            for old, _new, delta_row, delta_col in motions
        )
        evidence = TransitionEvidence(
            step=after.step,
            action=action,
            before_sig=before.signature,
            after_sig=after.signature,
            changed_cells=changed_cells,
            changed_bbox=changed_bbox,
            color_delta=color_delta,
            moved=moved_descriptions,
            level_before=before.level,
            level_after=after.level,
            state_after=after.state_name,
        )
        self.transitions.append(evidence)
        stats = self._stats(action.name)
        stats.attempts += 1
        stats.changed_cells_total += changed_cells
        if changed_cells:
            stats.changes += 1
        else:
            stats.noops += 1
        if after.state_name == "GAME_OVER":
            stats.game_overs += 1
        if evidence.level_completed:
            stats.level_completions += 1

        expected = DIRECTION_DELTA.get(action.name)
        if expected is not None:
            for old, _new, delta_row, delta_col in motions:
                stats.displacements.append((delta_row, delta_col))
                alignment = delta_row * expected[0] + delta_col * expected[1]
                if alignment > 0:
                    self.role_votes[old.role_key] += 2.0 + min(3.0, alignment)
                elif alignment < 0:
                    self.role_votes[old.role_key] -= 0.5

        if action.name == "ACTION6":
            clicked = self.component_at(before, int(action.y), int(action.x))
            click_key = clicked.role_key if clicked is not None else f"cell:{action.x},{action.y}"
            self.click_visits[click_key] += 1
            if changed_cells:
                self.role_votes[f"interactive:{click_key}"] += 1.0

        if evidence.level_completed:
            note = (
                f"Level {before.level + 1} completed by {action.key} after "
                f"{stats.attempts} observations of that action."
            )
            self.cross_level_notes.append(note)
        self.last_view = after
        self.last_level = after.level
        return evidence

    @staticmethod
    def component_at(view: FrameView, row: int, col: int) -> Optional[Component]:
        candidates = [
            component
            for component in view.components
            if component.top <= row <= component.bottom and component.left <= col <= component.right
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda component: component.pixels)

    def player_component(self, view: FrameView) -> Optional[Component]:
        for role_key, vote in self.role_votes.most_common():
            if vote <= 0 or role_key.startswith("interactive:"):
                continue
            component = view.component_by_role(role_key)
            if component is not None and not component.hud_like:
                return component
        movable = [
            component
            for component in view.components
            if not component.hud_like and component.pixels <= max(64, view.grid.size // 32)
        ]
        if not movable:
            return None
        center_row = (view.grid.shape[0] - 1) / 2
        center_col = (view.grid.shape[1] - 1) / 2
        return min(
            movable,
            key=lambda component: (
                component.touches_edge,
                abs(component.row - center_row) + abs(component.col - center_col),
                component.pixels,
            ),
        )

    def likely_targets(self, view: FrameView, player: Optional[Component]) -> list[Component]:
        candidates = [
            component
            for component in view.components
            if not component.hud_like
            and (player is None or component.object_id != player.object_id)
            and component.pixels < max(256, view.grid.size // 8)
        ]
        if player is None:
            return sorted(candidates, key=lambda component: (component.touches_edge, component.pixels))[:8]
        return sorted(
            candidates,
            key=lambda component: (
                abs(component.row - player.row) + abs(component.col - player.col),
                component.touches_edge,
                component.pixels,
            ),
        )[:8]

    def direction_step(self, action_name: str) -> tuple[int, int]:
        stats = self._stats(action_name)
        expected = DIRECTION_DELTA.get(action_name, (0, 0))
        aligned = [
            displacement
            for displacement in stats.displacements
            if displacement[0] * expected[0] + displacement[1] * expected[1] > 0
        ]
        if not aligned:
            return expected
        return (
            int(round(statistics.median(item[0] for item in aligned))),
            int(round(statistics.median(item[1] for item in aligned))),
        )

    def action_stats_text(self, available: Iterable[str]) -> str:
        parts = []
        for name in available:
            stats = self._stats(name)
            parts.append(
                f"{name}:n={stats.attempts},change={stats.change_rate:.2f},"
                f"risk={stats.risk_rate:.2f},wins={stats.level_completions},noops={stats.noops}"
            )
        return "; ".join(parts)

    def generate_candidates(self, view: FrameView, available: set[str]) -> list[ComboCandidate]:
        raw: list[tuple[ActionSpec, ...]] = []
        directions = [name for name in DIRECTION_DELTA if name in available]
        simple = [name for name in [*directions, "ACTION5", "ACTION7"] if name in available]

        for name in simple:
            raw.append((ActionSpec(name),))
        for name in directions:
            for length in (2, 3, 4, 6):
                raw.append(tuple(ActionSpec(name) for _ in range(length)))
        for length in (2, 3):
            for names in product(directions, repeat=length):
                if any(INVERSE_ACTION.get(names[index]) == names[index + 1] for index in range(length - 1)):
                    continue
                raw.append(tuple(ActionSpec(name) for name in names))

        player = self.player_component(view)
        role_is_observed = bool(self.role_votes) and max(self.role_votes.values(), default=0.0) > 0
        if role_is_observed and player is not None and directions:
            for target in self.likely_targets(view, player)[:4]:
                vertical_name = "ACTION2" if target.row > player.row else "ACTION1"
                horizontal_name = "ACTION4" if target.col > player.col else "ACTION3"
                vertical_step = max(1, abs(self.direction_step(vertical_name)[0]))
                horizontal_step = max(1, abs(self.direction_step(horizontal_name)[1]))
                vertical_count = min(MAX_PLAN_LENGTH, int(round(abs(target.row - player.row) / vertical_step)))
                horizontal_count = min(MAX_PLAN_LENGTH, int(round(abs(target.col - player.col) / horizontal_step)))
                vertical = [vertical_name] * vertical_count if vertical_name in available else []
                horizontal = [horizontal_name] * horizontal_count if horizontal_name in available else []
                for names in (vertical + horizontal, horizontal + vertical):
                    if names:
                        raw.append(tuple(ActionSpec(name) for name in names[:MAX_PLAN_LENGTH]))
        if "ACTION5" in available:
            for name in directions:
                raw.append((ActionSpec(name), ActionSpec("ACTION5")))
                raw.append((ActionSpec("ACTION5"), ActionSpec(name)))

        if "ACTION6" in available:
            click_components = sorted(
                [component for component in view.components if not component.hud_like],
                key=lambda component: (
                    self.click_visits[component.role_key],
                    component.touches_edge,
                    component.pixels,
                ),
            )[:18]
            for component in click_components:
                raw.append(
                    (
                        ActionSpec(
                            "ACTION6",
                            x=int(round(component.col)),
                            y=int(round(component.row)),
                        ),
                    )
                )

        if not raw:
            raw = [(ActionSpec(name),) for name in sorted(available) if name != "RESET"]

        unique: dict[str, tuple[ActionSpec, ...]] = {}
        for combo in raw:
            if not combo or len(combo) > MAX_PLAN_LENGTH:
                continue
            key = ">".join(action.key for action in combo)
            unique.setdefault(key, combo)

        scored = sorted(
            [self.score_combo(view, combo) for combo in unique.values()],
            key=lambda candidate: (-candidate.score, len(candidate.actions), candidate.key),
        )
        diverse: list[ComboCandidate] = []
        seen_keys: set[str] = set()
        for first_action in sorted(available - {"RESET"}):
            representative = next(
                (candidate for candidate in scored if candidate.actions[0].name == first_action),
                None,
            )
            if representative is not None:
                diverse.append(representative)
                seen_keys.add(representative.key)
        for candidate in scored:
            if candidate.key in seen_keys:
                continue
            diverse.append(candidate)
            seen_keys.add(candidate.key)
            if len(diverse) >= 16:
                break
        return sorted(
            diverse[:16],
            key=lambda candidate: (-candidate.score, len(candidate.actions), candidate.key),
        )

    def score_combo(self, view: FrameView, combo: tuple[ActionSpec, ...]) -> ComboCandidate:
        change_values: list[float] = []
        risk = 0.0
        progress_values: list[float] = []
        evidence_attempts = 0
        for action in combo:
            stats = self._stats(action.name)
            change_values.append(stats.change_rate)
            risk += stats.risk_rate
            progress_values.append(stats.progress_rate)
            evidence_attempts += stats.attempts

        change_value = statistics.fmean(change_values) if change_values else 0.0
        progress_history = max(progress_values, default=0.0)

        key = ">".join(action.key for action in combo)
        novelty = 1.0 / (1.0 + self.combo_visits[key])
        score = 0.65 * change_value + 1.8 * progress_history + 0.45 * novelty - 1.3 * risk
        reasons = [
            f"change={change_value:.2f}",
            f"risk={risk:.2f}",
            f"novelty={novelty:.2f}",
        ]

        player = self.player_component(view)
        targets = self.likely_targets(view, player)
        role_is_observed = bool(self.role_votes) and max(self.role_votes.values(), default=0.0) > 0
        if (
            role_is_observed
            and player is not None
            and targets
            and all(action.name in DIRECTION_DELTA for action in combo)
        ):
            target = targets[0]
            before_distance = abs(target.row - player.row) + abs(target.col - player.col)
            predicted_row, predicted_col = player.row, player.col
            for action in combo:
                delta_row, delta_col = self.direction_step(action.name)
                predicted_row += delta_row
                predicted_col += delta_col
            after_distance = abs(target.row - predicted_row) + abs(target.col - predicted_col)
            reduction = before_distance - after_distance
            confidence = min(1.0, evidence_attempts / max(1.0, len(combo)))
            score += (0.18 + 0.37 * confidence) * max(-4.0, min(4.0, reduction))
            reasons.append(f"target_distance_delta={reduction:.1f}")
            rows, cols = view.grid.shape
            if not (0 <= predicted_row < rows and 0 <= predicted_col < cols):
                score -= 2.5
                reasons.append("boundary_penalty")

        if combo[0].name == "ACTION6":
            component = self.component_at(view, int(combo[0].y), int(combo[0].x))
            if component is not None:
                attempts = self.click_visits[component.role_key]
                score += 0.8 / (1 + attempts)
                reasons.append(f"click_object={component.role_key}/tried={attempts}")
            else:
                score -= 0.6
                reasons.append("empty_click_penalty")

        reversals = sum(
            1
            for index in range(len(combo) - 1)
            if INVERSE_ACTION.get(combo[index].name) == combo[index + 1].name
        )
        score -= 0.16 * len(combo) + 0.9 * reversals
        deterministic_tiebreak = int(hashlib.blake2s((view.signature + key).encode(), digest_size=2).hexdigest(), 16)
        score += deterministic_tiebreak / 65535.0 * 0.001
        return ComboCandidate(actions=combo, score=score, rationale=", ".join(reasons))


class ModelProtocolError(ValueError):
    """The configured model endpoint did not return a usable planning response."""


class LocalModelPlanner:
    def __init__(self, game_id: str, world: GameWorldModel) -> None:
        self.game_id = game_id
        self.world = world
        self.failures = 0
        self.disabled = os.environ.get("ARC3_DISABLE_MODEL", "").strip().lower() in {
            "1",
            "true",
            "yes",
        }

    def choose(
        self,
        view: FrameView,
        candidates: list[ComboCandidate],
        available: set[str],
    ) -> ModelDecision:
        if not candidates:
            non_reset = [name for name in sorted(available) if name != "RESET"]
            fallback_name = non_reset[0] if non_reset else "RESET"
            return ModelDecision(
                selected=(ActionSpec(fallback_name),),
                world_model=self.world.world_model_text,
                goal_model=self.world.goal_model_text,
                reasoning_summary=f"No candidate combo was available; selected legal fallback {fallback_name}.",
                source="heuristic",
            )
        if self.disabled:
            return self._heuristic(candidates, "local model disabled by preflight or prior failures")

        payload = self._payload(view, candidates, available)
        request = urllib.request.Request(
            MODEL_ENDPOINT,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": "Bearer arc3-local"},
            method="POST",
        )
        try:
            with MODEL_SEMAPHORE:
                with urllib.request.urlopen(request, timeout=MODEL_TIMEOUT_S) as response:
                    raw_body = response.read().decode("utf-8")
            try:
                body = json.loads(raw_body)
            except json.JSONDecodeError as exc:
                raise ModelProtocolError("model response body was not valid JSON") from exc
            content = self._extract_model_content(body)
            parsed = self._parse_json(content)
            decision = self._validate_decision(parsed, candidates, available)
            self.failures = 0
            return decision
        except ModelProtocolError as exc:
            self.failures += 1
            self.disabled = True
            log(
                self.game_id,
                "MODEL",
                "protocol mismatch; disabling model planner immediately: "
                f"{clip_text(exc, 240)}",
            )
            return self._heuristic(candidates, "model protocol mismatch")
        except Exception as exc:
            self.failures += 1
            if self.failures >= 3:
                self.disabled = True
            log(self.game_id, "MODEL", f"planner failure {self.failures}: {type(exc).__name__}: {clip_text(exc, 240)}")
            return self._heuristic(candidates, f"model failure: {type(exc).__name__}")

    def _payload(
        self,
        view: FrameView,
        candidates: list[ComboCandidate],
        available: set[str],
    ) -> dict[str, Any]:
        player = self.world.player_component(view)
        targets = self.world.likely_targets(view, player)
        component_lines = [component.compact() for component in view.components[:32]]
        transition_lines = [transition.compact() for transition in list(self.world.transitions)[-12:]]
        candidate_lines = [candidate.compact() for candidate in candidates]
        prompt = f"""
GAME: {self.game_id}
TURN: {view.step}; LEVELS_COMPLETED: {view.level}; STATE: {view.state_name}
AVAILABLE: {sorted(available)}
BACKGROUND: color {view.background}; PALETTE_COUNTS: {view.color_counts}
CURRENT_WORLD_MODEL: {self.world.world_model_text}
CURRENT_GOAL_MODEL: {self.world.goal_model_text}
CROSS_LEVEL_MEMORY: {list(self.world.cross_level_notes)}
ACTION_EVIDENCE: {self.world.action_stats_text(sorted(available))}
LIKELY_PLAYER: {player.compact() if player else 'unresolved'}
LIKELY_TARGETS: {[target.compact() for target in targets]}
OBJECTS:\n{chr(10).join(component_lines) if component_lines else '[none]'}
RECENT_TRANSITIONS:\n{chr(10).join(transition_lines) if transition_lines else '[none yet]'}
EXACT_NONBACKGROUND_ROW_RUNS:\n{rle_scene(view)}
CANDIDATE_COMBOS:\n{chr(10).join(f'{index}. {line}' for index, line in enumerate(candidate_lines))}

Select one listed combo. Treat every real environment action as costly. Prefer a short discriminating
probe while the mechanics or objective are uncertain; prefer a direct reliable plan after evidence is
strong. Re-ground after level changes. Do not click HUD/timer bars. Never invent an unavailable action.
Return only one JSON object with exactly these keys:
{{"world_model":"concise testable mechanics summary","goal_model":"concise objective hypothesis",
"selected_candidate":0,"reasoning_summary":"brief evidence-based reason, no hidden chain of thought"}}
""".strip()
        system = (
            "You are the planning module for an ARC-AGI-3 competition agent. Frames are 64x64 color "
            "grids. ACTION1=up, ACTION2=down, ACTION3=left, ACTION4=right, ACTION5=interact/space, "
            "ACTION6=click x,y, ACTION7=undo. Infer object roles and goals from observed transitions. "
            "Maintain a falsifiable world model, compare candidate move combinations, and output strict JSON."
        )
        return {
            "model": MODEL_NAME,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.35,
            "top_p": 0.9,
            "max_tokens": 900,
            "stream": False,
        }

    @staticmethod
    def _extract_model_content(body: Any) -> str:
        if not isinstance(body, dict):
            raise ModelProtocolError("model response must be a JSON object")

        def text_from(value: Any) -> str:
            if isinstance(value, str):
                return value.strip()
            if isinstance(value, list):
                return "\n".join(part for item in value if (part := text_from(item))).strip()
            if isinstance(value, dict):
                for key in ("text", "output_text", "value", "content"):
                    part = text_from(value.get(key))
                    if part:
                        return part
            return ""

        direct = text_from(body.get("output_text"))
        if direct:
            return direct

        choices = body.get("choices")
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            choice = choices[0]
            message = choice.get("message")
            if isinstance(message, dict):
                content = text_from(message.get("content"))
                if content:
                    return content

                tool_calls = message.get("tool_calls")
                if isinstance(tool_calls, list):
                    arguments = []
                    for tool_call in tool_calls:
                        if not isinstance(tool_call, dict):
                            continue
                        function = tool_call.get("function")
                        if not isinstance(function, dict):
                            continue
                        value = function.get("arguments")
                        if isinstance(value, str) and value.strip():
                            arguments.append(value.strip())
                        elif isinstance(value, dict):
                            arguments.append(json.dumps(value))
                    if arguments:
                        return "\n".join(arguments)

                function_call = message.get("function_call")
                if isinstance(function_call, dict):
                    arguments = function_call.get("arguments")
                    if isinstance(arguments, str) and arguments.strip():
                        return arguments.strip()
                    if isinstance(arguments, dict):
                        return json.dumps(arguments)

            completion_text = text_from(choice.get("text"))
            if completion_text:
                return completion_text

        output = text_from(body.get("output"))
        if output:
            return output
        response = text_from(body.get("response"))
        if response:
            return response
        raise ModelProtocolError("unsupported or empty model response schema")

    @staticmethod
    def _parse_json(content: str) -> dict[str, Any]:
        cleaned = re.sub(r"<think>.*?</think>", "", str(content), flags=re.DOTALL | re.IGNORECASE)
        cleaned = cleaned.replace("```json", "").replace("```", "").strip()
        decoder = json.JSONDecoder()
        for index, char in enumerate(cleaned):
            if char != "{":
                continue
            try:
                value, _end = decoder.raw_decode(cleaned[index:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
        raise ModelProtocolError("model response did not contain a JSON object")

    def _validate_decision(
        self,
        parsed: dict[str, Any],
        candidates: list[ComboCandidate],
        available: set[str],
    ) -> ModelDecision:
        raw_index = parsed.get("selected_candidate", 0)
        try:
            selected_index = int(raw_index)
        except (TypeError, ValueError):
            selected_index = 0
        if not 0 <= selected_index < len(candidates):
            selected_index = 0
        selected = candidates[selected_index].actions
        if any(action.name not in available for action in selected):
            selected = candidates[0].actions
        world_model = clip_text(parsed.get("world_model"), 700) or self.world.world_model_text
        goal_model = clip_text(parsed.get("goal_model"), 500) or self.world.goal_model_text
        reasoning = clip_text(parsed.get("reasoning_summary"), 500) or candidates[selected_index].rationale
        self.world.world_model_text = world_model
        self.world.goal_model_text = goal_model
        return ModelDecision(
            selected=selected,
            world_model=world_model,
            goal_model=goal_model,
            reasoning_summary=reasoning,
            source="local-model",
        )

    def _heuristic(self, candidates: list[ComboCandidate], reason: str) -> ModelDecision:
        candidate = candidates[0]
        return ModelDecision(
            selected=candidate.actions,
            world_model=self.world.world_model_text,
            goal_model=self.world.goal_model_text,
            reasoning_summary=f"{reason}; selected highest evidence score: {candidate.rationale}",
            source="heuristic",
        )


class MyAgent(Agent):
    """Object-centric, model-assisted ARC-AGI-3 competition agent."""

    MAX_ACTIONS = max(80, int(os.environ.get("ARC3_MAX_ACTIONS", "320")))

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.world = GameWorldModel(self.game_id)
        self.planner = LocalModelPlanner(self.game_id, self.world)
        self.plan_queue: deque[ActionSpec] = deque()
        self.plan_id = 0
        self.pending_action = ActionSpec("RESET")
        self.pending_reasoning: dict[str, Any] = {}
        self.last_observation: Optional[FrameView] = None
        self.last_evidence: Optional[TransitionEvidence] = None
        self.plan_source = "bootstrap"
        legal = [normalize_action_name(action) for action in getattr(self.arc_env, "action_space", [])]
        log(
            self.game_id,
            "LOAD",
            f"environment loaded; legal={legal or 'from first observation'}; max_actions={self.MAX_ACTIONS}; "
            f"planner={MODEL_ENDPOINT}",
        )

    def is_done(self, frames: list[FrameData], latest_frame: FrameData) -> bool:
        return latest_frame.state is GameState.WIN or self.action_counter >= self.MAX_ACTIONS

    def choose_action(self, frames: list[FrameData], latest_frame: FrameData) -> GameAction:
        view = analyze_frame(latest_frame, self.action_counter)
        self.last_observation = view
        available = self._available_action_names(latest_frame)
        object_preview = " | ".join(component.compact() for component in view.components[:10])
        log(
            self.game_id,
            "OBSERVE",
            f"step={self.action_counter} state={view.state_name} levels={view.level} sig={view.signature} "
            f"bg={view.background} colors={view.color_counts} objects={len(view.components)}",
        )
        log(self.game_id, "OBJECTS", object_preview or "no non-background connected components")

        if latest_frame.state in (GameState.NOT_PLAYED, GameState.GAME_OVER):
            self.plan_queue.clear()
            reason = "start the environment" if latest_frame.state is GameState.NOT_PLAYED else "recover current level after GAME_OVER"
            return self._commit(ActionSpec("RESET"), source="protocol", reason=reason)

        if view.level != self.world.last_level:
            self.plan_queue.clear()
            log(self.game_id, "LEVEL", f"new settled level detected: completed={view.level}; discarded stale queued moves")
            self.world.last_level = view.level

        queue_is_safe = (
            bool(self.plan_queue)
            and self.last_evidence is not None
            and self.last_evidence.changed_cells > 0
            and not self.last_evidence.level_completed
            and self.last_evidence.state_after not in {"GAME_OVER", "WIN"}
        )
        if not queue_is_safe:
            self.plan_queue.clear()

        if not self.plan_queue:
            candidates = self.world.generate_candidates(view, available)
            if not candidates:
                legal = sorted(name for name in available if name != "RESET")
                if not legal:
                    return self._commit(ActionSpec("RESET"), source="protocol", reason="no non-reset action advertised")
                candidates = [self.world.score_combo(view, (ActionSpec(legal[0]),))]
            log(
                self.game_id,
                "CANDIDATES",
                " || ".join(f"#{index} {candidate.compact()}" for index, candidate in enumerate(candidates[:6])),
            )
            decision = self.planner.choose(view, candidates, available)
            self.plan_id += 1
            self.plan_source = decision.source
            self.plan_queue.extend(decision.selected)
            selected_key = ">".join(action.key for action in decision.selected)
            self.world.combo_visits[selected_key] += 1
            log(self.game_id, "WORLD", decision.world_model)
            log(self.game_id, "GOAL", decision.goal_model)
            log(
                self.game_id,
                "REASON",
                f"plan={self.plan_id} source={decision.source} selected={selected_key}; {decision.reasoning_summary}",
            )

        action = self.plan_queue.popleft()
        if action.name not in available:
            self.plan_queue.clear()
            legal = sorted(name for name in available if name != "RESET")
            action = ActionSpec(legal[0]) if legal else ActionSpec("RESET")
        return self._commit(
            action,
            source=self.plan_source,
            reason=f"execute plan {self.plan_id}; {len(self.plan_queue)} queued move(s) remain",
        )

    def _commit(self, action: ActionSpec, source: str, reason: str) -> GameAction:
        self.pending_action = action
        self.pending_reasoning = {
            "plan_id": self.plan_id,
            "source": source,
            "summary": clip_text(reason, 600),
            "world_model": clip_text(self.world.world_model_text, 1000),
            "goal_model": clip_text(self.world.goal_model_text, 700),
        }
        log(
            self.game_id,
            "EXECUTE",
            f"actual_move={action.name} data={action.data} plan={self.plan_id} source={source}; {reason}",
        )
        try:
            return GameAction.from_name(action.name)
        except Exception:
            return getattr(GameAction, action.name)

    def do_action_request(self, action: GameAction) -> FrameData:
        raw = self.arc_env.step(
            action,
            data=dict(self.pending_action.data),
            reasoning=dict(self.pending_reasoning),
        )
        return self._convert_raw_frame_data(raw)

    def append_frame(self, frame: FrameData) -> None:
        after = analyze_frame(frame, self.action_counter + 1)
        if self.last_observation is not None:
            evidence = self.world.record_transition(self.last_observation, after, self.pending_action)
            self.last_evidence = evidence
            log(
                self.game_id,
                "RESULT",
                f"move={self.pending_action.key} changed_cells={evidence.changed_cells} bbox={evidence.changed_bbox} "
                f"color_delta={list(evidence.color_delta)} moved={list(evidence.moved[:5])} "
                f"state={evidence.state_after} levels={evidence.level_before}->{evidence.level_after}",
            )
            if (
                evidence.changed_cells == 0
                or evidence.level_completed
                or evidence.state_after in {"GAME_OVER", "WIN"}
            ):
                if self.plan_queue:
                    log(
                        self.game_id,
                        "REPLAN",
                        f"discarding {len(self.plan_queue)} queued move(s) after boundary/no-op/terminal evidence",
                    )
                self.plan_queue.clear()
        self.last_observation = after
        super().append_frame(frame)

    def _available_action_names(self, latest_frame: FrameData) -> set[str]:
        names: set[str] = set()
        for value in getattr(latest_frame, "available_actions", []) or []:
            try:
                if isinstance(value, GameAction):
                    names.add(value.name)
                else:
                    names.add(GameAction.from_id(int(value)).name)
            except Exception:
                normalized = normalize_action_name(value)
                if normalized:
                    names.add(normalized)
        if not names:
            for action in getattr(self.arc_env, "action_space", []) or []:
                names.add(normalize_action_name(action))
        names.add("RESET")
        return names
