# Sigil Route Agent — Actual ARC-AGI-3 Games Build

This build is wired to real ARC-AGI-3 environments.

It uses:

- `arc_agi.Arcade(...)`
- `arc.get_environments()`
- `arc.make(game_id)`
- `env.reset()`
- `env.action_space`
- `env.step(action, data=..., reasoning=...)`

The competition path does **not** use the synthetic demo environment. Synthetic code remains only for local unit tests.

## Termux / Linux test

```bash
cd ~/sigil_route_agent_e2e
python - <<'PY'
from kaggle_adapter.arc_sigil_agent import ArcSigilAgent
from sigil_route_agent.agent import SigilRouteAgent
import agent
print('imports ok')
PY
```

## Run actual local ARC games

```bash
pip install arc-agi
python scripts/run_actual_arc_games.py --mode OFFLINE --steps 100 --render-mode terminal-fast
```

## Run competition mode

```bash
export OPERATION_MODE=COMPETITION
export SIGIL_VLLM_ENABLED=0
export SIGIL_REASONING_TOKENS=10000
export SIGIL_MAX_STEPS_PER_GAME=1000
python agent.py
```

## Kaggle notebook

```python
!unzip -q /kaggle/input/YOUR_ZIP/sigil_route_agent_ACTUAL_ARC_GAMES.zip -d /kaggle/working
%cd /kaggle/working

import os
os.environ['OPERATION_MODE'] = 'COMPETITION'
os.environ['SIGIL_VLLM_ENABLED'] = '0'
os.environ['SIGIL_REASONING_TOKENS'] = '10000'
os.environ['SIGIL_MAX_STEPS_PER_GAME'] = '1000'

import agent
agent.run_competition()
```

## Contract

```txt
actual ARC frame -> frame extractor -> symbolic state -> rule/planner -> legal env.action_space action -> env.step
```
