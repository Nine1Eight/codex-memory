from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import numpy as np

from sigil_route_agent.agent import SigilRouteAgent

try:
    from arcengine import GameAction
except Exception:  # local import smoke without toolkit
    GameAction = None


@dataclass
class ArcSigilConfig:
    max_plan_steps: int = 128
    contemplation_budget_tokens: int = 10000
    save_debug: bool = False
    safe_fallback: bool = True
    enable_clicks: bool = True


class ArcSigilAgent:
    """
    Adapter for ACTUAL ARC-AGI-3 environments.

    It never creates synthetic states. It receives FrameDataRaw/observation objects
    from env.reset()/env.step(), extracts the actual frame, asks the symbolic agent
    for an intent, then maps that intent into one of env.action_space's GameAction
    objects. Complex click actions get x/y payloads.
    """

    def __init__(self, config: Optional[ArcSigilConfig] = None):
        self.config = config or ArcSigilConfig()
        self.agent = SigilRouteAgent(
            contemplation_budget_tokens=self.config.contemplation_budget_tokens,
            max_plan_steps=self.config.max_plan_steps,
        )
        self.step_index = 0
        self.last_action_name: Optional[str] = None
        self.last_decision: Dict[str, Any] = {}

    def reset(self) -> None:
        self.agent.reset()
        self.step_index = 0
        self.last_action_name = None
        self.last_decision = {}

    def act(self, obs: Any = None, env: Any = None) -> Tuple[Any, Dict[str, Any], Dict[str, Any]]:
        """
        Return (action, action_data, reasoning) for env.step(action, data=..., reasoning=...).
        """
        frame = self._extract_frame(obs, env)
        decision = self.agent.act_from_frame(
            frame=frame,
            step_index=self.step_index,
            previous_action=self.last_action_name,
        )
        action_name = str(decision.get("action", "WAIT")).upper()
        action, action_data = self._map_action(action_name, env, decision)
        reasoning = self._build_reasoning(decision, action_name, action, action_data, frame is not None)

        self.last_action_name = action_name
        self.last_decision = decision
        self.step_index += 1
        return action, action_data, reasoning

    def _extract_frame(self, obs: Any, env: Any = None):
        candidates = []
        if obs is not None:
            candidates.append(obs)
            if isinstance(obs, dict):
                candidates.extend(obs.get(k) for k in ("frame", "frames", "image", "rgb", "pixels", "observation", "data", "grid") if k in obs)
            for attr in ("frame", "frames", "image", "rgb", "pixels", "observation", "data", "grid"):
                if hasattr(obs, attr):
                    try:
                        candidates.append(getattr(obs, attr))
                    except Exception:
                        pass
        if env is not None:
            # Actual ARC wrapper exposes observation_space after reset/step.
            for attr in ("observation_space", "frame", "image", "rgb", "pixels", "last_frame"):
                if hasattr(env, attr):
                    try:
                        candidates.append(getattr(env, attr))
                    except Exception:
                        pass
            # Avoid env.render() here for competition: rendering can be terminal text,
            # not a machine frame, and may add overhead.

        for item in candidates:
            arr = self._to_numpy_frame(item)
            if arr is not None:
                return arr
        return None

    def _to_numpy_frame(self, item: Any):
        if item is None:
            return None
        # Unpack nested FrameDataRaw-like objects.
        for attr in ("frame", "frames", "image", "rgb", "pixels", "data", "grid", "observation"):
            if hasattr(item, attr):
                try:
                    arr = self._to_numpy_frame(getattr(item, attr))
                    if arr is not None:
                        return arr
                except Exception:
                    pass
        if isinstance(item, dict):
            for key in ("frame", "frames", "image", "rgb", "pixels", "data", "grid", "observation"):
                if key in item:
                    arr = self._to_numpy_frame(item[key])
                    if arr is not None:
                        return arr
        if isinstance(item, (list, tuple)) and item:
            # For 1-N frames, use the most recent one.
            arr = self._to_numpy_frame(item[-1])
            if arr is not None:
                return arr
        try:
            arr = np.asarray(item)
        except Exception:
            return None
        if arr.size == 0 or arr.dtype == object:
            return None
        if arr.ndim == 2:
            return arr
        if arr.ndim == 3:
            if arr.shape[-1] in (3, 4):
                return arr[..., :3].astype(np.uint8)
            if arr.shape[0] <= 8:
                return self._to_numpy_frame(arr[-1])
        return None

    def _map_action(self, action_name: str, env: Any = None, decision: Optional[Dict[str, Any]] = None):
        available = self._available_actions(env)
        if not available and GameAction is not None:
            available = [getattr(GameAction, n) for n in dir(GameAction) if n.startswith("ACTION")]

        # ARC actions are abstract ACTION1..ACTION6. Direction naming is only intent.
        preferred_names = {
            "UP": ["ACTION1", "UP"],
            "DOWN": ["ACTION2", "DOWN"],
            "LEFT": ["ACTION3", "LEFT"],
            "RIGHT": ["ACTION4", "RIGHT"],
            "WAIT": ["ACTION5", "WAIT", "NOOP"],
            "ACT": ["ACTION6", "ACT", "CLICK"],
        }.get(action_name, ["ACTION5", "ACTION1"])

        chosen = self._first_matching_action(available, preferred_names)
        if chosen is None and available:
            chosen = self._exploration_action(available)
        if chosen is None:
            chosen = action_name

        data = {}
        if self._is_complex(chosen):
            data = self._click_data(decision)
        return chosen, data

    def _available_actions(self, env: Any) -> list:
        if env is None or not hasattr(env, "action_space"):
            return []
        try:
            return [a for a in list(env.action_space) if "RESET" not in self._action_name(a)]
        except Exception:
            return []

    def _first_matching_action(self, actions: list, names: list):
        upper = [n.upper() for n in names]
        for action in actions:
            an = self._action_name(action).upper()
            if an in upper:
                return action
        if GameAction is not None:
            for name in upper:
                if hasattr(GameAction, name):
                    return getattr(GameAction, name)
                if hasattr(GameAction, "from_name"):
                    try:
                        return GameAction.from_name(name)
                    except Exception:
                        pass
        return None

    def _exploration_action(self, actions: list):
        # Deterministic cycle through legal env actions, not synthetic actions.
        if not actions:
            return None
        idx = self.step_index % len(actions)
        return actions[idx]

    def _action_name(self, action: Any) -> str:
        return str(getattr(action, "name", action))

    def _is_complex(self, action: Any) -> bool:
        try:
            return bool(action.is_complex())
        except Exception:
            return "ACTION6" in self._action_name(action).upper() or "CLICK" in self._action_name(action).upper()

    def _click_data(self, decision: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
        # Default to center of ARC's 64x64 observation grid; later replace with salience target.
        target = None
        if decision:
            target = decision.get("click") or decision.get("target")
        if isinstance(target, (list, tuple)) and len(target) >= 2:
            return {"x": int(target[0]), "y": int(target[1])}
        if isinstance(target, dict) and "x" in target and "y" in target:
            return {"x": int(target["x"]), "y": int(target["y"])}
        return {"x": 32, "y": 32}

    def _build_reasoning(self, decision: Dict[str, Any], intent: str, action: Any, data: Dict[str, Any], got_frame: bool) -> Dict[str, Any]:
        return {
            "agent": "sigil_route_agent_actual_arc",
            "step_index": self.step_index,
            "got_actual_frame": bool(got_frame),
            "symbolic_intent": intent,
            "arc_action": self._action_name(action),
            "action_data": data,
            "state_sigil": decision.get("state_sigil", ""),
            "plan_actions": decision.get("plan_actions", []),
            "confidence": decision.get("confidence", 0.0),
            "reason": decision.get("reason", ""),
        }
