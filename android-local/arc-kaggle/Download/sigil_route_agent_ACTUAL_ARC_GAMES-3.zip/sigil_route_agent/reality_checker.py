
from __future__ import annotations
from .schema import GameState

class RealityChecker:
    def check_drift(self, predicted: GameState, observed: GameState) -> str:
        if observed.terminal:
            return "terminal"
        return "continue" if predicted.to_sigil() == observed.to_sigil() else "replan"
    def compare(self, observed, predicted):
        mode = self.check_drift(predicted, observed)
        return {"match": mode == "continue", "mode": mode, "drift": 0.0 if mode == "continue" else 1.0}
