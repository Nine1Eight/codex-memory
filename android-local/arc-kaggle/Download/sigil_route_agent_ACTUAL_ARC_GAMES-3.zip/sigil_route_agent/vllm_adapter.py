class VLLMAdapter:
    def __init__(self, enabled=False):
        self.enabled = enabled
    def analyze(self, frame):
        return {"enabled": self.enabled, "hypotheses": []}
