
from __future__ import annotations
from copy import deepcopy
from typing import List
from .schema import GameObject, GameState, ObjectType, Rule

ACTION_DELTAS = {
    "UP": (0, -1), "DOWN": (0, 1), "LEFT": (-1, 0), "RIGHT": (1, 0),
    "up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0),
    "WAIT": (0, 0), "ACT": (0, 0),
}

class WorldModelSimulator:
    def simulate(self, state: GameState, action: str, rules: List[Rule] | None = None) -> GameState:
        ns = deepcopy(state)
        ns.frame_id += 1
        agent = ns.agent()
        if agent is None:
            return ns
        dx, dy = ACTION_DELTAS.get(str(action), (0, 0))
        tx, ty = agent.position[0] + dx, agent.position[1] + dy
        target = (tx, ty)
        blocked = ns.blocked_cells()
        if 0 <= tx < ns.width and 0 <= ty < ns.height and target not in blocked:
            agent.position = target
        for obj in list(ns.objects):
            if obj is agent:
                continue
            if obj.position == agent.position and obj.type == ObjectType.KEY:
                ns.inventory.append(ObjectType.KEY)
                ns.objects.remove(obj)
            elif obj.position == agent.position and obj.type == ObjectType.GOAL:
                ns.terminal = True
        return ns

    step = simulate
