
from __future__ import annotations
from typing import List
from .schema import Delta, Rule

class RuleInducer:
    def induce_rules(self, deltas: List[Delta] | None = None) -> List[Rule]:
        return [
            Rule("directional_move", "direction action targets adjacent cell", "agent moves if target is not blocked", 1.0),
            Rule("collision_blocks", "target cell is wall/door/hazard", "agent remains in place", 1.0),
            Rule("collect_key", "agent overlaps key", "key removed and inventory updated", 0.75),
            Rule("goal_wins", "agent overlaps goal", "terminal win", 1.0),
        ]
    def get_rules(self):
        return self.induce_rules([])
