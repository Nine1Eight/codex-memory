
from __future__ import annotations
import argparse, json, os
from .synthetic import generate_demo_run
from .agent import SigilRouteAgent
from .renderer import PredictionRenderer

def run_demo(out_dir: str = "runs/demo"):
    os.makedirs(out_dir, exist_ok=True)
    state = generate_demo_run(out_dir)
    agent = SigilRouteAgent()
    decision = agent.act_from_frame(f"{out_dir}/frame_000.png", step_index=0)
    rules = agent.rule_inducer.get_rules()
    plan = agent.planner.plan(state, rules)
    gif = PredictionRenderer().render_rollout(plan.predicted_states, f"{out_dir}/prediction")
    data = {"decision": decision, "plan_actions": plan.actions, "terminal": bool(plan.predicted_states and plan.predicted_states[-1].terminal), "prediction_gif": gif}
    with open(f"{out_dir}/agent_run.json", "w") as f:
        json.dump(data, f, indent=2)
    print(f"Demo complete. GIF: {gif}")
    print("demo terminal:", "win" if data["terminal"] else "not_win")
    return data

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--out", default="runs/demo"); a = p.parse_args(); run_demo(a.out)
