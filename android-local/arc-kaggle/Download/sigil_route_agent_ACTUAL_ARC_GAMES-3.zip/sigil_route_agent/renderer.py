
from __future__ import annotations
import os
from pathlib import Path
from typing import List
from PIL import Image, ImageDraw
from .schema import GameState, ObjectType

class PredictionRenderer:
    def render_rollout(self, states: List[GameState], out_dir: str) -> str:
        os.makedirs(out_dir, exist_ok=True)
        if not states:
            states = [GameState(8,6,[])]
        frame_paths = []
        for i, state in enumerate(states):
            img = Image.new("RGB", (state.width * 20, state.height * 20), color=(230,230,230))
            draw = ImageDraw.Draw(img)
            for y in range(state.height):
                for x in range(state.width):
                    draw.rectangle([x*20,y*20,(x+1)*20,(y+1)*20], outline=(180,180,180))
            for obj in state.objects:
                x, y = obj.position
                try:
                    color = tuple(int(obj.color.lstrip('#')[j:j+2], 16) for j in (0,2,4))
                except Exception:
                    color = (128,128,128)
                draw.rectangle([x*20+2,y*20+2,(x+1)*20-2,(y+1)*20-2], fill=color)
            fp = Path(out_dir) / f"frame_{i:03d}.png"
            img.save(fp)
            frame_paths.append(fp)
        gif = Path(out_dir) / "predicted_win.gif"
        imgs = [Image.open(p) for p in frame_paths]
        imgs[0].save(gif, save_all=True, append_images=imgs[1:], duration=200, loop=0)
        return str(gif)
    def render(self, states, actions=None, out_dir="prediction"):
        return self.render_rollout(states, out_dir)
