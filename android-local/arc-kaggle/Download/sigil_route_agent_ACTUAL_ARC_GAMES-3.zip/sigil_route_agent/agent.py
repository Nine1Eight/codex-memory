
from __future__ import annotations
from .frame_grid import FrameGridExtractor
from .rules import RuleInducer
from .planner import RoutePlanner
from .simulator import WorldModelSimulator
from .contemplation import ContemplationCore
from .reality_checker import RealityChecker

class SigilRouteAgent:
    def __init__(self, contemplation_budget_tokens: int = 10000, max_plan_steps: int = 128, **kwargs):
        self.extractor = FrameGridExtractor()
        self.rule_inducer = RuleInducer()
        self.planner = RoutePlanner(max_steps=max_plan_steps)
        self.simulator = WorldModelSimulator()
        self.contemplation = ContemplationCore(token_budget=contemplation_budget_tokens)
        self.reality = RealityChecker()
        self.previous_state = None
        self.previous_prediction = None

    def reset(self):
        self.previous_state = None
        self.previous_prediction = None

    def act_from_frame(self, frame=None, step_index: int = 0, previous_action=None, **kwargs):
        state = self.extractor.extract(frame, frame_id=step_index, **kwargs)
        rules = self.rule_inducer.get_rules()
        plan = self.planner.plan(state, rules)
        action = plan.actions[0] if plan.actions else "WAIT"
        pred = self.simulator.simulate(state, action, rules)
        self.previous_state = state
        self.previous_prediction = pred
        return {
            "action": action,
            "state_sigil": state.to_sigil(),
            "plan_actions": plan.actions,
            "confidence": plan.confidence,
            "reason": plan.reason or plan.summary,
            "contemplation": self.contemplation.summarize(state, rules, plan),
        }

    def act(self, frame=None, **kwargs):
        return self.act_from_frame(frame, **kwargs)
