from __future__ import annotations

from collections import deque
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from .schema import GameObject, GameState, ObjectType

Cell = Tuple[int, int]


def _read_public_attrs(obj: Any) -> Dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    out: Dict[str, Any] = {}
    for name in dir(obj):
        if name.startswith("_"):
            continue
        try:
            value = getattr(obj, name)
        except Exception:
            continue
        if not callable(value):
            out[name] = value
    return out


class FrameGridExtractor:
    """
    Actual ARC-AGI-3 frame -> symbolic GameState extractor.

    No fake board is generated for competition. If no actual frame can be found,
    the returned state is empty and the ARC adapter falls back to legal env.action_space
    exploration.
    """

    def __init__(self, default_width: int = 64, default_height: int = 64):
        self.default_width = default_width
        self.default_height = default_height

    def extract(self, frame: Any = None, frame_id: int = 0, **kwargs) -> GameState:
        arr = self._extract_array(frame)
        if arr is None:
            return GameState(width=self.default_width, height=self.default_height, frame_id=frame_id)

        grid = self._array_to_grid(arr)
        h, w = grid.shape[:2]
        state = GameState(width=w, height=h, frame_id=frame_id)

        flat = grid.reshape(-1)
        values, counts = np.unique(flat, return_counts=True)
        bg = str(values[int(np.argmax(counts))])

        comps = self._connected_components(grid, background=bg)
        objects: List[GameObject] = []
        for idx, (color, cells) in enumerate(comps):
            if not cells:
                continue
            kind = self._guess_type(cells, w, h)
            pos = self._centroid_cell(cells)
            objects.append(
                GameObject(
                    type=kind,
                    color=str(color),
                    position=pos,
                    properties={"area": len(cells), "source": "actual_arc_frame"},
                    id=f"{kind.value.lower()}_{idx}",
                )
            )

        if objects and not any(o.type == ObjectType.AGENT for o in objects):
            ai = self._choose_agent_candidate(objects, w, h)
            objects[ai].type = ObjectType.AGENT
            objects[ai].id = "agent_0"

        if objects and not any(o.type == ObjectType.GOAL for o in objects):
            ai = next((i for i, o in enumerate(objects) if o.type == ObjectType.AGENT), None)
            gi = self._choose_goal_candidate(objects, ai) if ai is not None else None
            if gi is not None:
                objects[gi].type = ObjectType.GOAL
                objects[gi].id = "goal_0"

        state.objects = objects
        return state

    def frame_to_state(self, frame: Any = None, **kwargs) -> GameState:
        return self.extract(frame, **kwargs)

    def _extract_array(self, item: Any) -> Optional[np.ndarray]:
        if item is None:
            return None

        candidates: List[Any] = [item]
        d = _read_public_attrs(item)
        for key in ("frame", "frames", "image", "rgb", "pixels", "data", "grid", "observation", "screen", "state_frame"):
            if key in d:
                candidates.append(d[key])

        for cand in list(candidates):
            if isinstance(cand, (list, tuple)) and cand:
                candidates.append(cand[-1])
                if isinstance(cand[-1], dict):
                    candidates.extend(cand[-1].get(k) for k in ("frame", "data", "grid", "pixels", "rgb") if k in cand[-1])

        for cand in candidates:
            if cand is None:
                continue
            try:
                arr = np.asarray(cand)
            except Exception:
                continue
            if arr.size == 0 or arr.dtype == object:
                continue
            if arr.ndim == 2:
                return arr
            if arr.ndim == 3:
                if arr.shape[-1] in (3, 4):
                    return arr[..., :3]
                # Sequence of grayscale frames: [T,H,W].
                if arr.shape[0] <= 8:
                    return np.asarray(arr[-1])
        return None

    def _array_to_grid(self, arr: np.ndarray) -> np.ndarray:
        arr = np.asarray(arr)
        if arr.ndim == 2:
            return arr.astype(str)
        if arr.ndim == 3 and arr.shape[-1] >= 3:
            rgb = arr[..., :3].astype(np.uint8)
            h, w = rgb.shape[:2]
            out = np.empty((h, w), dtype="<U7")
            for y in range(h):
                for x in range(w):
                    r, g, b = rgb[y, x]
                    out[y, x] = f"#{int(r):02x}{int(g):02x}{int(b):02x}"
            return out
        raise ValueError(f"Unsupported frame shape: {arr.shape}")

    def _connected_components(self, grid: np.ndarray, background: str) -> List[Tuple[str, List[Cell]]]:
        h, w = grid.shape[:2]
        seen = np.zeros((h, w), dtype=bool)
        comps: List[Tuple[str, List[Cell]]] = []
        for y in range(h):
            for x in range(w):
                color = str(grid[y, x])
                if seen[y, x] or color == background:
                    continue
                cells: List[Cell] = []
                q = deque([(x, y)])
                seen[y, x] = True
                while q:
                    cx, cy = q.popleft()
                    cells.append((cx, cy))
                    for nx, ny in ((cx+1, cy), (cx-1, cy), (cx, cy+1), (cx, cy-1)):
                        if 0 <= nx < w and 0 <= ny < h and not seen[ny, nx] and str(grid[ny, nx]) == color:
                            seen[ny, nx] = True
                            q.append((nx, ny))
                comps.append((color, cells))
        comps.sort(key=lambda c: len(c[1]), reverse=True)
        return comps[:256]

    def _guess_type(self, cells: List[Cell], w: int, h: int) -> ObjectType:
        xs = [c[0] for c in cells]
        ys = [c[1] for c in cells]
        bw = max(xs) - min(xs) + 1
        bh = max(ys) - min(ys) + 1
        area = len(cells)
        if area > 0.25 * w * h or bw == w or bh == h:
            return ObjectType.WALL
        return ObjectType.UNKNOWN

    def _centroid_cell(self, cells: List[Cell]) -> Cell:
        sx = sum(x for x, _ in cells)
        sy = sum(y for _, y in cells)
        n = max(1, len(cells))
        return (int(round(sx / n)), int(round(sy / n)))

    def _choose_agent_candidate(self, objects: List[GameObject], w: int, h: int) -> int:
        cx, cy = w / 2.0, h / 2.0
        def score(i_obj):
            i, obj = i_obj
            x, y = obj.position
            area = int(obj.properties.get("area", 1))
            return (obj.type == ObjectType.WALL, area > 128, area, abs(x - cx) + abs(y - cy))
        return min(enumerate(objects), key=score)[0]

    def _choose_goal_candidate(self, objects: List[GameObject], agent_idx: Optional[int]) -> Optional[int]:
        if agent_idx is None:
            return None
        ax, ay = objects[agent_idx].position
        best_i = None
        best_dist = -1
        for i, obj in enumerate(objects):
            if i == agent_idx or obj.type == ObjectType.WALL:
                continue
            ox, oy = obj.position
            dist = abs(ox - ax) + abs(oy - ay)
            if dist > best_dist:
                best_dist = dist
                best_i = i
        return best_i
