
from __future__ import annotations
from collections import deque
from typing import List
from .schema import GameState, ObjectType, Plan, Rule
from .simulator import WorldModelSimulator

ACTIONS = ["UP", "DOWN", "LEFT", "RIGHT"]

class RoutePlanner:
    def __init__(self, max_steps: int = 128):
        self.simulator = WorldModelSimulator()
        self.max_steps = max_steps

    def plan(self, state: GameState, rules: List[Rule] | None = None) -> Plan:
        agent = state.agent()
        goals = state.by_type(ObjectType.GOAL)
        if not agent or not goals:
            return Plan(actions=["WAIT"], predicted_states=[state], confidence=0.1, reason="no_agent_or_goal")
        start_sig = state.to_sigil()
        q = deque([(state, [], [state])])
        seen = {start_sig}
        while q:
            cur, path, states = q.popleft()
            if cur.terminal or (cur.agent() and cur.agent().position in {g.position for g in goals}):
                return Plan(actions=path, predicted_states=states, confidence=0.95, reason="bfs_goal")
            if len(path) >= self.max_steps:
                continue
            for action in ACTIONS:
                nxt = self.simulator.simulate(cur, action, rules or [])
                sig = nxt.to_sigil()
                if sig in seen:
                    continue
                seen.add(sig)
                q.append((nxt, path + [action], states + [nxt]))
        return self._greedy_fallback(state, rules or [])

    def _greedy_fallback(self, state: GameState, rules: List[Rule]) -> Plan:
        agent = state.agent(); goals = state.by_type(ObjectType.GOAL)
        if not agent or not goals:
            return Plan(actions=["WAIT"], predicted_states=[state], confidence=0.1, reason="fallback_wait")
        ax, ay = agent.position; gx, gy = goals[0].position
        action = "RIGHT" if gx > ax else "LEFT" if gx < ax else "DOWN" if gy > ay else "UP" if gy < ay else "WAIT"
        nxt = self.simulator.simulate(state, action, rules)
        return Plan(actions=[action], predicted_states=[state, nxt], confidence=0.35, reason="greedy_fallback")
