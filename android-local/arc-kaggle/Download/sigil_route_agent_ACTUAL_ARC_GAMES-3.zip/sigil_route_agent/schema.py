
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

Cell = Tuple[int, int]

class ObjectType(str, Enum):
    AGENT = "AGENT"
    WALL = "WALL"
    KEY = "KEY"
    DOOR = "DOOR"
    GOAL = "GOAL"
    HAZARD = "HAZARD"
    UNKNOWN = "UNKNOWN"

@dataclass
class GameObject:
    type: ObjectType
    color: str
    position: Cell
    properties: Dict[str, Any] = field(default_factory=dict)
    id: str = ""

    def __post_init__(self):
        if isinstance(self.type, str):
            self.type = ObjectType(self.type.upper()) if self.type.upper() in ObjectType.__members__ else ObjectType.UNKNOWN
        if not self.id:
            self.id = f"{self.type.value.lower()}_{self.position[0]}_{self.position[1]}"

    def to_sigil(self) -> str:
        props = ""
        if self.properties:
            props = "." + ".".join(f"{k}={v}" for k, v in sorted(self.properties.items()))
        return f"{self.type.value}.{self.color}@{self.position[0]},{self.position[1]}{props}"

@dataclass
class GameState:
    width: int
    height: int
    objects: List[GameObject] = field(default_factory=list)
    inventory: List[ObjectType] = field(default_factory=list)
    terminal: bool = False
    frame_id: int = 0

    def agent(self) -> Optional[GameObject]:
        return next((o for o in self.objects if o.type == ObjectType.AGENT), None)

    def by_type(self, t: ObjectType | str) -> List[GameObject]:
        if isinstance(t, str):
            t = ObjectType(t.upper()) if t.upper() in ObjectType.__members__ else ObjectType.UNKNOWN
        return [o for o in self.objects if o.type == t]

    def blocked_cells(self) -> set[Cell]:
        return {o.position for o in self.objects if o.type in (ObjectType.WALL, ObjectType.DOOR, ObjectType.HAZARD)}

    def to_sigil(self) -> str:
        grid = f"GRID[{self.width}x{self.height}]"
        obj_strs = [obj.to_sigil() for obj in sorted(self.objects, key=lambda o: (o.position[1], o.position[0], o.type.value))]
        inv_str = f"|INV:{','.join(t.value if isinstance(t, ObjectType) else str(t) for t in self.inventory)}" if self.inventory else ""
        term_str = "|TERMINAL" if self.terminal else ""
        return f"{grid}|{'|'.join(obj_strs)}{inv_str}{term_str}"

    sigil = to_sigil

@dataclass
class Delta:
    action: str
    moved_objects: List[Tuple[GameObject, Cell, Cell]] = field(default_factory=list)
    created: List[GameObject] = field(default_factory=list)
    deleted: List[GameObject] = field(default_factory=list)
    inventory_changes: List[ObjectType] = field(default_factory=list)
    terminal_change: bool = False
    blocked: bool = False
    description: str = ""

@dataclass
class Rule:
    name: str
    condition: str
    effect: str
    confidence: float = 1.0

@dataclass
class Plan:
    actions: List[str]
    predicted_states: List[GameState]
    confidence: float = 1.0
    summary: str = ""
    reason: str = ""
