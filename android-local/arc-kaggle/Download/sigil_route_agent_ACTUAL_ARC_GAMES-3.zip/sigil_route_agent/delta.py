
from __future__ import annotations
from .schema import Delta, GameState

class TemporalDeltaEngine:
    def compute_delta(self, state_t: GameState, action: str, state_tp1: GameState) -> Delta:
        d = Delta(action=action)
        a0 = state_t.agent(); a1 = state_tp1.agent()
        if a0 and a1:
            if a0.position != a1.position:
                d.moved_objects.append((a0, a0.position, a1.position))
            elif action not in ("WAIT", "ACT", None):
                d.blocked = True
        d.terminal_change = state_t.terminal != state_tp1.terminal
        if d.terminal_change:
            d.description = "Terminal state changed"
        return d
    compute = compute_delta
