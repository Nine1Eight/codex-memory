
from __future__ import annotations
import json, os
from PIL import Image, ImageDraw
from .schema import GameObject, GameState, ObjectType

def create_synthetic_frame(state: GameState, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img = Image.new('RGB', (state.width * 20, state.height * 20), color=(230, 230, 230))
    draw = ImageDraw.Draw(img)
    for obj in state.objects:
        x, y = obj.position
        color = tuple(int(obj.color.lstrip('#')[i:i+2], 16) for i in (0, 2, 4)) if obj.color.startswith('#') else (128,128,128)
        draw.rectangle([x*20+2, y*20+2, (x+1)*20-2, (y+1)*20-2], fill=color)
    img.save(path)

def make_initial_state():
    return GameState(8, 6, [
        GameObject(ObjectType.AGENT, "#2878ff", (1,1)),
        GameObject(ObjectType.KEY, "#fadc28", (4,1)),
        GameObject(ObjectType.DOOR, "#dc8c23", (6,1), {"locked": True}),
        GameObject(ObjectType.GOAL, "#3cdc5a", (6,4)),
    ])

def generate_demo_run(out_dir: str = "runs/demo"):
    os.makedirs(out_dir, exist_ok=True)
    state = make_initial_state()
    create_synthetic_frame(state, f"{out_dir}/frame_000.png")
    with open(f"{out_dir}/agent_run.json", "w") as f:
        json.dump({"initial": state.to_sigil()}, f, indent=2)
    print("Synthetic demo generated.")
    return state
