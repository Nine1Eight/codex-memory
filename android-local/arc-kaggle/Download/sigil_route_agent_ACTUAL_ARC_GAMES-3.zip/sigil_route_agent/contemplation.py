
from __future__ import annotations

def contemplate(plan, budget: int = 10000) -> str:
    return f"Selected {len(plan.actions)} actions with confidence {plan.confidence:.2f}; budget={budget}."

class ContemplationCore:
    def __init__(self, token_budget: int = 10000):
        self.token_budget = token_budget
    def summarize(self, state, rules, plan):
        return {
            "budget": self.token_budget,
            "state_sigil": state.to_sigil(),
            "plan_length": len(plan.actions),
            "confidence": plan.confidence,
            "reason": plan.reason or plan.summary,
        }
