from __future__ import annotations

import os
from typing import Any, Iterable, List, Optional

from kaggle_adapter.arc_sigil_agent import ArcSigilAgent, ArcSigilConfig

try:
    import arc_agi
    from arc_agi import OperationMode
    from arcengine import GameState
except Exception:  # import smoke outside ARC runtime
    arc_agi = None
    OperationMode = None
    GameState = None


PUBLIC_FALLBACK_GAMES = [
    "ls20", "ft09", "vc33", "ar25", "lp85", "re86", "sc25", "sk48", "tr87", "tu93", "wa30"
]


class KaggleSigilRouteAgent:
    """
    Competition wrapper for actual ARC-AGI-3 games.

    Synthetic/demo environments are not used here. This class only acts on observations
    coming from env.reset()/env.step() and chooses actions from env.action_space.
    """

    def __init__(self):
        self.agent = ArcSigilAgent(
            ArcSigilConfig(
                max_plan_steps=int(os.getenv("SIGIL_MAX_PLAN_STEPS", "128")),
                contemplation_budget_tokens=int(os.getenv("SIGIL_REASONING_TOKENS", "10000")),
                save_debug=os.getenv("SIGIL_SAVE_DEBUG", "0") == "1",
                safe_fallback=True,
                enable_clicks=True,
            )
        )

    def reset(self):
        self.agent.reset()

    def act(self, obs: Any = None, env: Any = None):
        return self.agent.act(obs, env)


def _operation_mode():
    if OperationMode is None:
        return None
    requested = os.getenv("OPERATION_MODE", "COMPETITION").upper()
    return getattr(OperationMode, requested, getattr(OperationMode, "COMPETITION", None))


def _game_id(info: Any) -> Optional[str]:
    for attr in ("game_id", "id", "name"):
        if hasattr(info, attr):
            try:
                value = getattr(info, attr)
                if value:
                    return str(value)
            except Exception:
                pass
    if isinstance(info, str):
        return info
    return None


def _discover_games(arc: Any) -> List[str]:
    games: List[str] = []
    try:
        for info in arc.get_environments():
            gid = _game_id(info)
            if gid and gid not in games:
                games.append(gid)
    except Exception:
        pass
    if games:
        return games
    # Development fallback only if environment listing fails. These are actual ARC ids,
    # not synthetic games; arc.make() still must succeed.
    envvar = os.getenv("SIGIL_ARC_GAMES", "")
    if envvar.strip():
        return [x.strip() for x in envvar.split(",") if x.strip()]
    return PUBLIC_FALLBACK_GAMES


def _is_terminal(obs: Any) -> bool:
    if obs is None or GameState is None:
        return False
    state = getattr(obs, "state", None)
    return state in (getattr(GameState, "WIN", object()), getattr(GameState, "GAME_OVER", object()))


def _is_game_over(obs: Any) -> bool:
    if obs is None or GameState is None:
        return False
    return getattr(obs, "state", None) == getattr(GameState, "GAME_OVER", object())


def _is_win(obs: Any) -> bool:
    if obs is None or GameState is None:
        return False
    return getattr(obs, "state", None) == getattr(GameState, "WIN", object())


def play_environment(arc: Any, game_id: str, max_steps: int = 1000, render_mode: Optional[str] = None) -> dict:
    """Play one real ARC environment exactly once via arc.make(game_id)."""
    env = arc.make(game_id, render_mode=render_mode)
    if env is None:
        return {"game_id": game_id, "made": False, "steps": 0, "status": "make_failed"}

    runner = KaggleSigilRouteAgent()
    runner.reset()

    try:
        obs = env.reset()
    except Exception:
        obs = getattr(env, "observation_space", None)

    steps = 0
    status = "running"
    for step in range(max_steps):
        try:
            action, data, reasoning = runner.act(obs, env)
            obs = env.step(action, data=data or None, reasoning=reasoning)
            steps += 1
        except TypeError:
            # Older toolkit compatibility: step(action) only.
            try:
                action, data, reasoning = runner.act(obs, env)
                obs = env.step(action)
                steps += 1
            except Exception as exc:
                status = f"step_error:{type(exc).__name__}"
                break
        except Exception as exc:
            status = f"step_error:{type(exc).__name__}"
            break

        if _is_win(obs):
            status = "win"
            break
        if _is_game_over(obs):
            status = "game_over"
            # In competition mode, game reset is restricted; avoid repeated make().
            break

    return {"game_id": game_id, "made": True, "steps": steps, "status": status}


def run_competition(max_steps_per_game: Optional[int] = None, render_mode: Optional[str] = None):
    """
    Actual ARC-AGI-3 competition entrypoint.

    - Instantiates arc_agi.Arcade with OperationMode.COMPETITION by default.
    - Discovers actual environments with arc.get_environments().
    - Calls arc.make(game_id) once per environment.
    - Calls env.reset() and env.step(...) with legal env.action_space actions.
    """
    if arc_agi is None:
        raise RuntimeError("arc_agi is not installed. Install with: pip install arc-agi")

    max_steps = int(max_steps_per_game or os.getenv("SIGIL_MAX_STEPS_PER_GAME", "1000"))
    mode = _operation_mode()
    arc = arc_agi.Arcade(operation_mode=mode)

    game_ids = _discover_games(arc)
    results = []
    for game_id in game_ids:
        results.append(play_environment(arc, game_id, max_steps=max_steps, render_mode=render_mode))

    scorecard = None
    try:
        # In competition mode this may be blocked while in-flight. Do not require it.
        scorecard = arc.get_scorecard()
    except Exception:
        scorecard = None

    return {"mode": str(mode), "games": results, "scorecard": str(scorecard) if scorecard is not None else None}


if __name__ == "__main__":
    print(run_competition())
