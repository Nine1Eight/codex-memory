from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Ensure project root is importable when script is run directly.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import agent


def main() -> None:
    p = argparse.ArgumentParser(description="Run Sigil Route Agent on actual ARC-AGI-3 environments.")
    p.add_argument("--mode", default=os.getenv("OPERATION_MODE", "OFFLINE"), choices=["NORMAL", "OFFLINE", "ONLINE", "COMPETITION"])
    p.add_argument("--steps", type=int, default=int(os.getenv("SIGIL_MAX_STEPS_PER_GAME", "1000")))
    p.add_argument("--render-mode", default=None)
    p.add_argument("--out", default="runs/actual_arc_results.json")
    args = p.parse_args()

    os.environ["OPERATION_MODE"] = args.mode
    result = agent.run_competition(max_steps_per_game=args.steps, render_mode=args.render_mode)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
