from __future__ import annotations

import hashlib
import importlib
import json
import os
import random
from pathlib import Path
from typing import Any, Callable

import numpy as np


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        try:
            torch.set_num_threads(max(1, min(4, torch.get_num_threads())))
        except Exception:
            pass
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def ensure_parent(path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def stable_hash_array(arr: np.ndarray) -> str:
    h = hashlib.blake2b(digest_size=16)
    h.update(str(arr.shape).encode("utf-8"))
    h.update(str(arr.dtype).encode("utf-8"))
    h.update(np.ascontiguousarray(arr).tobytes())
    return h.hexdigest()


def json_dump(obj: Any, path: str | Path) -> None:
    p = ensure_parent(path)
    p.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def import_factory(spec: str) -> Callable[..., Any]:
    if ":" not in spec:
        raise ValueError("factory spec must be 'module.submodule:callable_name'")
    mod_name, fn_name = spec.split(":", 1)
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, fn_name)
    if not callable(fn):
        raise TypeError(f"{spec!r} does not resolve to a callable")
    return fn


def atomic_torch_save(obj: Any, path: str | Path) -> None:
    p = ensure_parent(path)
    tmp = p.with_suffix(p.suffix + ".tmp")
    try:
        import torch
        torch.save(obj, tmp)
        os.replace(tmp, p)
    finally:
        if tmp.exists():
            tmp.unlink(missing_ok=True)
