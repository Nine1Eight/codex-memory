from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .controls import ControlCommand, ControlSchema
from .observations import ParsedObservation, extract_grid


@dataclass(slots=True)
class StepResult:
    obs: ParsedObservation
    reward: float | None
    terminal: bool
    level_complete: bool
    info: dict[str, Any]
    error: str | None = None


class EnvAdapter:
    """Dynamic environment adapter.

    The adapter translates pure controls to common environment payload shapes.
    If an environment needs exact official ARC-specific payload formatting, put
    that formatting in a wrapper around the env. Do not put game strategy here.
    """

    def __init__(self, env: Any, grid_size: int = 64, num_colors: int = 16, strict: bool = False):
        self.env = env
        self.grid_size = int(grid_size)
        self.num_colors = int(num_colors)
        self.strict = bool(strict)
        self.schema = ControlSchema.from_env(env)

    def reset(self) -> ParsedObservation:
        out = self.env.reset()
        return extract_grid(out, grid_size=self.grid_size, num_colors=self.num_colors)

    def step(self, command: ControlCommand) -> StepResult:
        payloads = self._payload_candidates(command)
        last_exc: Exception | None = None
        for payload in payloads:
            try:
                out = self.env.step(payload)
                return self._parse_step_output(out)
            except Exception as exc:  # try alternate API payloads
                last_exc = exc
                if self.strict:
                    break
        if last_exc is not None:
            raise last_exc
        raise RuntimeError("env.step failed without exception")

    def _payload_candidates(self, command: ControlCommand) -> list[Any]:
        h = w = self.grid_size
        px = None if command.x is None else int(np.clip(command.x, 0.0, 1.0) * (w - 1))
        py = None if command.y is None else int(np.clip(command.y, 0.0, 1.0) * (h - 1))
        px2 = None if command.x2 is None else int(np.clip(command.x2, 0.0, 1.0) * (w - 1))
        py2 = None if command.y2 is None else int(np.clip(command.y2, 0.0, 1.0) * (h - 1))

        d = command.to_json()
        d.update({"px": px, "py": py, "px2": px2, "py2": py2})

        if command.kind == "click":
            return [d, {"action": command.action_id, "x": px, "y": py}, (command.action_id, px, py), command.action_id]
        if command.kind == "drag":
            return [
                d,
                {"action": command.action_id, "x": px, "y": py, "x2": px2, "y2": py2},
                (command.action_id, px, py, px2, py2),
                command.action_id,
            ]
        return [d, {"action": command.action_id}, command.action_id]

    def _parse_step_output(self, out: Any) -> StepResult:
        reward: float | None = None
        terminal = False
        complete = False
        info: dict[str, Any] = {}
        obs_part = out

        if isinstance(out, tuple):
            if len(out) == 5:
                obs_part, reward, terminated, truncated, info_obj = out
                terminal = bool(terminated) or bool(truncated)
                info = info_obj if isinstance(info_obj, dict) else {}
            elif len(out) == 4:
                obs_part, reward, done, info_obj = out
                terminal = bool(done)
                info = info_obj if isinstance(info_obj, dict) else {}
            elif len(out) == 3:
                obs_part, reward, done = out
                terminal = bool(done)
            elif len(out) == 2:
                obs_part, info_obj = out
                info = info_obj if isinstance(info_obj, dict) else {}

        elif isinstance(out, dict):
            reward = out.get("reward", reward)
            terminal = bool(out.get("done", out.get("terminal", out.get("is_terminal", terminal))))
            complete = bool(out.get("level_complete", out.get("complete", out.get("success", complete))))
            info = out.get("info", {}) if isinstance(out.get("info", {}), dict) else {}

        else:
            reward = getattr(out, "reward", reward)
            terminal = bool(getattr(out, "done", getattr(out, "terminal", getattr(out, "is_terminal", terminal))))
            complete = bool(getattr(out, "level_complete", getattr(out, "complete", getattr(out, "success", complete))))
            maybe_info = getattr(out, "info", {})
            info = maybe_info if isinstance(maybe_info, dict) else {}

        parsed = extract_grid(obs_part, grid_size=self.grid_size, num_colors=self.num_colors)
        terminal = terminal or parsed.terminal
        complete = complete or parsed.level_complete or bool(info.get("level_complete", False)) or bool(info.get("success", False))
        return StepResult(obs=parsed, reward=None if reward is None else float(reward), terminal=terminal, level_complete=complete, info=info)


class MockControlsEnv:
    """Small deterministic environment for plumbing tests only.

    It intentionally exposes no game label or semantic objective. Controls cause
    simple pixel effects so the trainer can validate recording and learning.
    """

    num_actions = 5

    def __init__(self, size: int = 64, max_steps: int = 25, seed: int = 918):
        self.size = size
        self.max_steps = max_steps
        self.rng = np.random.default_rng(seed)
        self.t = 0
        self.grid = np.zeros((size, size), dtype=np.uint8)
        self.pos = [size // 2, size // 2]

    def reset(self) -> dict[str, Any]:
        self.t = 0
        self.grid.fill(0)
        self.pos = [self.size // 2, self.size // 2]
        self.grid[self.pos[1], self.pos[0]] = 3
        return {"grid": self.grid.copy(), "done": False}

    def step(self, action: Any):
        aid = action.get("action", action.get("action_id", 0)) if isinstance(action, dict) else int(action)
        self.grid[self.pos[1], self.pos[0]] = 0
        if aid == 1:
            self.pos[1] = max(0, self.pos[1] - 1)
        elif aid == 2:
            self.pos[1] = min(self.size - 1, self.pos[1] + 1)
        elif aid == 3:
            self.pos[0] = max(0, self.pos[0] - 1)
        elif aid == 4:
            self.pos[0] = min(self.size - 1, self.pos[0] + 1)
        if isinstance(action, dict) and action.get("kind") == "click" and action.get("px") is not None:
            x = int(np.clip(action["px"], 0, self.size - 1))
            y = int(np.clip(action["py"], 0, self.size - 1))
            self.grid[y, x] = 9
        self.grid[self.pos[1], self.pos[0]] = 3
        self.t += 1
        done = self.t >= self.max_steps
        return {"grid": self.grid.copy(), "done": done, "level_complete": False}, 0.0, done, {}


def create_mock_env() -> MockControlsEnv:
    return MockControlsEnv()
