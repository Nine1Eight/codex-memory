from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Iterable, Sequence

import numpy as np


@dataclass(frozen=True, slots=True)
class ControlCommand:
    """A pure control command, not a game semantic.

    kind is the only symbolic part. Coordinates are normalized to [0, 1]
    in the agent and converted by the adapter when needed.
    """

    action_id: int
    kind: str = "button"
    x: float | None = None
    y: float | None = None
    x2: float | None = None
    y2: float | None = None
    hold: float = 0.0

    def to_vector(self, max_action_id: int) -> np.ndarray:
        denom = max(1, max_action_id)
        return np.array(
            [
                self.action_id / denom,
                -1.0 if self.x is None else float(self.x),
                -1.0 if self.y is None else float(self.y),
                -1.0 if self.x2 is None else float(self.x2),
                -1.0 if self.y2 is None else float(self.y2),
                float(self.hold),
                1.0 if self.kind == "click" else 0.0,
                1.0 if self.kind == "drag" else 0.0,
            ],
            dtype=np.float32,
        )

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ControlSchema:
    """Allowed prior: controls only."""

    button_count: int = 5
    has_click: bool = True
    has_drag: bool = False
    grid_targets: int = 5

    @property
    def max_action_id(self) -> int:
        base = self.button_count
        if self.has_click:
            base += 1
        if self.has_drag:
            base += 1
        return max(0, base - 1)

    @classmethod
    def from_env(cls, env: Any | None) -> "ControlSchema":
        """Infer control count from an environment without adding game rules."""
        if env is None:
            return cls()
        n = None
        action_space = getattr(env, "action_space", None)
        if action_space is not None:
            n = getattr(action_space, "n", None)
        if n is None:
            n = getattr(env, "num_actions", None)
        if isinstance(n, int) and n > 0:
            # Treat all exposed actions as buttons unless user overrides later.
            return cls(button_count=n, has_click=True, has_drag=False)
        return cls()

    def base_buttons(self) -> list[ControlCommand]:
        return [ControlCommand(action_id=i, kind="button") for i in range(self.button_count)]


def _linspace_targets(n: int) -> list[tuple[float, float]]:
    n = max(2, int(n))
    vals = np.linspace(0.10, 0.90, n)
    pts = [(float(x), float(y)) for y in vals for x in vals]
    pts.append((0.5, 0.5))
    # Deduplicate while preserving order.
    seen: set[tuple[float, float]] = set()
    out: list[tuple[float, float]] = []
    for p in pts:
        key = (round(p[0], 4), round(p[1], 4))
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def saliency_targets(grid: np.ndarray, limit: int = 16) -> list[tuple[float, float]]:
    """Generic pixel-structure target proposals.

    This is not a game prior: it only proposes centers of non-background
    connected color regions and high-contrast cells.
    """
    h, w = grid.shape[:2]
    if h == 0 or w == 0:
        return [(0.5, 0.5)]
    vals, counts = np.unique(grid, return_counts=True)
    bg = vals[int(np.argmax(counts))]
    mask = grid != bg
    if not bool(mask.any()):
        return [(0.5, 0.5)]

    visited = np.zeros(mask.shape, dtype=bool)
    targets: list[tuple[int, float, float]] = []
    for yy in range(h):
        for xx in range(w):
            if visited[yy, xx] or not mask[yy, xx]:
                continue
            color = grid[yy, xx]
            stack = [(xx, yy)]
            xs: list[int] = []
            ys: list[int] = []
            visited[yy, xx] = True
            while stack:
                x, y = stack.pop()
                xs.append(x)
                ys.append(y)
                for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if 0 <= nx < w and 0 <= ny < h and not visited[ny, nx] and mask[ny, nx] and grid[ny, nx] == color:
                        visited[ny, nx] = True
                        stack.append((nx, ny))
            size = len(xs)
            cx = (float(np.mean(xs)) + 0.5) / w
            cy = (float(np.mean(ys)) + 0.5) / h
            targets.append((size, cx, cy))
    targets.sort(reverse=True, key=lambda t: t[0])
    out = [(cx, cy) for _, cx, cy in targets[:limit]]
    out.append((0.5, 0.5))
    return out[:limit]


def propose_controls(schema: ControlSchema, grid: np.ndarray, limit: int) -> list[ControlCommand]:
    """Return bounded pure-control proposals."""
    proposals: list[ControlCommand] = []
    proposals.extend(schema.base_buttons())

    if schema.has_click:
        click_id = schema.button_count
        targets = saliency_targets(grid, limit=max(4, limit // 3))
        targets.extend(_linspace_targets(schema.grid_targets))
        seen: set[tuple[int, int]] = set()
        for x, y in targets:
            key = (int(x * 1000), int(y * 1000))
            if key in seen:
                continue
            seen.add(key)
            proposals.append(ControlCommand(action_id=click_id, kind="click", x=float(x), y=float(y)))
            if len(proposals) >= limit:
                return proposals[:limit]

    if schema.has_drag:
        drag_id = schema.button_count + int(schema.has_click)
        anchors = _linspace_targets(max(2, schema.grid_targets // 2))[:8]
        for x, y in anchors:
            for x2, y2 in ((0.5, 0.5), (1.0 - x, 1.0 - y)):
                proposals.append(ControlCommand(action_id=drag_id, kind="drag", x=x, y=y, x2=x2, y2=y2))
                if len(proposals) >= limit:
                    return proposals[:limit]

    return proposals[:limit]
