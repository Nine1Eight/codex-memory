from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterator

import numpy as np

from .controls import ControlCommand
from .utils import ensure_parent, stable_hash_array

SCHEMA_VERSION = "arc3.controls_prior.v1"


def encode_grid(grid: np.ndarray) -> dict[str, Any]:
    arr = np.asarray(grid, dtype=np.uint8)
    return {
        "shape": list(arr.shape),
        "dtype": "uint8",
        "b64": base64.b64encode(np.ascontiguousarray(arr).tobytes()).decode("ascii"),
    }


def decode_grid(obj: dict[str, Any]) -> np.ndarray:
    shape = tuple(int(x) for x in obj["shape"])
    raw = base64.b64decode(obj["b64"].encode("ascii"))
    return np.frombuffer(raw, dtype=np.uint8).reshape(shape).copy()


@dataclass(slots=True)
class TransitionRecord:
    schema: str
    episode: int
    step: int
    action: dict[str, Any]
    before: dict[str, Any]
    after: dict[str, Any]
    before_hash: str
    after_hash: str
    changed: int
    terminal: bool = False
    level_complete: bool = False
    reward: float | None = None
    error: str | None = None
    ts: float = 0.0

    @classmethod
    def make(
        cls,
        episode: int,
        step: int,
        action: ControlCommand,
        before_grid: np.ndarray,
        after_grid: np.ndarray,
        terminal: bool = False,
        level_complete: bool = False,
        reward: float | None = None,
        error: str | None = None,
    ) -> "TransitionRecord":
        before = np.asarray(before_grid, dtype=np.uint8)
        after = np.asarray(after_grid, dtype=np.uint8)
        return cls(
            schema=SCHEMA_VERSION,
            episode=int(episode),
            step=int(step),
            action=action.to_json(),
            before=encode_grid(before),
            after=encode_grid(after),
            before_hash=stable_hash_array(before),
            after_hash=stable_hash_array(after),
            changed=int(np.sum(before != after)),
            terminal=bool(terminal),
            level_complete=bool(level_complete),
            reward=None if reward is None else float(reward),
            error=error,
            ts=time.time(),
        )

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


class TransitionWriter:
    def __init__(self, path: str | Path):
        self.path = ensure_parent(path)
        self.fp = self.path.open("a", encoding="utf-8")

    def write(self, rec: TransitionRecord) -> None:
        self.fp.write(json.dumps(rec.to_json(), sort_keys=True) + "\n")
        self.fp.flush()

    def close(self) -> None:
        self.fp.close()

    def __enter__(self) -> "TransitionWriter":
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()


def read_transitions(path: str | Path) -> Iterator[tuple[np.ndarray, np.ndarray, np.ndarray, dict[str, Any]]]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as fp:
        for line_no, line in enumerate(fp, 1):
            if not line.strip():
                continue
            obj = json.loads(line)
            if obj.get("schema") != SCHEMA_VERSION:
                raise ValueError(f"line {line_no}: unsupported schema {obj.get('schema')}")
            before = decode_grid(obj["before"])
            after = decode_grid(obj["after"])
            action = obj["action"]
            yield before, action, after, obj
