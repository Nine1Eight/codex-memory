from __future__ import annotations

import random
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .config import AgentConfig
from .controls import ControlCommand, ControlSchema
from .dataset import read_transitions
from .model import SpatialControlWorldModel, pixel_ce_loss
from .utils import atomic_torch_save


def _command_from_json(obj: dict[str, Any]) -> ControlCommand:
    allowed = {"action_id", "kind", "x", "y", "x2", "y2", "hold"}
    kwargs = {k: obj.get(k) for k in allowed if k in obj}
    return ControlCommand(**kwargs)


def load_records(path: str | Path, limit: int | None = None) -> list[tuple[np.ndarray, ControlCommand, np.ndarray]]:
    rows: list[tuple[np.ndarray, ControlCommand, np.ndarray]] = []
    for before, action_obj, after, _raw in read_transitions(path):
        rows.append((before, _command_from_json(action_obj), after))
        if limit is not None and len(rows) >= limit:
            break
    if not rows:
        raise ValueError(f"no transition rows found in {path}")
    return rows


def train_offline(
    dataset: str | Path,
    checkpoint: str | Path,
    epochs: int = 3,
    batch_size: int = 32,
    lr: float = 1e-3,
    seed: int = 918,
    device: str = "cpu",
) -> dict[str, Any]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    records = load_records(dataset)
    max_aid = max(int(r[1].action_id) for r in records)
    schema = ControlSchema(button_count=max(1, max_aid + 1), has_click=True, has_drag=False)
    model = SpatialControlWorldModel(num_colors=16, latent_dim=16).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-5)

    losses: list[float] = []
    model.train()
    for _epoch in range(int(epochs)):
        random.shuffle(records)
        for start in range(0, len(records), batch_size):
            batch = records[start : start + batch_size]
            if len(batch) < 2:
                continue
            grids = torch.as_tensor(np.stack([b[0] for b in batch]), dtype=torch.long, device=device)
            ctrls = torch.as_tensor(np.stack([b[1].to_vector(schema.max_action_id) for b in batch]), dtype=torch.float32, device=device)
            targets = torch.as_tensor(np.stack([b[2] for b in batch]), dtype=torch.long, device=device)
            logits = model(grids, ctrls)
            loss = pixel_ce_loss(logits, targets)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            losses.append(float(loss.detach().cpu().item()))

    package = {
        "model": model.state_dict(),
        "schema": {"button_count": schema.button_count, "has_click": schema.has_click, "has_drag": schema.has_drag},
        "cfg": {"lr": lr, "batch_size": batch_size, "seed": seed},
        "rows": len(records),
        "epochs": int(epochs),
        "loss_last": None if not losses else losses[-1],
        "loss_mean": None if not losses else float(np.mean(losses)),
    }
    atomic_torch_save(package, checkpoint)
    return {k: v for k, v in package.items() if k != "model"}
