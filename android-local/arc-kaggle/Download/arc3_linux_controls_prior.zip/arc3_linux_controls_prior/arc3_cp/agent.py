from __future__ import annotations

import random
from collections import deque
from dataclasses import asdict
from typing import Any

import numpy as np
import torch

from .config import AgentConfig
from .controls import ControlCommand, ControlSchema, propose_controls
from .model import SpatialControlWorldModel, batch_from_records, pixel_ce_loss


class PixelControlAgent:
    """Online agent that learns controls from raw transition outcomes.

    The agent receives no game-specific symbols. It chooses pure controls,
    records resulting pixel transitions, and trains a next-state predictor.
    """

    def __init__(self, schema: ControlSchema, cfg: AgentConfig | None = None):
        self.schema = schema
        self.cfg = cfg or AgentConfig()
        self.device = torch.device(self.cfg.device)
        self.model = SpatialControlWorldModel(
            num_colors=self.cfg.num_colors,
            latent_dim=self.cfg.latent_dim,
        ).to(self.device)
        self.optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.cfg.lr, weight_decay=1e-5)
        self.buffer: deque[tuple[np.ndarray, ControlCommand, np.ndarray]] = deque(maxlen=self.cfg.buffer_size)
        self.epsilon = float(self.cfg.epsilon_start)
        self.steps_seen = 0
        self.last_loss: float | None = None

    def observe_transition(self, before: np.ndarray, action: ControlCommand, after: np.ndarray) -> None:
        self.buffer.append((before.astype(np.uint8), action, after.astype(np.uint8)))
        self.steps_seen += 1

    def act(self, grid: np.ndarray) -> ControlCommand:
        proposals = propose_controls(self.schema, grid, limit=self.cfg.proposal_limit)
        if not proposals:
            return ControlCommand(action_id=0, kind="button")
        if random.random() < self.epsilon or len(self.buffer) < self.cfg.batch_size:
            return random.choice(proposals)
        return self._choose_by_model(grid, proposals)

    def _choose_by_model(self, grid: np.ndarray, proposals: list[ControlCommand]) -> ControlCommand:
        """Choose action by predicted information gain / state change.

        This is a game-agnostic objective. It favors controls likely to produce
        nontrivial observable effects while preserving exploration.
        """
        self.model.eval()
        with torch.no_grad():
            grid_batch = torch.as_tensor(
                np.repeat(grid[None, :, :], len(proposals), axis=0), dtype=torch.long, device=self.device
            )
            ctrl_batch = torch.as_tensor(
                np.stack([p.to_vector(self.schema.max_action_id) for p in proposals]),
                dtype=torch.float32,
                device=self.device,
            )
            logits = self.model(grid_batch, ctrl_batch)
            probs = logits.softmax(dim=1)
            pred = probs.argmax(dim=1).cpu().numpy().astype(np.uint8)
            entropy = (-(probs * (probs + 1e-8).log()).sum(dim=1).mean(dim=(1, 2))).cpu().numpy()
        change = np.array([(p != grid).mean() for p in pred], dtype=np.float32)
        # Avoid degenerate all-change hallucinations: peak around moderate predicted effect.
        effect = 1.0 - np.abs(change - 0.15)
        scores = 0.55 * effect + 0.45 * entropy.astype(np.float32)
        best = int(np.argmax(scores))
        return proposals[best]

    def train_step(self, updates: int | None = None) -> dict[str, Any]:
        if len(self.buffer) < self.cfg.batch_size:
            return {"trained": False, "buffer": len(self.buffer), "loss": self.last_loss}
        updates = self.cfg.updates_per_train if updates is None else updates
        losses: list[float] = []
        self.model.train()
        for _ in range(updates):
            batch = random.sample(list(self.buffer), self.cfg.batch_size)
            grids, controls, targets = batch_from_records(batch, self.schema, str(self.device))
            logits = self.model(grids, controls)
            loss = pixel_ce_loss(logits, targets)
            self.optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            self.optimizer.step()
            losses.append(float(loss.detach().cpu().item()))
        self.epsilon = max(self.cfg.epsilon_end, self.epsilon * self.cfg.epsilon_decay)
        self.last_loss = float(np.mean(losses))
        return {"trained": True, "buffer": len(self.buffer), "loss": self.last_loss, "epsilon": self.epsilon}

    def state_dict_package(self) -> dict[str, Any]:
        return {
            "model": self.model.state_dict(),
            "schema": asdict(self.schema),
            "cfg": asdict(self.cfg),
            "epsilon": self.epsilon,
            "steps_seen": self.steps_seen,
        }

    def load_state_dict_package(self, package: dict[str, Any]) -> None:
        self.model.load_state_dict(package["model"])
        self.epsilon = float(package.get("epsilon", self.epsilon))
        self.steps_seen = int(package.get("steps_seen", self.steps_seen))
