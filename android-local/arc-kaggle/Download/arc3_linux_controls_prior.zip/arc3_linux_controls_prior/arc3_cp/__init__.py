"""ARC3 controls-prior trainer."""

__all__ = ["__version__"]
__version__ = "0.1.0"
