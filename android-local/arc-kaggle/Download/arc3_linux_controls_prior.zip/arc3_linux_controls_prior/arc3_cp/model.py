from __future__ import annotations

from typing import Iterable

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .controls import ControlCommand, ControlSchema


class SpatialControlWorldModel(nn.Module):
    """Predict next pixel-grid from current grid + pure control vector."""

    def __init__(self, num_colors: int = 16, latent_dim: int = 16, control_dim: int = 8):
        super().__init__()
        self.num_colors = int(num_colors)
        self.latent_dim = int(latent_dim)
        self.control_dim = int(control_dim)

        self.color_embed = nn.Embedding(self.num_colors, 8)
        self.encoder = nn.Sequential(
            nn.Conv2d(8, 16, 4, stride=2, padding=1),
            nn.GELU(),
            nn.Conv2d(16, 32, 4, stride=2, padding=1),
            nn.GELU(),
            nn.Conv2d(32, self.latent_dim, 4, stride=2, padding=1),
            nn.GELU(),
        )
        self.control_mlp = nn.Sequential(
            nn.Linear(self.control_dim, 64),
            nn.GELU(),
            nn.Linear(64, self.latent_dim * 8 * 8),
        )
        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(self.latent_dim, 32, 4, stride=2, padding=1),
            nn.GELU(),
            nn.ConvTranspose2d(32, 16, 4, stride=2, padding=1),
            nn.GELU(),
            nn.ConvTranspose2d(16, self.num_colors, 4, stride=2, padding=1),
        )

    def forward(self, grid: torch.Tensor, control: torch.Tensor) -> torch.Tensor:
        if grid.ndim != 3:
            raise ValueError(f"grid must be [B,H,W], got {tuple(grid.shape)}")
        b = grid.shape[0]
        x = self.color_embed(grid.long().clamp(0, self.num_colors - 1)).permute(0, 3, 1, 2)
        z = self.encoder(x)
        c = self.control_mlp(control.float()).view(b, self.latent_dim, 8, 8)
        return self.decoder(z + c)

    @torch.no_grad()
    def predict_next(self, grid_np: np.ndarray, command: ControlCommand, schema: ControlSchema, device: str = "cpu") -> np.ndarray:
        self.eval()
        grid_t = torch.as_tensor(grid_np[None, :, :], dtype=torch.long, device=device)
        ctrl_t = torch.as_tensor(command.to_vector(schema.max_action_id)[None, :], dtype=torch.float32, device=device)
        logits = self(grid_t, ctrl_t)
        return logits.argmax(dim=1).squeeze(0).cpu().numpy().astype(np.uint8)


def batch_from_records(records: list[tuple[np.ndarray, ControlCommand, np.ndarray]], schema: ControlSchema, device: str):
    grids = torch.as_tensor(np.stack([r[0] for r in records]), dtype=torch.long, device=device)
    controls = torch.as_tensor(np.stack([r[1].to_vector(schema.max_action_id) for r in records]), dtype=torch.float32, device=device)
    targets = torch.as_tensor(np.stack([r[2] for r in records]), dtype=torch.long, device=device)
    return grids, controls, targets


def pixel_ce_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return F.cross_entropy(logits, target.long())


def prediction_error_score(logits: torch.Tensor, target: torch.Tensor) -> float:
    with torch.no_grad():
        pred = logits.argmax(dim=1)
        return float((pred != target).float().mean().item())
