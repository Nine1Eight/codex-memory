from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(slots=True)
class ParsedObservation:
    grid: np.ndarray
    raw: Any = None
    terminal: bool = False
    level_complete: bool = False
    info: dict | None = None


def _nearest_resize_2d(arr: np.ndarray, size: int) -> np.ndarray:
    h, w = arr.shape[:2]
    if h == size and w == size:
        return arr.astype(np.uint8, copy=False)
    y_idx = np.clip((np.arange(size) * h / size).astype(int), 0, h - 1)
    x_idx = np.clip((np.arange(size) * w / size).astype(int), 0, w - 1)
    return arr[y_idx[:, None], x_idx[None, :]].astype(np.uint8, copy=False)


def rgb_to_palette_grid(frame: np.ndarray, num_colors: int = 16) -> np.ndarray:
    """Convert arbitrary image/frame data to stable small color indices."""
    arr = np.asarray(frame)
    if arr.ndim == 2:
        # Already a grid or grayscale.
        if arr.dtype.kind in "iu" and arr.max(initial=0) < num_colors and arr.min(initial=0) >= 0:
            return arr.astype(np.uint8)
        mn = float(np.min(arr))
        mx = float(np.max(arr))
        if mx <= mn:
            return np.zeros(arr.shape, dtype=np.uint8)
        scaled = np.floor((arr.astype(np.float32) - mn) / (mx - mn + 1e-6) * (num_colors - 1))
        return scaled.astype(np.uint8)

    if arr.ndim == 3 and arr.shape[-1] >= 3:
        rgb = arr[..., :3].astype(np.int32)
        flat = rgb.reshape(-1, 3)
        colors, inverse, counts = np.unique(flat, axis=0, return_inverse=True, return_counts=True)
        order = np.argsort(-counts)
        lut = np.zeros(len(colors), dtype=np.uint8)
        for idx, color_idx in enumerate(order[:num_colors]):
            lut[color_idx] = idx
        # Rare colors map to nearest selected frequent color.
        if len(order) > num_colors:
            selected = colors[order[:num_colors]].astype(np.float32)
            rare = order[num_colors:]
            for color_idx in rare:
                d = ((selected - colors[color_idx].astype(np.float32)) ** 2).sum(axis=1)
                lut[color_idx] = int(np.argmin(d))
        return lut[inverse].reshape(arr.shape[:2]).astype(np.uint8)

    raise ValueError(f"Unsupported observation array shape: {arr.shape}")


def extract_grid(obs: Any, grid_size: int = 64, num_colors: int = 16) -> ParsedObservation:
    """Best-effort observation parser for ARC-like wrappers.

    No game-specific fields are required; the parser only looks for generic
    pixel/grid containers and terminal/completion flags.
    """
    terminal = False
    complete = False
    info: dict | None = None
    candidate = obs

    if isinstance(obs, ParsedObservation):
        return obs

    if isinstance(obs, tuple) and obs:
        # reset may return (obs, info). Some wrappers return richer tuples.
        candidate = obs[0]
        if len(obs) >= 2 and isinstance(obs[-1], dict):
            info = obs[-1]

    if isinstance(candidate, dict):
        info = {**candidate.get("info", {}), **(info or {})} if isinstance(candidate.get("info", {}), dict) else info
        for k in ("is_terminal", "terminal", "done"):
            terminal = terminal or bool(candidate.get(k, False))
        for k in ("level_complete", "complete", "success", "won"):
            complete = complete or bool(candidate.get(k, False))
        for key in ("grid", "board", "state", "frame", "image", "pixels", "observation"):
            if key in candidate:
                candidate = candidate[key]
                break

    else:
        for k in ("is_terminal", "terminal", "done"):
            terminal = terminal or bool(getattr(candidate, k, False))
        for k in ("level_complete", "complete", "success", "won"):
            complete = complete or bool(getattr(candidate, k, False))
        for key in ("grid", "board", "state", "frame", "image", "pixels", "observation"):
            if hasattr(candidate, key):
                candidate = getattr(candidate, key)
                break

    grid = rgb_to_palette_grid(np.asarray(candidate), num_colors=num_colors)
    grid = _nearest_resize_2d(grid, grid_size)
    grid = np.clip(grid, 0, num_colors - 1).astype(np.uint8)
    return ParsedObservation(grid=grid, raw=obs, terminal=terminal, level_complete=complete, info=info)
