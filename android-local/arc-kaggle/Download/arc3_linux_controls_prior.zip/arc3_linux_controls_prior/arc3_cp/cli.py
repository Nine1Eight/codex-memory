from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import torch

from .adapter import EnvAdapter, create_mock_env
from .agent import PixelControlAgent
from .config import AgentConfig
from .dataset import TransitionRecord, TransitionWriter
from .trainer import train_offline
from .utils import import_factory, json_dump, set_seed, atomic_torch_save


def _make_env(factory_spec: str | None):
    if not factory_spec or factory_spec == "mock":
        return create_mock_env()
    fn = import_factory(factory_spec)
    return fn()


def _load_agent_checkpoint(agent: PixelControlAgent, checkpoint: str | Path | None) -> bool:
    if not checkpoint:
        return False
    p = Path(checkpoint)
    if not p.exists():
        return False
    package = torch.load(p, map_location=agent.cfg.device)
    if "model" in package:
        agent.load_state_dict_package(package)
        return True
    return False


def run_collect(args: argparse.Namespace) -> dict[str, Any]:
    set_seed(args.seed)
    env = _make_env(args.env_factory)
    adapter = EnvAdapter(env, grid_size=args.grid_size, strict=args.strict)
    cfg = AgentConfig(
        grid_size=args.grid_size,
        seed=args.seed,
        batch_size=args.batch_size,
        proposal_limit=args.proposal_limit,
        device=args.device,
    )
    agent = PixelControlAgent(adapter.schema, cfg)
    _load_agent_checkpoint(agent, args.checkpoint)

    rows = 0
    completes = 0
    with TransitionWriter(args.out) as writer:
        for ep in range(args.episodes):
            obs = adapter.reset()
            grid = obs.grid
            for step in range(args.max_steps):
                action = agent.act(grid)
                try:
                    result = adapter.step(action)
                    next_grid = result.obs.grid
                    rec = TransitionRecord.make(
                        ep, step, action, grid, next_grid,
                        terminal=result.terminal,
                        level_complete=result.level_complete,
                        reward=result.reward,
                    )
                    writer.write(rec)
                    agent.observe_transition(grid, action, next_grid)
                    if args.online_train and (rows + 1) % cfg.train_every == 0:
                        agent.train_step()
                    rows += 1
                    grid = next_grid
                    if result.level_complete:
                        completes += 1
                    if result.terminal or result.level_complete:
                        break
                except Exception as exc:
                    # Preserve failed control attempt as a no-transition error row.
                    rec = TransitionRecord.make(ep, step, action, grid, grid, terminal=True, error=repr(exc))
                    writer.write(rec)
                    rows += 1
                    if args.strict:
                        raise
                    break

    if args.checkpoint:
        atomic_torch_save(agent.state_dict_package(), args.checkpoint)
    return {"rows": rows, "episodes": args.episodes, "level_completes": completes, "out": str(args.out)}


def run_attempt(args: argparse.Namespace) -> dict[str, Any]:
    # Same as collect, but emits an action trace/submission artifact.
    set_seed(args.seed)
    env = _make_env(args.env_factory)
    adapter = EnvAdapter(env, grid_size=args.grid_size, strict=args.strict)
    cfg = AgentConfig(
        grid_size=args.grid_size,
        seed=args.seed,
        batch_size=args.batch_size,
        proposal_limit=args.proposal_limit,
        device=args.device,
        epsilon_start=args.epsilon,
    )
    agent = PixelControlAgent(adapter.schema, cfg)
    _load_agent_checkpoint(agent, args.checkpoint)

    actions: list[dict[str, Any]] = []
    rows = 0
    completed = False
    with TransitionWriter(args.transitions) as writer:
        obs = adapter.reset()
        grid = obs.grid
        for step in range(args.max_steps):
            action = agent.act(grid)
            actions.append({"step": step, "control": action.to_json()})
            try:
                result = adapter.step(action)
                next_grid = result.obs.grid
                rec = TransitionRecord.make(
                    0, step, action, grid, next_grid,
                    terminal=result.terminal,
                    level_complete=result.level_complete,
                    reward=result.reward,
                )
                writer.write(rec)
                agent.observe_transition(grid, action, next_grid)
                if args.online_train:
                    agent.train_step()
                rows += 1
                grid = next_grid
                completed = completed or result.level_complete
                if result.terminal or result.level_complete:
                    break
            except Exception as exc:
                rec = TransitionRecord.make(0, step, action, grid, grid, terminal=True, error=repr(exc))
                writer.write(rec)
                rows += 1
                if args.strict:
                    raise
                break

    if args.checkpoint:
        atomic_torch_save(agent.state_dict_package(), args.checkpoint)

    submission = {
        "schema": "arc3.controls_prior.submission_trace.v1",
        "env_factory": args.env_factory or "mock",
        "max_steps": args.max_steps,
        "completed_observed": completed,
        "actions": actions,
        "note": "Action trace only. Push with the official submission API/tooling; this runner does not fake API submission.",
    }
    if args.submission:
        json_dump(submission, args.submission)
    return {"rows": rows, "completed_observed": completed, "submission": str(args.submission) if args.submission else None}


def run_train(args: argparse.Namespace) -> dict[str, Any]:
    return train_offline(
        dataset=args.dataset,
        checkpoint=args.checkpoint,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        seed=args.seed,
        device=args.device,
    )


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="arc3cp", description="ARC3 controls-prior local trainer")
    sub = p.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--env-factory", default="mock", help="module:function returning env, or 'mock'")
    common.add_argument("--grid-size", type=int, default=64)
    common.add_argument("--max-steps", type=int, default=100)
    common.add_argument("--seed", type=int, default=918)
    common.add_argument("--batch-size", type=int, default=32)
    common.add_argument("--proposal-limit", type=int, default=48)
    common.add_argument("--device", default="cpu")
    common.add_argument("--checkpoint", default=None)
    common.add_argument("--strict", action="store_true")
    common.add_argument("--online-train", action="store_true", help="train from the same actual attempt transitions")

    c = sub.add_parser("collect", parents=[common], help="collect actual attempt transitions")
    c.add_argument("--episodes", type=int, default=5)
    c.add_argument("--out", default="runs/transitions.jsonl")
    c.set_defaults(func=run_collect)

    a = sub.add_parser("attempt", parents=[common], help="one actual winning-attempt style run")
    a.add_argument("--transitions", default="runs/attempt_transitions.jsonl")
    a.add_argument("--submission", default="runs/submission.json")
    a.add_argument("--epsilon", type=float, default=0.20)
    a.set_defaults(func=run_attempt)

    t = sub.add_parser("train", help="offline train from JSONL transitions")
    t.add_argument("--dataset", required=True)
    t.add_argument("--checkpoint", required=True)
    t.add_argument("--epochs", type=int, default=3)
    t.add_argument("--batch-size", type=int, default=32)
    t.add_argument("--lr", type=float, default=1e-3)
    t.add_argument("--seed", type=int, default=918)
    t.add_argument("--device", default="cpu")
    t.set_defaults(func=run_train)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    result = args.func(args)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
