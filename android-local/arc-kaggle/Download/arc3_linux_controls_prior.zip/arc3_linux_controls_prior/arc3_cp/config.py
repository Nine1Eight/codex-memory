from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class AgentConfig:
    grid_size: int = 64
    num_colors: int = 16
    latent_dim: int = 16
    action_embed_dim: int = 32
    lr: float = 1e-3
    batch_size: int = 32
    buffer_size: int = 20_000
    train_every: int = 1
    updates_per_train: int = 1
    epsilon_start: float = 1.0
    epsilon_end: float = 0.05
    epsilon_decay: float = 0.9975
    proposal_limit: int = 16
    seed: int = 918
    device: str = "cpu"


@dataclass(slots=True)
class RunConfig:
    episodes: int = 1
    max_steps: int = 100
    out: Path = Path("runs/transitions.jsonl")
    checkpoint: Path | None = None
    submission: Path | None = None
    strict: bool = False
