#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m arc3_cp.cli train \
  --dataset "${1:-runs/transitions.jsonl}" \
  --epochs "${EPOCHS:-3}" \
  --batch-size "${BATCH_SIZE:-32}" \
  --checkpoint "${CHECKPOINT:-runs/world_model.pt}"
