#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python -m arc3_cp.cli collect --env-factory mock --episodes 1 --max-steps 6 --out runs/smoke_transitions.jsonl --online-train --batch-size 2 --proposal-limit 8
python -m arc3_cp.cli train --dataset runs/smoke_transitions.jsonl --epochs 1 --batch-size 2 --checkpoint runs/smoke_world_model.pt
python -m arc3_cp.cli attempt --env-factory mock --max-steps 6 --checkpoint runs/smoke_world_model.pt --transitions runs/smoke_attempt.jsonl --submission runs/smoke_submission.json --online-train --batch-size 2 --proposal-limit 8
python -m compileall -q arc3_cp
