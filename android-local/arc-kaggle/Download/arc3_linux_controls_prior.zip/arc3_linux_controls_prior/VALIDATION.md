# Validation

Executed locally in the artifact workspace.

```text
$ ./scripts/smoke.sh
collect: rows=6
train: rows=6, epochs=1, checkpoint=runs/smoke_world_model.pt
attempt: rows=6, submission=runs/smoke_submission.json
```

```text
$ PYTHONPATH=. pytest -q
1 passed
```

```text
$ python -m compileall -q arc3_cp
ok
```
