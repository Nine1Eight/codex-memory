# ARC3 Linux Local — Controls-Prior Trainer

A Linux-local ARC-AGI-3 style agent runner/trainer converted from `dropin_agent_v2.py` into a modular project.

## Design contract

This project intentionally avoids game-specific strategy:

- no level-name branches
- no hardcoded mechanics
- no per-game action scripts
- no hand-authored win conditions
- no external instructions or semantic labels

Allowed prior:

- the control/action schema exposed to the agent
- generic pixel/grid structure
- generic causality from `(before, action, after)` transitions
- generic online prediction-error learning

The result is a **controls-prior trainer**: every attempted run creates transition rows, trains from observed correct/incorrect effects, and improves the world model without being told game rules.

## Layout

```text
arc3_cp/
  agent.py              PixelControlAgent: selects controls, records transitions, trains online
  adapter.py            Dynamic env adapter for ARC-like wrappers and mock envs
  cli.py                Main command line entrypoint
  config.py             Runtime config
  controls.py           Action/control schema and proposal generator
  dataset.py            JSONL transition storage
  model.py              Spatial world model with control-vector conditioning
  observations.py       Robust observation-to-grid conversion
  trainer.py            Offline trainer
  utils.py              Determinism, hashes, filesystem helpers
scripts/
  smoke.sh              End-to-end local smoke run
  train.sh              Offline train command example
tests/
  test_smoke.py         Basic tests
```

## Install

```bash
cd arc3_linux_controls_prior
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e '.[dev]'
```

Torch CPU is enough for local validation.

## Smoke run

```bash
./scripts/smoke.sh
```

This uses the included mock environment only to validate plumbing. The mock is not game logic used by the agent.

## Collect attempts

```bash
arc3cp collect \
  --env-factory my_env_module:create_env \
  --episodes 10 \
  --max-steps 80 \
  --out runs/transitions.jsonl
```

The `--env-factory` must point to a Python callable returning an environment object with reset/step behavior.

## Train offline

```bash
arc3cp train \
  --dataset runs/transitions.jsonl \
  --epochs 3 \
  --checkpoint runs/world_model.pt
```

## Actual attempt loop

```bash
arc3cp attempt \
  --env-factory my_env_module:create_env \
  --max-steps 120 \
  --checkpoint runs/world_model.pt \
  --transitions runs/attempt_transitions.jsonl \
  --submission runs/submission.json
```

Every step is both an action attempt and a training datapoint. The runner does not create separate “practice moves” unless the environment itself treats the move as part of the run.

## Adapter notes

The adapter accepts common reset/step shapes:

- Gym style: `(obs, info)` reset and `(obs, reward, done, info)` step
- Gymnasium style: `(obs, reward, terminated, truncated, info)` step
- Object wrappers exposing `grid`, `frame`, `image`, `is_terminal`, `level_complete`, etc.

If the official ARC wrapper requires custom payloads, configure the control schema rather than hardcoding game mechanics.

## Safety checks

Run:

```bash
python -m pytest -q
python -m compileall arc3_cp
```

