from pathlib import Path

from arc3_cp.cli import main


def test_collect_train_attempt(tmp_path: Path):
    ds = tmp_path / "transitions.jsonl"
    ckpt = tmp_path / "model.pt"
    attempt_ds = tmp_path / "attempt.jsonl"
    sub = tmp_path / "submission.json"

    assert main(["collect", "--env-factory", "mock", "--episodes", "1", "--max-steps", "8", "--out", str(ds), "--online-train", "--batch-size", "2"]) == 0
    assert ds.exists() and ds.stat().st_size > 0

    assert main(["train", "--dataset", str(ds), "--checkpoint", str(ckpt), "--epochs", "1", "--batch-size", "2"]) == 0
    assert ckpt.exists() and ckpt.stat().st_size > 0

    assert main(["attempt", "--env-factory", "mock", "--max-steps", "8", "--checkpoint", str(ckpt), "--transitions", str(attempt_ds), "--submission", str(sub), "--online-train", "--batch-size", "2"]) == 0
    assert attempt_ds.exists() and attempt_ds.stat().st_size > 0
    assert sub.exists() and sub.stat().st_size > 0
