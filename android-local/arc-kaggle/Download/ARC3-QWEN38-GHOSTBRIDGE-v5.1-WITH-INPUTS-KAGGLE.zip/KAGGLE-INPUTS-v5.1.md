# ARC3 v5.1 Kaggle package with required inputs

The notebook already contains Kaggle `dataSources` metadata for all four inputs. This package also includes `prepare_kaggle_kernel_package.py`, which creates a concrete `kernel-metadata.json` from the authenticated Kaggle account and can push the notebook with every input attached.

## Required sources

1. Competition: `arc-prize-2026-arc-agi-3` — source ID `133468`.
2. Dataset: `jeroencottaar/taaf-kaggle-source-share` — dataset-version ID `16761237`.
3. Dataset: `driessmit1/arc3-vllm-h100-wheelhouse-v3` — dataset-version ID `16033726`.
4. Model: `foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/pytorch/hf-fp8/1` — model-instance-version ID `966079`.

Internet must remain disabled and GPU must remain enabled. The Environment Prompt Agent 1.0.1 wheel is embedded in the notebook and is not a separate Kaggle input.

## Push with inputs

Extract the ZIP into one directory with existing Kaggle credentials, then run:

```bash
python prepare_kaggle_kernel_package.py --push
```

The script resolves the authenticated username from `KAGGLE_USERNAME` or the configured `kaggle.json`, validates the notebook hash and embedded input metadata, writes `kernel-metadata.json`, and invokes `kaggle kernels push`.

For a browser upload, upload the `.ipynb` and verify that the Kaggle Inputs panel lists exactly the competition, two datasets, and one model above before saving a version.
