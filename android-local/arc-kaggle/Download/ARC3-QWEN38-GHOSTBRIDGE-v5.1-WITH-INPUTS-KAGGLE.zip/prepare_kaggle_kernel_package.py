#!/usr/bin/env python3
"""Prepare and optionally push the ARC3 v5.1 Kaggle kernel with all inputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path


NOTEBOOK_NAME = "ARC3-QWEN38-ADL-GHOSTBRIDGE-ENVIRONMENT-PROMPT-AGENT-v5.1.ipynb"
NOTEBOOK_SHA256 = "20cc6de8a5a081586faf94d3e8d38ec8fdf2ed3cdd59417fd3a72901380b3496"
KERNEL_SLUG = "arc3-qwen38-ghostbridge-environment-prompt-agent-v51"
KERNEL_TITLE = "ARC3 Qwen3.8 ADL GhostBridge Environment Prompt Agent v5.1"

COMPETITION_SOURCES = ["arc-prize-2026-arc-agi-3"]
DATASET_SOURCES = [
    "jeroencottaar/taaf-kaggle-source-share",
    "driessmit1/arc3-vllm-h100-wheelhouse-v3",
]
MODEL_SOURCES = [
    "foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/pytorch/hf-fp8/1",
]
EXPECTED_DATA_SOURCES = [
    {"sourceType": "competition", "sourceId": 133468},
    {"sourceType": "datasetVersion", "sourceId": 16761237},
    {"sourceType": "datasetVersion", "sourceId": 16033726},
    {"sourceType": "modelInstanceVersion", "sourceId": 966079},
]


def _credential_candidates() -> list[Path]:
    candidates: list[Path] = []
    configured = os.environ.get("KAGGLE_CONFIG_DIR", "").strip()
    if configured:
        candidates.append(Path(configured).expanduser() / "kaggle.json")
    candidates.extend([
        Path.home() / ".kaggle" / "kaggle.json",
        Path.home() / ".config" / "kaggle" / "kaggle.json",
    ])
    result: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved not in seen:
            result.append(resolved)
            seen.add(resolved)
    return result


def resolve_username() -> str:
    for variable in ("KAGGLE_USERNAME", "KAGGLE_USER_NAME"):
        value = os.environ.get(variable, "").strip()
        if value:
            return validate_username(value)
    for path in _credential_candidates():
        if not path.is_file():
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Cannot read Kaggle credential file {path}: {exc}") from exc
        value = str(payload.get("username") or payload.get("user_name") or "").strip()
        if value:
            return validate_username(value)
    raise RuntimeError(
        "Kaggle username was not found. Configure ~/.kaggle/kaggle.json or set KAGGLE_USERNAME."
    )


def validate_username(value: str) -> str:
    username = value.strip().lower()
    if not re.fullmatch(r"[a-z0-9][a-z0-9_-]{1,49}", username):
        raise ValueError(f"Invalid Kaggle username format: {value!r}")
    return username


def validate_notebook(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != NOTEBOOK_SHA256:
        raise RuntimeError(
            f"Notebook SHA256 mismatch: expected {NOTEBOOK_SHA256}, found {digest}"
        )
    try:
        notebook = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Notebook is not valid UTF-8 JSON: {exc}") from exc
    kaggle_metadata = notebook.get("metadata", {}).get("kaggle", {})
    actual_sources = kaggle_metadata.get("dataSources")
    if actual_sources != EXPECTED_DATA_SOURCES:
        raise RuntimeError(
            "Notebook Kaggle dataSources differ from the required competition, datasets, and model"
        )
    if kaggle_metadata.get("isInternetEnabled") is not False:
        raise RuntimeError("Notebook must keep Kaggle internet disabled")
    if kaggle_metadata.get("isGpuEnabled") is not True:
        raise RuntimeError("Notebook must keep Kaggle GPU enabled")
    return notebook


def metadata(username: str) -> dict:
    return {
        "id": f"{username}/{KERNEL_SLUG}",
        "title": KERNEL_TITLE,
        "code_file": NOTEBOOK_NAME,
        "language": "python",
        "kernel_type": "notebook",
        "is_private": "true",
        "enable_gpu": "true",
        "enable_internet": "false",
        "dataset_sources": DATASET_SOURCES,
        "competition_sources": COMPETITION_SOURCES,
        "kernel_sources": [],
        "model_sources": MODEL_SOURCES,
    }


def prepare(directory: Path) -> Path:
    directory = directory.resolve()
    notebook_path = directory / NOTEBOOK_NAME
    validate_notebook(notebook_path)
    username = resolve_username()
    destination = directory / "kernel-metadata.json"
    temporary = destination.with_suffix(".json.tmp")
    temporary.write_text(
        json.dumps(metadata(username), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(destination)
    return destination


def push(directory: Path) -> None:
    executable = shutil.which("kaggle")
    if not executable:
        raise RuntimeError("Kaggle CLI is not installed or is not on PATH")
    subprocess.run(
        [executable, "kernels", "push", "-p", str(directory.resolve())],
        check=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--directory",
        type=Path,
        default=Path(__file__).resolve().parent,
        help="Directory containing the packaged notebook",
    )
    parser.add_argument("--push", action="store_true", help="Push after validation and metadata generation")
    args = parser.parse_args()
    metadata_path = prepare(args.directory)
    print(f"Prepared {metadata_path}")
    if args.push:
        push(args.directory)


if __name__ == "__main__":
    main()
