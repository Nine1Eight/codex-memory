# ARC-AGI-3 Termux Harness Reasoning Report

Use known sequences: `False`
Allow root alias: `False`

| Game | Won | Levels | Steps | Error |
|---|---:|---:|---:|---|
| ar25-e3c63847 | False | 0/8 | 1 |  |
| bp35-0a0ad940 | False | 0/9 | 1 |  |
| cd82-fb555c5d | False | 0/6 | 1 |  |
| cn04-65d47d14 | False | 0/5 | 1 |  |
| dc22-4c9bff3e | False | 0/6 | 1 |  |
| ft09-0d8bbf25 | False | 0/6 | 1 |  |
| g50t-5849a774 | False | 0/7 | 1 |  |
| ka59-9f096b4a | False | 0/7 | 1 |  |
| lf52-271a04aa | False | 0/10 | 1 |  |
| lp85-305b61c3 | False | 0/8 | 1 |  |
| ls20-9607627b | False | 0/7 | 1 |  |
| m0r0-dadda488 | False | 0/6 | 1 |  |
| r11l-aa269680 | False | 0/6 | 1 |  |
| re86-4e57566e | False | 0/8 | 1 |  |
| s5i5-a48e4b1d | False | 0/8 | 1 |  |
| sb26-7fbdac44 | False | 0/8 | 1 |  |
| sc25-f9b21a2f | False | 0/6 | 1 |  |
| sk48-41055498 | False | 0/8 | 1 |  |
| sp80-0ee2d095 | False | 0/6 | 1 |  |
| su15-4c352900 | False | 0/9 | 1 |  |
| tn36-ab4f63cc | False | 0/7 | 1 |  |
| tr87-cd924810 | False | 0/6 | 1 |  |
| tu93-2b534c15 | False | 0/9 | 1 |  |
| vc33-9851e02b | False | 0/7 | 1 |  |
| wa30-ee6fef47 | False | 0/9 | 1 |  |

## Notes

- This harness is for local public-game training on Termux.
- Exact known routes are diagnostic. For Kaggle generalization, prefer learned policy outputs and frame-hash-gated memories over blind route replay.
