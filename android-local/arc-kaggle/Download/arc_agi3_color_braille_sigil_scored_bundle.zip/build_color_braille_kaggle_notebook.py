#!/usr/bin/env python3
from pathlib import Path
import json, hashlib

AGENT_PATH = Path('/mnt/data/arc_agi3_color_braille_my_agent.py')
NOTEBOOK_PATH = Path('/mnt/data/arc_agi3_color_braille_sigil_scored_run.ipynb')
print("Agent:", AGENT_PATH)
print("Notebook:", NOTEBOOK_PATH)
print("Agent SHA256:", hashlib.sha256(AGENT_PATH.read_bytes()).hexdigest())
print("Notebook cells:", len(json.loads(NOTEBOOK_PATH.read_text())["cells"]))
