#!/usr/bin/env python3
"""Integrate the Qwen3.8 Environment Prompt Agent into ARC3 GhostBridge v4."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path


INTEGRATION_MARKER = "# === QWEN3.8 ENVIRONMENT PROMPT AGENT -> GHOSTBRIDGE PRE/ADL POST ==="
WHEEL_NAME = "qwen38_environment_prompt_agent-1.0.0-py3-none-any.whl"


def _source(text: str) -> list[str]:
    return text.splitlines(keepends=True)


def _integration_code(wheel_b64: str, wheel_sha256: str) -> str:
    return f'''{INTEGRATION_MARKER}
import base64
import hashlib
import json
import os
import sys
import threading
from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass
from types import MethodType
from typing import Any, Mapping

import numpy as np

ENV_PROMPT_AGENT_SCHEMA = "adldb.arc3.environment_prompt_agent.v1"
ENV_PROMPT_AGENT_MODE = "deterministic_grid_scene_graph_inline_qwen"
ENV_PROMPT_AGENT_PACKAGE_VERSION = "1.0.0"
ENV_PROMPT_AGENT_WHEEL_SHA256 = "{wheel_sha256}"
ENV_PROMPT_AGENT_CONNECTIVITY = int(os.environ.get("ARC3_ENV_PROMPT_CONNECTIVITY", "8"))
ENV_PROMPT_AGENT_MAX_OBJECTS = int(os.environ.get("ARC3_ENV_PROMPT_MAX_OBJECTS", "48"))
ENV_PROMPT_AGENT_PROMPT_LIMIT = int(os.environ.get("ARC3_ENV_PROMPT_LIMIT", "5500"))
ENV_PROMPT_AGENT_LOG = WORKING_DIR / "environment_prompt_agent_boundary_events.jsonl"
ENV_PROMPT_AGENT_LOG.unlink(missing_ok=True)

if ENV_PROMPT_AGENT_CONNECTIVITY not in {{4, 8}}:
    raise ValueError("ARC3_ENV_PROMPT_CONNECTIVITY must be 4 or 8")
if ENV_PROMPT_AGENT_MAX_OBJECTS < 1:
    raise ValueError("ARC3_ENV_PROMPT_MAX_OBJECTS must be positive")
if ENV_PROMPT_AGENT_PROMPT_LIMIT < 1200:
    raise ValueError("ARC3_ENV_PROMPT_LIMIT must be at least 1200 characters")

# The supplied pure-Python wheel is embedded so Kaggle reruns need no network,
# extra dataset mount, or recursive package installation. Adding the wheel to
# sys.path imports its schema/composer only; EnvironmentPromptAgent.analyze()
# and its Transformers backend are deliberately never instantiated.
_ENV_PROMPT_WHEEL_BYTES = base64.b64decode("""{wheel_b64}""")
if hashlib.sha256(_ENV_PROMPT_WHEEL_BYTES).hexdigest() != ENV_PROMPT_AGENT_WHEEL_SHA256:
    raise RuntimeError("Embedded Environment Prompt Agent wheel digest mismatch")
_ENV_PROMPT_ASSET_DIR = WORKING_DIR / "_embedded_assets"
_ENV_PROMPT_ASSET_DIR.mkdir(parents=True, exist_ok=True)
ENV_PROMPT_AGENT_WHEEL_PATH = _ENV_PROMPT_ASSET_DIR / "{WHEEL_NAME}"
if (
    not ENV_PROMPT_AGENT_WHEEL_PATH.is_file()
    or hashlib.sha256(ENV_PROMPT_AGENT_WHEEL_PATH.read_bytes()).hexdigest() != ENV_PROMPT_AGENT_WHEEL_SHA256
):
    _temporary_wheel = ENV_PROMPT_AGENT_WHEEL_PATH.with_suffix(".tmp")
    _temporary_wheel.write_bytes(_ENV_PROMPT_WHEEL_BYTES)
    _temporary_wheel.replace(ENV_PROMPT_AGENT_WHEEL_PATH)
if str(ENV_PROMPT_AGENT_WHEEL_PATH) not in sys.path:
    sys.path.insert(0, str(ENV_PROMPT_AGENT_WHEEL_PATH))

try:
    from environment_prompt_agent.composer import compose_prompts
    from environment_prompt_agent.fusion import audit_scene
    from environment_prompt_agent.schema import (
        BoundingBox,
        DetectedObject,
        PatternObservation,
        SceneGraph,
        SpatialRelationship,
        Uncertainty,
    )
except Exception as exc:
    raise RuntimeError(
        "Embedded Environment Prompt Agent schema/composer failed to import before gameplay"
    ) from exc


@dataclass(frozen=True)
class EnvironmentPromptDualStateKey:
    exact: str
    abstract: str


ARC_COLOR_NAMES = {{
    0: "black", 1: "blue", 2: "red", 3: "green", 4: "yellow",
    5: "gray", 6: "magenta", 7: "orange", 8: "azure", 9: "brown",
}}


def _epa_write_jsonl(payload):
    line = json.dumps(payload, sort_keys=True, ensure_ascii=False, default=str)
    with ENV_PROMPT_AGENT_LOG.open("a", encoding="utf-8") as handle:
        handle.write(line + "\\n")


class ARC3EnvironmentPromptBridge:
    """Deterministic ARC scene graph and dual-key bridge for one real trajectory."""

    def __init__(self, connectivity=8, max_objects=48, prompt_limit=5500):
        if connectivity not in {{4, 8}}:
            raise ValueError("connectivity must be 4 or 8")
        self.connectivity = int(connectivity)
        self.max_objects = int(max_objects)
        self.prompt_limit = int(prompt_limit)
        self.namespace = f"epa=1.0.0|conn={{self.connectivity}}|palette=spatial-rank-v1"
        self._cache = {{}}
        self._lock = threading.RLock()

    @staticmethod
    def _extract_candidate(value, seen=None):
        if value is None:
            return None
        if seen is None:
            seen = set()
        try:
            ident = id(value)
            if ident in seen:
                return None
            seen.add(ident)
        except Exception:
            pass
        if isinstance(value, np.ndarray):
            return value
        if isinstance(value, Mapping):
            for name in (
                "grid", "board", "frame", "pixels", "array", "data",
                "state_matrix", "current_frame", "after_frame",
            ):
                if name in value:
                    candidate = ARC3EnvironmentPromptBridge._extract_candidate(value[name], seen)
                    if candidate is not None:
                        return candidate
            return None
        if isinstance(value, (list, tuple)):
            if value and all(isinstance(row, (list, tuple, np.ndarray)) for row in value):
                return value
            return None
        if isinstance(value, str):
            rows = []
            for raw_line in value.splitlines():
                line = raw_line.strip()
                if not line:
                    continue
                parts = line.split()
                cells = parts if len(parts) > 1 else list(line)
                if cells and all(str(cell).strip().isdigit() for cell in cells):
                    rows.append(cells)
            if len(rows) >= 1 and len({{len(row) for row in rows}}) == 1:
                return rows
            return None
        for name in (
            "grid", "board", "frame", "pixels", "array", "data",
            "state_matrix", "current_frame", "after_frame",
        ):
            try:
                child = getattr(value, name)
            except Exception:
                continue
            if callable(child):
                continue
            candidate = ARC3EnvironmentPromptBridge._extract_candidate(child, seen)
            if candidate is not None:
                return candidate
        return None

    def grid(self, value):
        candidate = self._extract_candidate(value)
        if candidate is None:
            # Reuse the notebook's mature extractor when the direct route did
            # not locate a grid, but preserve this bridge's strict validation.
            try:
                candidate = _dwe_grid(value)
            except Exception:
                candidate = None
        if candidate is None:
            raise ValueError("No two-dimensional ARC grid found in current frame")
        try:
            array = np.asarray(candidate)
        except Exception as exc:
            raise ValueError("ARC frame could not be converted to a rectangular array") from exc
        if array.ndim != 2 or array.size == 0:
            raise ValueError(f"ARC grid must be non-empty and two-dimensional; shape={{array.shape}}")
        try:
            numeric = array.astype(np.int16)
        except Exception as exc:
            raise ValueError("ARC grid cells must be integer-like values in [0, 9]") from exc
        if np.any(numeric < 0) or np.any(numeric > 9):
            raise ValueError(
                f"ARC grid values must be in [0, 9]; range=[{{int(numeric.min())}},{{int(numeric.max())}}]"
            )
        if not np.all(array.astype(str) == numeric.astype(str)):
            # Accept conventional zero-padded integers but reject fractional or
            # symbolic values that merely coerce to an integer.
            for original, parsed in zip(array.ravel(), numeric.ravel()):
                text = str(original).strip()
                if not text.lstrip("+-").isdigit() or int(text) != int(parsed):
                    raise ValueError(f"ARC grid contains a non-integer cell: {{original!r}}")
        return numeric.astype(np.uint8)

    @staticmethod
    def _background(grid):
        height, width = grid.shape
        border_coords = set()
        for col in range(width):
            border_coords.add((0, col))
            border_coords.add((height - 1, col))
        for row in range(height):
            border_coords.add((row, 0))
            border_coords.add((row, width - 1))
        border_counts = Counter(int(grid[row, col]) for row, col in sorted(border_coords))
        total_counts = Counter(int(cell) for cell in grid.ravel())
        first = {{}}
        for index, cell in enumerate(grid.ravel()):
            first.setdefault(int(cell), index)
        return min(
            total_counts,
            key=lambda color: (
                -border_counts.get(color, 0),
                -total_counts[color],
                first[color],
                color,
            ),
        )

    @staticmethod
    def _palette_map(grid, background):
        mapping = {{int(background): 0}}
        next_rank = 1
        for cell in grid.ravel():
            color = int(cell)
            if color not in mapping:
                mapping[color] = next_rank
                next_rank += 1
        return mapping

    def components(self, grid):
        background = self._background(grid)
        palette = self._palette_map(grid, background)
        height, width = grid.shape
        visited = np.zeros(grid.shape, dtype=bool)
        if self.connectivity == 8:
            neighbors = (
                (-1, -1), (-1, 0), (-1, 1), (0, -1),
                (0, 1), (1, -1), (1, 0), (1, 1),
            )
        else:
            neighbors = ((-1, 0), (0, -1), (0, 1), (1, 0))
        components = []
        for row in range(height):
            for col in range(width):
                color = int(grid[row, col])
                if color == background or visited[row, col]:
                    continue
                queue = deque([(row, col)])
                visited[row, col] = True
                cells = []
                while queue:
                    rr, cc = queue.popleft()
                    cells.append((rr, cc))
                    for dr, dc in neighbors:
                        nr, nc = rr + dr, cc + dc
                        if (
                            0 <= nr < height and 0 <= nc < width
                            and not visited[nr, nc]
                            and int(grid[nr, nc]) == color
                        ):
                            visited[nr, nc] = True
                            queue.append((nr, nc))
                rows = [item[0] for item in cells]
                cols = [item[1] for item in cells]
                min_r, max_r = min(rows), max(rows)
                min_c, max_c = min(cols), max(cols)
                mask = np.zeros((max_r - min_r + 1, max_c - min_c + 1), dtype=np.uint8)
                for rr, cc in cells:
                    mask[rr - min_r, cc - min_c] = 1
                components.append({{
                    "color": color,
                    "color_rank": palette[color],
                    "cells": tuple(sorted(cells)),
                    "size": len(cells),
                    "bbox": (min_r, min_c, max_r, max_c),
                    "mask": mask,
                }})
        components.sort(key=lambda item: (item["bbox"][0], item["bbox"][1], item["color_rank"]))
        return background, palette, components

    def resolve_dual_key(self, value):
        grid = self.grid(value)
        background, _, components = self.components(grid)
        exact = hashlib.blake2b(digest_size=16)
        exact.update(
            f"{{self.namespace}}|EXACT|SHAPE:{{grid.shape[0]}}x{{grid.shape[1]}}|RAW:".encode()
        )
        exact.update(grid.tobytes())
        abstract = hashlib.blake2b(digest_size=16)
        abstract.update(
            f"{{self.namespace}}|ABSTRACT|SHAPE:{{grid.shape[0]}}x{{grid.shape[1]}}|BG:R0|".encode()
        )
        for item in components:
            min_r, min_c, max_r, max_c = item["bbox"]
            abstract.update(
                f"CR:{{item['color_rank']}}|H:{{max_r-min_r+1}}|W:{{max_c-min_c+1}}|"
                f"POS:({{min_r}},{{min_c}})|M:".encode()
            )
            abstract.update(item["mask"].tobytes())
        return EnvironmentPromptDualStateKey(exact.hexdigest(), abstract.hexdigest())

    @staticmethod
    def classify(before, after):
        exact_changed = before.exact != after.exact
        abstract_changed = before.abstract != after.abstract
        if not exact_changed and not abstract_changed:
            return "EXACT_NO_CHANGE"
        if exact_changed and not abstract_changed:
            return "COLOR_OR_PALETTE_CHANGE"
        if exact_changed and abstract_changed:
            return "STRUCTURAL_CHANGE"
        raise RuntimeError(
            "Fail-closed dual-key invariant violated: abstract changed while exact remained identical"
        )

    @staticmethod
    def _normalized_bbox(bbox, height, width):
        min_r, min_c, max_r, max_c = bbox
        return BoundingBox(
            x1=round(1000 * min_c / width),
            y1=round(1000 * min_r / height),
            x2=round(1000 * (max_c + 1) / width),
            y2=round(1000 * (max_r + 1) / height),
        )

    @staticmethod
    def _shape(item):
        mask = item["mask"]
        height, width = mask.shape
        if item["size"] == 1:
            return "single cell"
        if height == 1:
            return "horizontal line"
        if width == 1:
            return "vertical line"
        if int(mask.sum()) == height * width:
            return "filled rectangle" if height != width else "filled square"
        return "connected irregular component"

    def _scene(self, grid, dual):
        height, width = grid.shape
        background, palette, components = self.components(grid)
        total_cells = int(grid.size)
        objects = []
        for index, item in enumerate(components[: self.max_objects], start=1):
            min_r, min_c, max_r, max_c = item["bbox"]
            share = item["size"] / max(1, total_cells)
            size_relative = "small" if share < 0.05 else "medium" if share < 0.20 else "large"
            objects.append(DetectedObject(
                id=f"O{{index:03d}}",
                label=f"{{ARC_COLOR_NAMES[item['color']]}} component",
                category="ARC grid object",
                bbox=self._normalized_bbox(item["bbox"], height, width),
                confidence=1.0,
                depth="midground",
                occlusion="none",
                colors=[f"{{ARC_COLOR_NAMES[item['color']]}} ({{item['color']}})", f"palette-rank C_{{item['color_rank']}}"],
                materials=["discrete grid cells"],
                textures=["uniform categorical fill"],
                shape=self._shape(item),
                size_relative=size_relative,
                orientation="grid-aligned",
                state="observed current frame",
                distinguishing_features=[
                    f"{{item['size']}} occupied cells",
                    f"bbox rows {{min_r}}..{{max_r}}, cols {{min_c}}..{{max_c}}",
                ],
                functional_role="unresolved; visual evidence only",
                evidence=f"exact connected component under {{self.connectivity}}-connectivity",
                source_regions=["full current ARC grid"],
            ))

        relationships = []
        relation_cap = min(24, max(0, len(objects) * 2))
        for left_index, left in enumerate(objects):
            if len(relationships) >= relation_cap:
                break
            for right in objects[left_index + 1:]:
                if len(relationships) >= relation_cap:
                    break
                lx, ly = left.bbox.center
                rx, ry = right.bbox.center
                if abs(lx - rx) >= abs(ly - ry):
                    subject, predicate, target = (
                        (left, "left_of", right) if lx <= rx else (left, "right_of", right)
                    )
                else:
                    subject, predicate, target = (
                        (left, "above", right) if ly <= ry else (left, "below", right)
                    )
                relationships.append(SpatialRelationship(
                    subject_id=subject.id,
                    predicate=predicate,
                    object_id=target.id,
                    confidence=1.0,
                    evidence="deterministic component centroid order",
                ))

        counts = Counter(int(cell) for cell in grid.ravel())
        patterns = [PatternObservation(
            name="categorical occupancy",
            pattern_type="count",
            description=", ".join(
                f"{{ARC_COLOR_NAMES[color]}}({{color}})={{counts[color]}}" for color in sorted(counts)
            ),
            repeated_elements=[f"color {{color}}" for color, count in sorted(counts.items()) if count > 1],
            spatial_rule="exact full-grid frequency",
            significance="visual evidence; mechanic unresolved",
            confidence=1.0,
        )]
        symmetries = []
        if np.array_equal(grid, np.fliplr(grid)):
            symmetries.append("vertical-axis")
        if np.array_equal(grid, np.flipud(grid)):
            symmetries.append("horizontal-axis")
        if symmetries:
            patterns.append(PatternObservation(
                name="exact grid symmetry",
                pattern_type="symmetry",
                description="Current frame is exactly symmetric under " + " and ".join(symmetries),
                symmetry=", ".join(symmetries),
                spatial_rule="cellwise equality",
                significance="structural clue only",
                confidence=1.0,
            ))
        geometry_counts = Counter(
            (item["mask"].shape, item["mask"].tobytes()) for item in components
        )
        repeated_geometry = sum(1 for count in geometry_counts.values() if count > 1)
        if repeated_geometry:
            patterns.append(PatternObservation(
                name="repeated component geometry",
                pattern_type="repetition",
                description=f"{{repeated_geometry}} color-independent component shapes repeat",
                spatial_rule="tight masks compared without absolute color IDs",
                significance="candidate structural analogy",
                confidence=1.0,
            ))

        palette_order = sorted(palette, key=lambda color: palette[color])
        background_cells = counts[background]
        scene = SceneGraph(
            scene_type="ARC-AGI-3 discrete grid environment",
            summary=(
                f"{{height}}x{{width}} observed grid; background {{ARC_COLOR_NAMES[background]}}({{background}}); "
                f"{{len(components)}} foreground connected components; no mechanic inferred"
            ),
            setting="current empirical ARC game state",
            indoor_outdoor="unknown",
            architecture=["bounded rectangular cell lattice"],
            terrain_and_ground=[f"background occupies {{background_cells}}/{{total_cells}} cells"],
            background=[f"{{ARC_COLOR_NAMES[background]}} color {{background}} assigned palette-rank C_0"],
            lighting=["not applicable to categorical grid evidence"],
            color_palette=[
                f"C_{{palette[color]}}={{ARC_COLOR_NAMES[color]}}({{color}})" for color in palette_order
            ],
            dominant_textures=["discrete uniform categorical cells"],
            composition=["top-left origin", "row-major coordinates", "full frame retained"],
            camera=["orthographic full-grid observation"],
            scale_and_depth=["one cell is the atomic spatial unit", "no depth inferred"],
            objects=objects,
            relationships=relationships,
            patterns=patterns,
            activities_and_dynamics=["single current frame; dynamics require observed transitions"],
            sensory_cues=[f"exact_key={{dual.exact}}", f"palette_invariant_key={{dual.abstract}}"],
            uncertainties=[
                Uncertainty(
                    claim="object semantics and functional roles",
                    reason="not identifiable from a single categorical grid without observed causal transitions",
                    alternatives=["obstacle", "avatar", "target", "control", "decoration"],
                    confidence=0.0,
                ),
                Uncertainty(
                    claim="goal and winning mechanic",
                    reason="must be learned from current-game action/reward/score evidence",
                    alternatives=["movement", "interaction", "matching", "collection", "transformation"],
                    confidence=0.0,
                ),
            ],
            source_width=width,
            source_height=height,
        )
        return scene, components, background

    def _prompt(self, grid, dual):
        scene, components, background = self._scene(grid, dual)
        prompts = compose_prompts(scene)
        audit = audit_scene(scene)
        relationship_lines = [
            f"- {{item.subject_id}} {{item.predicate}} {{item.object_id}}"
            for item in scene.relationships[:16]
        ]
        pattern_lines = [f"- {{item.name}}: {{item.description}}" for item in scene.patterns[:8]]
        text = "\\n".join([
            "ENVIRONMENT_PROMPT_AGENT_PRE (empirical current frame; no extra model call/action)",
            f"schema={{ENV_PROMPT_AGENT_SCHEMA}} mode={{ENV_PROMPT_AGENT_MODE}} package={{ENV_PROMPT_AGENT_PACKAGE_VERSION}}",
            f"grid={{grid.shape[0]}}x{{grid.shape[1]}} connectivity={{self.connectivity}} background={{background}}",
            f"exact_state_key={{dual.exact}}",
            f"palette_invariant_state_key={{dual.abstract}}",
            f"scene_summary={{scene.summary}}",
            f"quality_score={{audit.overall_quality_score:.4f}} objects={{audit.object_count}} relationships={{audit.relationship_count}} patterns={{audit.pattern_count}}",
            "OBJECT_INVENTORY:",
            prompts.object_inventory,
            "RELATIONSHIPS:",
            *(relationship_lines or ["- none established"]),
            "PATTERNS:",
            *(pattern_lines or ["- none established"]),
            "NEGATIVE_SPACE:",
            f"- {{int(np.sum(grid == background))}} background cells are explicitly unoccupied by segmented foreground components",
            "UNCERTAINTY_GUARDRAIL:",
            prompts.uncertainty_guardrail,
            "CONTRACT: Treat exact keys/observed components as evidence. Treat palette-invariant analogy as a testable hypothesis only. "
            "Do not infer hidden source logic, do not create an extra environment action, and validate any abstract bridge on the next committed transition.",
        ])
        if len(text) > self.prompt_limit:
            text = text[: self.prompt_limit - 80].rstrip() + "\\n[ENVIRONMENT_PROMPT_AGENT_PRE TRUNCATED]"
        return text, scene, audit, len(components), background

    def context(self, *, game_id, move, current_frame):
        grid = self.grid(current_frame)
        dual = self.resolve_dual_key(grid)
        cache_key = (str(game_id or "unknown"), int(move))
        with self._lock:
            cached = self._cache.get(cache_key)
            if cached is not None:
                if cached["dual"].exact != dual.exact:
                    raise RuntimeError(
                        f"Environment Prompt Agent frame changed during analyzer retry game={{game_id}} move={{move}}"
                    )
                return cached["prompt"]
            prompt, scene, audit, component_count, background = self._prompt(grid, dual)
            self._cache[cache_key] = {{"prompt": prompt, "dual": dual}}
            _epa_write_jsonl({{
                "schema": ENV_PROMPT_AGENT_SCHEMA,
                "phase": "PRE_CONTEXT",
                "game_id": str(game_id),
                "move": int(move),
                "exact_key": dual.exact,
                "abstract_key": dual.abstract,
                "grid_shape": list(grid.shape),
                "background": int(background),
                "object_count_total": int(component_count),
                "object_count_prompted": int(len(scene.objects)),
                "quality_audit": audit.model_dump(),
                "wheel_sha256": ENV_PROMPT_AGENT_WHEEL_SHA256,
                "package_version": ENV_PROMPT_AGENT_PACKAGE_VERSION,
                "extra_model_calls": 0,
                "extra_environment_actions": 0,
                "source_code_read": False,
            }})
            return prompt

    def transition_evidence(self, before, after):
        before_key = self.resolve_dual_key(before)
        after_key = self.resolve_dual_key(after)
        return {{
            "schema": ENV_PROMPT_AGENT_SCHEMA,
            "before": asdict(before_key),
            "after": asdict(after_key),
            "transition_type": self.classify(before_key, after_key),
            "requires_exact_validation": before_key.abstract == after_key.abstract and before_key.exact != after_key.exact,
            "extra_model_calls": 0,
            "extra_environment_actions": 0,
            "source_code_read": False,
        }}


ENVIRONMENT_PROMPT_BRIDGE = ARC3EnvironmentPromptBridge(
    connectivity=ENV_PROMPT_AGENT_CONNECTIVITY,
    max_objects=ENV_PROMPT_AGENT_MAX_OBJECTS,
    prompt_limit=ENV_PROMPT_AGENT_PROMPT_LIMIT,
)

# Catch the johnny5 residual before any game object or action exists.
_ENV_PROMPT_DWE_SUMMARY_PREFLIGHT = DWE_ALLOCATOR.summaries()
if not isinstance(_ENV_PROMPT_DWE_SUMMARY_PREFLIGHT, list):
    raise RuntimeError("DWE summaries preflight did not return a list")

# Outermost GhostBridge wrapper: environment_files + causal memory remain the
# base brief; the scene graph is appended exactly once per pending move.
_ENV_PROMPT_GHOSTBRIDGE_BRIEF_ORIGINAL = _ghostbridge_premove_brief


def _ghostbridge_premove_brief(*, game_id, action_num, valid_actions, current_frame, previous_step_summary):
    base = _ENV_PROMPT_GHOSTBRIDGE_BRIEF_ORIGINAL(
        game_id=game_id,
        action_num=action_num,
        valid_actions=valid_actions,
        current_frame=current_frame,
        previous_step_summary=previous_step_summary,
    )
    move = int(DWE_ALLOCATOR.state(game_id).move) + 1
    context = ENVIRONMENT_PROMPT_BRIDGE.context(
        game_id=game_id,
        move=move,
        current_frame=current_frame,
    )
    return str(base) + "\\n\\n" + context


# ADL POST receives the same dual identity after the real transition. Errors
# are recorded without dropping the underlying causal-memory POST transaction;
# the final invariant then fails closed on any incomplete evidence.
_ENV_PROMPT_MEMORY_UPDATE_ORIGINAL = PERSISTENT_CAUSAL_MEMORY.update


def _environment_prompt_memory_update(self, game_id, action, before, after, event, result):
    event = dict(event) if isinstance(event, Mapping) else {{"raw_event": str(event)}}
    try:
        evidence = ENVIRONMENT_PROMPT_BRIDGE.transition_evidence(
            before.get("grid") if isinstance(before, Mapping) else before,
            after.get("grid") if isinstance(after, Mapping) else after,
        )
    except Exception as exc:
        evidence = {{
            "schema": ENV_PROMPT_AGENT_SCHEMA,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "extra_model_calls": 0,
            "extra_environment_actions": 0,
            "source_code_read": False,
        }}
    event["environment_prompt_agent"] = evidence
    payload = _ENV_PROMPT_MEMORY_UPDATE_ORIGINAL(game_id, action, before, after, event, result)
    _epa_write_jsonl({{
        "schema": ENV_PROMPT_AGENT_SCHEMA,
        "phase": "POST_CONTEXT",
        "game_id": str(game_id),
        "move": int(payload.get("move", event.get("move", -1))),
        "action": str(action),
        "evidence": evidence,
        "wheel_sha256": ENV_PROMPT_AGENT_WHEEL_SHA256,
        "package_version": ENV_PROMPT_AGENT_PACKAGE_VERSION,
        "extra_model_calls": 0,
        "extra_environment_actions": 0,
        "source_code_read": False,
    }})
    return payload


PERSISTENT_CAUSAL_MEMORY.update = MethodType(
    _environment_prompt_memory_update,
    PERSISTENT_CAUSAL_MEMORY,
)

print(
    "QWEN3.8 ENVIRONMENT PROMPT AGENT BRIDGE READY "
    f"mode={{ENV_PROMPT_AGENT_MODE}} package={{ENV_PROMPT_AGENT_PACKAGE_VERSION}} "
    f"connectivity={{ENV_PROMPT_AGENT_CONNECTIVITY}} extra_model_calls=0 extra_environment_actions=0 "
    f"dwe_summary_preflight=pass wheel_sha256={{ENV_PROMPT_AGENT_WHEEL_SHA256}}",
    flush=True,
)
'''


def _replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"Expected one {label} insertion point, found {count}")
    return text.replace(old, new, 1)


def integrate(baseline: Path, wheel: Path, output: Path) -> dict:
    notebook = json.loads(baseline.read_text(encoding="utf-8"))
    wheel_bytes = wheel.read_bytes()
    wheel_sha256 = hashlib.sha256(wheel_bytes).hexdigest()
    wheel_b64 = base64.b64encode(wheel_bytes).decode("ascii")

    if any(INTEGRATION_MARKER in "".join(cell.get("source", [])) for cell in notebook["cells"]):
        raise RuntimeError("Notebook already contains the Environment Prompt Agent integration")

    insertion_index = next(
        index
        for index, cell in enumerate(notebook["cells"])
        if cell.get("cell_type") == "markdown"
        and "## 8. Run exactly one real competition trajectory per game" in "".join(cell.get("source", []))
    )
    markdown = "## 7.3 Qwen3.8 Environment Prompt Agent bridge\n\n"
    markdown += (
        "Embed the supplied validated wheel and reuse its strict scene-graph schema, prompt composer, and quality auditor as a deterministic ARC-grid preprocessor. "
        "The bridge adds exact and palette-invariant state keys to GhostBridge PRE and ADL POST while preserving the one-real-action contract. "
        "It does **not** instantiate the package's Transformers backend: the existing Qwen3.8 analyzer receives the compact scene context in its normal prompt, so the integration adds zero model loads, zero model calls, and zero environment actions.\n"
    )
    notebook["cells"][insertion_index:insertion_index] = [
        {"cell_type": "markdown", "metadata": {}, "source": _source(markdown)},
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {"tags": ["ghostbridge", "environment-prompt-agent", "fail-closed"]},
            "outputs": [],
            "source": _source(_integration_code(wheel_b64, wheel_sha256)),
        },
    ]

    # Update the title/workflow without changing any scored control settings.
    title = "".join(notebook["cells"][0]["source"])
    title = title.replace(
        "# ARC-AGI-3 Qwen3.8 — definitive ADL / GhostBridge / RHAE pipeline",
        "# ARC-AGI-3 Qwen3.8 — ADL / GhostBridge / Environment Prompt Agent / RHAE pipeline",
    )
    title = title.replace(
        "public environment context → temporal observation → GhostBridge PRE",
        "public environment context → deterministic scene graph + dual state keys → temporal observation → GhostBridge PRE",
    )
    notebook["cells"][0]["source"] = _source(title)

    run_index = next(
        index
        for index, cell in enumerate(notebook["cells"])
        if cell.get("cell_type") == "code"
        and "# === ONE-ENVIRONMENT COMPETITION/LOCAL EXECUTION ===" in "".join(cell.get("source", []))
    )
    run_code = "".join(notebook["cells"][run_index]["source"])
    manifest_anchor = '    "environment_files_source_code_read": False,\n'
    manifest_addition = manifest_anchor + (
        '    "environment_prompt_agent_enabled": True,\n'
        '    "environment_prompt_agent_mode": ENV_PROMPT_AGENT_MODE,\n'
        '    "environment_prompt_agent_package_version": ENV_PROMPT_AGENT_PACKAGE_VERSION,\n'
        '    "environment_prompt_agent_wheel_sha256": ENV_PROMPT_AGENT_WHEEL_SHA256,\n'
        '    "environment_prompt_agent_log": str(ENV_PROMPT_AGENT_LOG),\n'
        '    "environment_prompt_agent_connectivity": ENV_PROMPT_AGENT_CONNECTIVITY,\n'
        '    "environment_prompt_agent_exact_and_palette_invariant_keys": True,\n'
        '    "environment_prompt_agent_extra_model_loads": 0,\n'
        '    "environment_prompt_agent_extra_model_calls": 0,\n'
        '    "environment_prompt_agent_extra_environment_actions": 0,\n'
        '    "environment_prompt_agent_source_code_read": False,\n'
    )
    run_code = _replace_once(run_code, manifest_anchor, manifest_addition, "run-manifest")
    notebook["cells"][run_index]["source"] = _source(run_code)

    final_index = next(
        index
        for index, cell in enumerate(notebook["cells"])
        if cell.get("cell_type") == "code"
        and "# === PUBLIC CONTROL / CAUSAL MEMORY v4 / GHOSTBRIDGE FINAL INVARIANT AUDIT ===" in "".join(cell.get("source", []))
    )
    final_code = "".join(notebook["cells"][final_index]["source"])
    records_anchor = '_envfiles_records = _audit_jsonl(ENVIRONMENT_FILES_USAGE_LOG, "environment-files-context")\n'
    records_addition = records_anchor + '_epa_records = _audit_jsonl(ENV_PROMPT_AGENT_LOG, "environment-prompt-agent")\n'
    final_code = _replace_once(final_code, records_anchor, records_addition, "final-audit records")

    keys_anchor = '''_envfiles_post = {
    _norm_pair((x.get("game_id"), x.get("move", -1)))
    for x in _envfiles_records if x.get("phase") == "POST_CONTEXT"
}
'''
    keys_addition = keys_anchor + '''_epa_pre = {
    _norm_pair((x.get("game_id"), x.get("move", -1)))
    for x in _epa_records if x.get("phase") == "PRE_CONTEXT"
}
_epa_post = {
    _norm_pair((x.get("game_id"), x.get("move", -1)))
    for x in _epa_records if x.get("phase") == "POST_CONTEXT"
}
'''
    final_code = _replace_once(final_code, keys_anchor, keys_addition, "environment-prompt keys")

    equality_anchor = '    ("environment_files ADL POST", _envfiles_post),\n'
    equality_addition = equality_anchor + (
        '    ("Environment Prompt Agent GhostBridge PRE", _epa_pre),\n'
        '    ("Environment Prompt Agent ADL POST", _epa_post),\n'
    )
    final_code = _replace_once(final_code, equality_anchor, equality_addition, "equality set")

    duplicate_anchor = '''if len(_envfiles_records) != len(_envfiles_pre) + len(_envfiles_post):
    raise RuntimeError(
        f"Duplicate/unknown environment_files records: rows={len(_envfiles_records)} "
        f"pre={len(_envfiles_pre)} post={len(_envfiles_post)}"
    )
'''
    duplicate_addition = duplicate_anchor + '''if len(_epa_records) != len(_epa_pre) + len(_epa_post):
    raise RuntimeError(
        f"Duplicate/unknown Environment Prompt Agent records: rows={len(_epa_records)} "
        f"pre={len(_epa_pre)} post={len(_epa_post)}"
    )
for _epa_record in _epa_records:
    if _epa_record.get("extra_model_calls") != 0 or _epa_record.get("extra_environment_actions") != 0:
        raise RuntimeError("Environment Prompt Agent violated zero-extra-call/action contract")
    if _epa_record.get("source_code_read") is not False:
        raise RuntimeError("Environment Prompt Agent reports environment source-code access")
    if _epa_record.get("wheel_sha256") != ENV_PROMPT_AGENT_WHEEL_SHA256:
        raise RuntimeError("Environment Prompt Agent wheel identity changed during scored run")
    if _epa_record.get("phase") == "POST_CONTEXT":
        _evidence = _epa_record.get("evidence") or {}
        if _evidence.get("error") or not _evidence.get("transition_type"):
            raise RuntimeError(
                f"Incomplete Environment Prompt Agent POST evidence: "
                f"{_epa_record.get('game_id')} move={_epa_record.get('move')}"
            )
'''
    final_code = _replace_once(final_code, duplicate_anchor, duplicate_addition, "duplicate audit")

    cm_anchor = '''    if _environment_context.get("source_code_read") is not False:
        raise RuntimeError("Environment implementation source entered the scored causal-memory path")
'''
    cm_addition = cm_anchor + '''    _prompt_context = (_record.get("event") or {}).get("environment_prompt_agent")
    if not isinstance(_prompt_context, dict) or not _prompt_context.get("transition_type"):
        raise RuntimeError(
            f"Causal-memory event lacks Environment Prompt Agent dual-key evidence: "
            f"{_record.get('game_id')} move={_record.get('move')}"
        )
    if _prompt_context.get("source_code_read") is not False:
        raise RuntimeError("Environment Prompt Agent source-code guard failed in causal memory")
'''
    final_code = _replace_once(final_code, cm_anchor, cm_addition, "causal-memory evidence")

    print_anchor = '    f"environment_files_post={len(_envfiles_post)} adl_debt={max(0, _committed_actions-len(_adl_norm))} "\n'
    print_addition = (
        '    f"environment_files_post={len(_envfiles_post)} environment_prompt_pre={len(_epa_pre)} "\n'
        '    f"environment_prompt_post={len(_epa_post)} environment_prompt_extra_actions=0 "\n'
        '    f"environment_prompt_extra_model_calls=0 adl_debt={max(0, _committed_actions-len(_adl_norm))} "\n'
    )
    final_code = _replace_once(final_code, print_anchor, print_addition, "completion print")
    notebook["cells"][final_index]["source"] = _source(final_code)

    metadata = notebook.setdefault("metadata", {})
    metadata["title"] = "ARC3 Qwen3.8 ADL GhostBridge Environment Prompt Agent v5"
    metadata["environment_prompt_agent"] = {
        "enabled": True,
        "mode": "deterministic_grid_scene_graph_inline_qwen",
        "package_version": "1.0.0",
        "wheel_sha256": wheel_sha256,
        "extra_model_loads": 0,
        "extra_model_calls": 0,
        "extra_environment_actions": 0,
    }
    for cell in notebook["cells"]:
        if cell.get("cell_type") == "code":
            cell["execution_count"] = None
            cell["outputs"] = []

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(notebook, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    return {
        "schema": "adldb.arc3.environment_prompt_agent.integration_report.v1",
        "baseline": str(baseline),
        "output": str(output),
        "cell_count": len(notebook["cells"]),
        "wheel": str(wheel),
        "wheel_sha256": wheel_sha256,
        "wheel_embedded": True,
        "extra_model_loads": 0,
        "extra_model_calls": 0,
        "extra_environment_actions": 0,
        "integration_marker": INTEGRATION_MARKER,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    report = integrate(args.baseline, args.wheel, args.output)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
