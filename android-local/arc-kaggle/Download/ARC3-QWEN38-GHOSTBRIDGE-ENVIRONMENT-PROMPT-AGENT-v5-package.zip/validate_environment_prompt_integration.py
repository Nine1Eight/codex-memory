#!/usr/bin/env python3
"""Static and synthetic validation for the integrated ARC3 notebook."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import tempfile
from pathlib import Path

import numpy as np


MARKER = "# === QWEN3.8 ENVIRONMENT PROMPT AGENT -> GHOSTBRIDGE PRE/ADL POST ==="
EXPECTED_WHEEL_SHA256 = "560cdd2e82b853256a8e0c21fb7c92c0d58b308d4412c101af85d15f9ea68be4"


class _State:
    move = 0


class _Allocator:
    def state(self, game_id):
        return _State()

    def summaries(self):
        return []


class _Memory:
    def __init__(self):
        self.events = []

    def update(self, game_id, action, before, after, event, result):
        self.events.append(event)
        return {"move": int(event.get("move", 1)), "event": event}


def _base_brief(**kwargs):
    return "BASE_GHOSTBRIDGE_PRE"


def _dwe_grid(value):
    if isinstance(value, dict):
        for key in ("grid", "frame", "board", "current_frame", "after_frame"):
            if key in value:
                return _dwe_grid(value[key])
    return value


def _read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def validate(notebook_path: Path, report_path: Path) -> dict:
    notebook = json.loads(notebook_path.read_text(encoding="utf-8"))
    integration_cells = [
        cell
        for cell in notebook["cells"]
        if cell.get("cell_type") == "code" and MARKER in "".join(cell.get("source", []))
    ]
    assert len(integration_cells) == 1, f"expected one integration cell, found {len(integration_cells)}"
    integration_code = "".join(integration_cells[0]["source"])
    ast.parse(integration_code)

    full_text = "\n".join("".join(cell.get("source", [])) for cell in notebook["cells"])
    required_markers = {
        "embedded_wheel": "_ENV_PROMPT_WHEEL_BYTES = base64.b64decode",
        "wheel_digest": f'ENV_PROMPT_AGENT_WHEEL_SHA256 = "{EXPECTED_WHEEL_SHA256}"',
        "scene_composer": "compose_prompts(scene)",
        "scene_audit": "audit_scene(scene)",
        "dual_key": "palette_invariant_state_key=",
        "ghostbridge_wrapper": "_ENV_PROMPT_GHOSTBRIDGE_BRIEF_ORIGINAL",
        "adl_post_wrapper": "_environment_prompt_memory_update",
        "dwe_summary_preflight": "DWE_ALLOCATOR.summaries()",
        "manifest_zero_actions": '"environment_prompt_agent_extra_environment_actions": 0',
        "manifest_zero_model_calls": '"environment_prompt_agent_extra_model_calls": 0',
        "final_pre_equality": '("Environment Prompt Agent GhostBridge PRE", _epa_pre)',
        "final_post_equality": '("Environment Prompt Agent ADL POST", _epa_post)',
    }
    missing = [name for name, marker in required_markers.items() if marker not in full_text]
    assert not missing, f"missing integration markers: {missing}"
    assert "EnvironmentPromptAgent(" not in integration_code
    assert "TransformersBackend(" not in integration_code
    assert all(not cell.get("outputs") for cell in notebook["cells"] if cell.get("cell_type") == "code")
    assert all(cell.get("execution_count") is None for cell in notebook["cells"] if cell.get("cell_type") == "code")

    component_cells = [
        "".join(cell.get("source", []))
        for cell in notebook["cells"]
        if cell.get("cell_type") == "code"
        and (
            "COMPONENT CONTRACTS READY" in "".join(cell.get("source", []))
            or "RHAE CONTROL TUNING COMPLETE" in "".join(cell.get("source", []))
        )
    ]
    assert len(component_cells) == 2
    component_namespace: dict = {}
    for source in component_cells:
        exec(compile(source, "<baseline-component-contract>", "exec"), component_namespace)
    assert component_namespace["PRE_TUNE_SELF_TESTS"]["passed"] == 7
    assert component_namespace["PRE_TUNE_SELF_TESTS"]["failed"] == 0
    assert component_namespace["POST_TUNE_SELF_TESTS"]["passed"] == 7
    assert component_namespace["POST_TUNE_SELF_TESTS"]["failed"] == 0
    assert component_namespace["TUNED_CONTROL_CONFIG"] == {
        "soft_stall": 6,
        "hard_stall": 12,
        "success_protect": 18,
        "no_impact_threshold": 0.75,
        "no_impact_streak": 3,
        "zero_score_triage": 24,
    }
    assert component_namespace["CONTROL_TUNING"]["selected_objective"] == 90.0

    with tempfile.TemporaryDirectory(prefix="arc3-epa-validation-") as temporary:
        working = Path(temporary)
        memory = _Memory()
        namespace = {
            "WORKING_DIR": working,
            "DWE_ALLOCATOR": _Allocator(),
            "PERSISTENT_CAUSAL_MEMORY": memory,
            "_ghostbridge_premove_brief": _base_brief,
            "_dwe_grid": _dwe_grid,
        }
        exec(compile(integration_code, "<environment-prompt-integration>", "exec"), namespace)

        bridge = namespace["ENVIRONMENT_PROMPT_BRIDGE"]
        original = np.array([
            [0, 0, 0, 0],
            [0, 1, 1, 0],
            [0, 1, 1, 0],
            [0, 0, 0, 0],
        ], dtype=np.uint8)
        palette_swap = np.array([
            [4, 4, 4, 4],
            [4, 2, 2, 4],
            [4, 2, 2, 4],
            [4, 4, 4, 4],
        ], dtype=np.uint8)
        moved = np.array([
            [0, 1, 1, 0],
            [0, 1, 1, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
        ], dtype=np.uint8)

        key_original = bridge.resolve_dual_key(original)
        key_swap = bridge.resolve_dual_key(palette_swap)
        key_moved = bridge.resolve_dual_key(moved)
        assert key_original.exact != key_swap.exact
        assert key_original.abstract == key_swap.abstract
        assert bridge.classify(key_original, key_swap) == "COLOR_OR_PALETTE_CHANGE"
        assert bridge.classify(key_original, key_moved) == "STRUCTURAL_CHANGE"

        prompt_a = namespace["_ghostbridge_premove_brief"](
            game_id="test-game",
            action_num=1,
            valid_actions=["UP", "DOWN"],
            current_frame=original,
            previous_step_summary=None,
        )
        prompt_b = namespace["_ghostbridge_premove_brief"](
            game_id="test-game",
            action_num=1,
            valid_actions=["UP", "DOWN"],
            current_frame=original.copy(),
            previous_step_summary=None,
        )
        assert prompt_a == prompt_b
        assert "BASE_GHOSTBRIDGE_PRE" in prompt_a
        assert "ENVIRONMENT_PROMPT_AGENT_PRE" in prompt_a
        assert "palette_invariant_state_key=" in prompt_a

        namespace["PERSISTENT_CAUSAL_MEMORY"].update(
            "test-game",
            "UP",
            {"grid": original},
            {"grid": moved},
            {"move": 1},
            None,
        )
        rows = _read_jsonl(working / "environment_prompt_agent_boundary_events.jsonl")
        pre = [row for row in rows if row.get("phase") == "PRE_CONTEXT"]
        post = [row for row in rows if row.get("phase") == "POST_CONTEXT"]
        assert len(pre) == 1
        assert len(post) == 1
        assert post[0]["evidence"]["transition_type"] == "STRUCTURAL_CHANGE"
        assert all(row["extra_model_calls"] == 0 for row in rows)
        assert all(row["extra_environment_actions"] == 0 for row in rows)
        assert all(row["wheel_sha256"] == EXPECTED_WHEEL_SHA256 for row in rows)

        wheel_path = Path(namespace["ENV_PROMPT_AGENT_WHEEL_PATH"])
        assert hashlib.sha256(wheel_path.read_bytes()).hexdigest() == EXPECTED_WHEEL_SHA256

    report = {
        "schema": "adldb.arc3.environment_prompt_agent.validation.v1",
        "status": "PASS",
        "notebook": str(notebook_path),
        "cell_count": len(notebook["cells"]),
        "integration_cell_count": len(integration_cells),
        "required_markers": required_markers,
        "synthetic_tests": {
            "baseline_pre_tune_components_7_of_7": "PASS",
            "baseline_post_tune_components_7_of_7": "PASS",
            "baseline_selected_objective_90": "PASS",
            "embedded_wheel_import": "PASS",
            "palette_swap_exact_diff_abstract_equal": "PASS",
            "structural_movement_dual_key": "PASS",
            "ghostbridge_retry_exactly_once": "PASS",
            "adl_post_dual_key_evidence": "PASS",
            "zero_extra_model_calls": "PASS",
            "zero_extra_environment_actions": "PASS",
            "cleared_outputs": "PASS",
        },
        "selected_control_config": component_namespace["TUNED_CONTROL_CONFIG"],
        "selected_synthetic_objective": component_namespace["CONTROL_TUNING"]["selected_objective"],
        "wheel_sha256": EXPECTED_WHEEL_SHA256,
        "gateway_execution": "NOT_RUN",
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--notebook", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    report = validate(args.notebook, args.report)
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
