# ARC3 Qwen3.8 GhostBridge Environment Prompt Agent v5

This package integrates the supplied `qwen38_environment_prompt_agent-1.0.0` wheel into the validated ARC3 Qwen3.8 ADL/GhostBridge v4 notebook.

## Primary artifact

`ARC3-QWEN38-ADL-GHOSTBRIDGE-ENVIRONMENT-PROMPT-AGENT-v5.ipynb`

Upload the notebook to Kaggle with the same ARC-AGI-3, TAAF, offline wheelhouse, and Qwen3.8-27B-FP8 model inputs used by the v4 lineage. The Environment Prompt Agent wheel is embedded in the notebook, so it does not require another dataset mount or network install.

## Integration behavior

- Reuses the package's `SceneGraph`, prompt composer, and quality audit.
- Builds the scene graph deterministically from the current ARC grid.
- Produces both exact and palette-invariant BLAKE2b state keys.
- Appends compact object, relationship, pattern, negative-space, and uncertainty evidence to GhostBridge PRE.
- Attaches before/after dual keys and transition classification to ADL/causal-memory POST.
- Extends the final equality audit with Environment Prompt Agent PRE and POST ledgers.
- Runs `DWE_ALLOCATOR.summaries()` before gameplay to catch the historical `NO_IMPACT_BAND_WINDOW` summary-path regression.
- Adds zero model loads, zero model calls, and zero environment actions. The existing Qwen3.8 analyzer remains the only heavyweight model.

Palette-invariant evidence is a hypothesis plane only. Exact observed keys remain authoritative, and no Twin prediction is promoted to empirical evidence without the next live committed transition.

## Validation

Local validation passed:

- Environment Prompt Agent package regression tests: 11/11.
- Baseline component contracts: 7/7 before tuning and 7/7 after tuning.
- Tuned synthetic objective: 90.0.
- Selected controls preserved: hard stall 12, soft stall 6, no-impact threshold 0.75, success protect 18, no-impact streak 3, zero-score triage 24.
- Integrated notebook syntax: 21/21 code cells.
- Embedded wheel import and SHA-256 verification.
- Palette-swap exact-different/abstract-equal test.
- Structural movement dual-key test.
- GhostBridge analyzer-retry exactly-once logging.
- ADL POST dual-key evidence.
- Cleared notebook outputs.

The real Kaggle competition gateway/GPU run was not available locally. Do not claim a new score from this package until a rerun reaches `TRUE SCORED RUN COMPLETE`, writes and reads back `submission.parquet`, and satisfies the extended PRE/POST equality invariant.

## Included support files

- `validation-report.json` — local static and synthetic results.
- `integration-report.json` — source/output and embedded-wheel identity.
- `qwen38_environment_prompt_agent-1.0.0-py3-none-any.whl` — original validated wheel, also embedded in the notebook.
- `integrate_environment_prompt_agent.py` — deterministic notebook builder.
- `validate_environment_prompt_integration.py` — local integration validator.
- `memory.codex` — updated ARC3 lineage, constraints, and v5 handoff record.
