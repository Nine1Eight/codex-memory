# Agent Security Notebook Corpus

A competition-scoped pipeline for turning **public Kaggle notebooks** from
`ai-agent-security-multi-step-tool-attacks` into a provenance-preserving
training corpus and lightweight strategy-selection agent.

This project deliberately separates:

1. notebook discovery,
2. immutable snapshotting,
3. cell/code normalization,
4. strategy extraction,
5. dataset creation,
6. portfolio scoring,
7. model training.

It does **not** target arbitrary third-party systems. The default configuration
is locked to the Kaggle competition slug above.

## What it builds

```text
Kaggle public notebooks
        |
        v
discover -> snapshot -> normalize -> extract -> build-dataset -> train
                                                   |
                                                   v
                                        strategy portfolio
                                                   |
                                                   v
                                          selector model
```

Output:

```text
workspace/
├── discovered/notebooks.jsonl
├── raw/<owner>/<slug>/
├── normalized/records.jsonl
├── corpus/
│   ├── strategies.jsonl
│   ├── sft.jsonl
│   ├── preference.jsonl
│   └── manifest.json
├── portfolio/portfolio.json
└── models/strategy_selector.json
```

## Requirements

- Python 3.11+
- Kaggle CLI (`pip install kaggle`)
- Kaggle authentication configured with one of Kaggle's supported methods.

Join the competition and accept its rules before using competition resources.

## Install

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Fast start

```bash
agentsec doctor

agentsec discover \
  --top 50 \
  --sort scoreDescending

agentsec snapshot

agentsec normalize
agentsec extract
agentsec build-dataset
agentsec train
agentsec report
```

Or:

```bash
agentsec pipeline --top 50
```

## Why the corpus is better than copying notebooks

The pipeline stores provenance but trains from normalized records such as:

```json
{
  "source_ref": "owner/notebook",
  "cell_index": 17,
  "kind": "planning",
  "signals": ["tool-selection", "retry", "score-feedback"],
  "features": {
    "tool_call_terms": 4,
    "branch_terms": 2,
    "retry_terms": 3
  }
}
```

These are aggregated into a strategy portfolio. The selector learns which
strategy families are most associated with stronger public notebook scores,
while preserving source boundaries so train/eval splits do not leak cells from
the same notebook into both sides.

## Competition scope guard

`agentsec` is pinned by default to:

```text
ai-agent-security-multi-step-tool-attacks
```

If a different competition slug is supplied, the CLI refuses to run unless the
source code is deliberately changed. This keeps the collector tied to the
competition workflow it was built for.

## Notes on notebook score

Kaggle's `kernels list` supports `--sort-by scoreDescending`. The collector
records whatever public score metadata Kaggle returns. Missing scores are kept
as null rather than invented.

## License / provenance

Public does not necessarily mean unrestricted. Every snapshot gets a metadata
record and SHA-256 hashes. Before redistributing notebook-derived text/code,
verify the source notebook's license and competition rules. The generated
training corpus can be configured to keep only structural labels and features
instead of copied code.


## Observable trajectory learning

The second-stage pipeline converts observable execution behavior into multi-step training trajectories. It does not invent hidden reasoning. It learns from saved notebook outputs and explicit JSONL traces: observations, candidates, selected actions/tool calls, tool results, rewards, and terminal outcomes.

```bash
agentsec extract-events
agentsec reconstruct-episodes
agentsec build-trajectories --min-quality 0.25
agentsec train-trajectory-policy
```

For high-quality traces:

```bash
agentsec ingest-trace examples/sample_trace.jsonl
agentsec reconstruct-episodes
agentsec build-trajectories --min-quality 0
agentsec train-trajectory-policy
agentsec rank-actions --observation "More evidence is needed."
```

Generated files include `events.jsonl`, `episodes.jsonl`, `trajectory_sft.jsonl`, `trajectory_preferences.jsonl`, `replay.jsonl`, and `trajectory_manifest.json`. Downloaded notebooks are treated as untrusted code: the repo parses saved outputs but does not automatically execute arbitrary notebook code. Fresh executions should be run in a separately reviewed/sandboxed environment and exported as canonical JSONL traces.

## Difference learning across notebook versions

The agent learns from **what changed between notebook versions**, not only from final notebooks. For each source it stores immutable versions, computes cell/code/AST/token diffs, and pairs each patch with the observed public-score delta.

```text
v12 score .41 -> code/strategy patch -> v13 score .58 -> label +.17
v13 score .58 -> code/strategy patch -> v14 score .52 -> label -.06
```

Commands:

```bash
agentsec capture-versions
agentsec build-version-diffs
agentsec build-diff-dataset
agentsec train-diff-model
```

Archived versions can be imported explicitly:

```bash
agentsec import-version owner/notebook ./v12.ipynb --score 0.41 --label v12
```

Artifacts:

```text
workspace/versions/history.jsonl
workspace/corpus/version_diffs.jsonl
workspace/corpus/diff_regression.jsonl
workspace/corpus/diff_preferences.jsonl
workspace/models/diff_effect_model.json
```

Leaderboard movement is treated as **weak supervision**, not proof that a particular code change caused the score change. This prevents the learner from overstating causal evidence.


## Difference Expert

This build treats the **difference between notebook versions** as the primary
training object.

The expert does not primarily ask:

> What does the best notebook contain?

It asks:

> What changed, what happened to the public score afterward, did independent
> notebooks make a similar change, and how consistently did that pattern help
> or hurt?

### Learning hierarchy

```text
version N
   |
   | structural + token + AST + strategy delta
   v
version N+1
   |
   +---- public score delta
   |
   v
within-notebook evidence
   |
   +---- compare to similar deltas from unrelated notebooks
   v
cross-notebook corroboration
   |
   +---- preserve contradictions and uncertainty
   v
DIFFERENCE EXPERT
```

### Full Difference Expert pipeline

```bash
agentsec capture-versions

agentsec build-version-diffs
agentsec build-diff-dataset --min-abs-delta 0.001

agentsec build-cross-notebook-evidence \
  --similarity-threshold 0.35 \
  --min-abs-delta 0.001

agentsec build-difference-curriculum
agentsec train-difference-expert
```

Or:

```bash
agentsec difference-pipeline \
  --min-abs-delta 0.001 \
  --similarity-threshold 0.35
```

Evaluate a proposed change before trying it:

```bash
agentsec evaluate-patch --patch-json '{
  "added_tokens": {"retry": 2, "state": 1},
  "removed_tokens": {},
  "ast_delta": {"If": 1},
  "changed_units": 1
}'
```

The model reports:

- likely improving / regressing / unknown direction;
- a learned score-delta signal;
- confidence;
- recognized change features;
- the highest-impact learned feature contributions;
- number of independent sources supporting those features.

### Curriculum

`difference_curriculum.jsonl` teaches increasingly difficult tasks:

1. **Change detection** — identify exactly what changed.
2. **Direction prediction** — did the change precede improvement or regression?
3. **Magnitude prediction** — estimate the relative score effect.
4. **Cross-notebook generalization** — decide whether similar changes replicated.
5. **Contradiction awareness** — do not overgeneralize when evidence conflicts.
6. **Uncertainty calibration** — weak or isolated edits remain low-confidence.

### Core rule

A leaderboard delta is evidence, not proof of causation. The Difference Expert
therefore increases confidence only when independently developed notebooks show
similar changes with consistent outcomes.

## V5 — Closed-loop Difference Learning

V5 makes difference learning operational as a hypothesis → test → learn loop.
The expert proposes auditable structural notebook changes, ranks them by learned
score-effect signal and confidence, reserves part of the experiment budget for
uncertain changes, and accepts real measured competition results back into the
training corpus.

```text
public notebook differences
          ↓
    Difference Expert
          ↓
    propose changes
          ↓
    experiment queue
      ↙         ↘
 exploit       explore
      \         /
       sandbox run
           ↓
    measured score Δ
           ↓
      trial registry
           ↓
    learn-from-trials
           ↓
    Difference Expert
           ↺
```

Generate candidate differences:

```bash
agentsec propose-changes --source-ref my/notebook --max-proposals 12
```

Rank experiments:

```bash
agentsec experiment-queue --budget 5 --exploration-rate 0.20
```

Feed a real scored result back in:

```bash
agentsec register-trial <PROPOSAL_ID> --before 0.50 --after 0.56
agentsec learn-from-trials
agentsec build-cross-notebook-evidence
agentsec build-difference-curriculum
agentsec train-difference-expert
```

The proposal engine emits change specifications rather than silently executing
or rewriting downloaded notebooks. Apply reviewed changes inside the intended
competition sandbox, then import the measured score delta. This makes every
self-improvement claim traceable to a concrete before/after result.
\n\n## V6 — Kaggle-ready closed-loop bundle\n\nV6 adds a runnable Kaggle notebook and packaging path so the Difference Expert can be\ncarried into an actual competition notebook without rewriting the pipeline.\n\n- `notebooks/agent_security_adl_top_public.ipynb` — top-public discovery → snapshots → ADL diffs → expert → experiment queue.\n- `KAGGLE_RUNBOOK.md` — exact run order and persistence notes.\n- `examples/bootstrap_difference_demo.py` — offline end-to-end proof of the closed loop.\n- `scripts/build_kaggle_bundle.py` — builds the wheel that can be attached to Kaggle as a dataset input.\n\nThe notebook intentionally distinguishes a first snapshot from historical evidence: ADL only\nclaims a learned score effect when a real version-to-version score delta exists.\n