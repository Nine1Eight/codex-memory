from pathlib import Path
import shutil, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
DIST.mkdir(exist_ok=True)
subprocess.check_call([sys.executable, "-m", "pip", "wheel", ".", "--no-deps", "-w", str(DIST)], cwd=ROOT)
print("Built wheels:")
for p in sorted(DIST.glob("*.whl")):
    print(p)
