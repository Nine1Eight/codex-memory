import pytest
from agentsec.config import Config

def test_scope_guard():
    Config().validate_scope()
    with pytest.raises(ValueError):
        Config(competition="some-other-competition").validate_scope()
