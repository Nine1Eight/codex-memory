from pathlib import Path
from agentsec.config import Config
from agentsec.util import write_jsonl
from agentsec.difference_expert import build_cross_notebook_evidence, train_difference_expert
from agentsec.self_improve import propose_changes, experiment_queue, register_trial, learn_from_trials


def _diff(pid, ref, delta, token):
    return {
        "pair_id": pid,
        "source_ref": ref,
        "old_score": 0.1,
        "new_score": 0.1 + delta,
        "target_score_delta": delta,
        "direction": "improved" if delta > 0 else "regressed",
        "patch": {
            "added_tokens": {token: 3},
            "removed_tokens": {},
            "ast_delta": {"If": 1},
            "changed_units": 1,
            "strategy_families": [],
        },
    }


def test_self_improvement_cycle(tmp_path: Path):
    cfg = Config(workspace=tmp_path / "ws")
    rows = [
        _diff("a", "u/a", 0.20, "retry"),
        _diff("b", "u/b", 0.15, "retry"),
        _diff("c", "u/c", 0.10, "state"),
    ]
    write_jsonl(cfg.corpus_dir / "diff_regression.jsonl", rows)
    build_cross_notebook_evidence(cfg, similarity_threshold=0.2)
    train_difference_expert(cfg)

    props = propose_changes(cfg, max_proposals=4, min_confidence=0.0)
    assert props
    queue = experiment_queue(cfg, budget=min(2, len(props)))
    assert queue
    p = queue[0]
    trial = register_trial(cfg, p["proposal_id"], measured_score_before=0.50, measured_score_after=0.55)
    assert trial["measured_score_delta"] > 0
    learned = learn_from_trials(cfg)
    assert learned["new_training_rows_added"] == 1
