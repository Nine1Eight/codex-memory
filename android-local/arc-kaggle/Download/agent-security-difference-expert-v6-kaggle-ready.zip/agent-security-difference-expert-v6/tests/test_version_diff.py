from pathlib import Path
import nbformat
from agentsec.config import Config
from agentsec.version_diff import import_version, build_version_diffs, build_diff_learning_dataset, train_diff_model


def _nb(path: Path, code: str):
    nb=nbformat.v4.new_notebook(); nb.cells=[nbformat.v4.new_code_cell(code)]; nbformat.write(nb,path)


def test_diff_learning(tmp_path: Path):
    cfg=Config(workspace=tmp_path/'ws')
    a,b,c=tmp_path/'v1.ipynb',tmp_path/'v2.ipynb',tmp_path/'v3.ipynb'
    _nb(a,'def choose(x):\n    return x')
    _nb(b,'def choose(x):\n    if x:\n        return score(x)\n    return x')
    _nb(c,'def choose(x):\n    while x:\n        x = mutate(x)\n    return x')
    import_version(cfg,'owner/notebook',a,0.10,'v1')
    import_version(cfg,'owner/notebook',b,0.30,'v2')
    import_version(cfg,'owner/notebook',c,0.20,'v3')
    pairs=build_version_diffs(cfg)
    assert len(pairs)==2
    assert round(pairs[0]['score_delta'],6)==0.2
    assert round(pairs[1]['score_delta'],6)==-0.1
    m=build_diff_learning_dataset(cfg)
    assert m['improvements']==1 and m['regressions']==1 and m['preference_pairs']==1
    model=train_diff_model(cfg)
    assert model['training_rows']==2
