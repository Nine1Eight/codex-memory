from pathlib import Path
import json

from agentsec.config import Config
from agentsec.difference_expert import (
    patch_features,
    cosine,
    build_cross_notebook_evidence,
    train_difference_expert,
    evaluate_patch,
    build_difference_curriculum,
)
from agentsec.util import write_jsonl


def _row(pid, ref, delta, added=None, removed=None, ast=None):
    return {
        "pair_id": pid,
        "source_ref": ref,
        "old_score": 0.1,
        "new_score": 0.1 + delta,
        "target_score_delta": delta,
        "direction": "improved" if delta > 0 else "regressed",
        "patch": {
            "added_tokens": added or {},
            "removed_tokens": removed or {},
            "ast_delta": ast or {},
            "changed_units": 1,
        },
    }


def test_patch_similarity():
    a = patch_features({"added_tokens": {"retry": 3}, "changed_units": 1})
    b = patch_features({"added_tokens": {"retry": 2}, "changed_units": 1})
    assert cosine(a, b) > 0.5


def test_cross_notebook_expert(tmp_path: Path):
    cfg = Config(workspace=tmp_path / "ws")
    rows = [
        _row("a", "u/a", 0.20, {"retry": 3, "state": 2}, ast={"If": 1}),
        _row("b", "u/b", 0.15, {"retry": 2, "state": 1}, ast={"If": 1}),
        _row("c", "u/c", -0.10, {"random": 4}, ast={"While": 2}),
    ]
    write_jsonl(cfg.corpus_dir / "diff_regression.jsonl", rows)

    m = build_cross_notebook_evidence(cfg, similarity_threshold=0.2)
    assert m["cross_notebook_edges"] >= 1

    cm = build_difference_curriculum(cfg)
    assert cm["examples"] == len(rows) * 4

    model = train_difference_expert(cfg)
    assert model["model_type"] == "difference-expert-v1"

    result = evaluate_patch(cfg, {
        "added_tokens": {"retry": 2, "state": 1},
        "ast_delta": {"If": 1},
        "changed_units": 1,
    })
    assert result["recognized_features"] > 0
