from agentsec.normalize import _code_features, _signals

def test_code_features():
    src = """
def f(x):
    for i in range(2):
        if x:
            g(i)
"""
    f = _code_features(src)
    assert f["functions"] == 1
    assert f["loops"] == 1
    assert f["ifs"] == 1
    assert f["calls"] >= 2

def test_signals():
    s = _signals("planner retries tool calls and checks reward score")
    assert "planning" in s
    assert "retry" in s
    assert "tool-selection" in s
    assert "scoring" in s
