from pathlib import Path
from agentsec.config import Config
from agentsec.trajectory import _classify_line
from agentsec.episodes import build_external_episodes,merge_episodes
from agentsec.trajectory_dataset import build_trajectory_datasets
from agentsec.trajectory_policy import train_trajectory_policy,rank_actions
from agentsec.util import write_jsonl

def test_line_classification():
    assert _classify_line('reward: 0.25')==('reward',0.25)
    kind,value=_classify_line('{"action":"search","tool":"search"}')
    assert kind=='action' and value['action']=='search'

def test_external_trajectory_dataset(tmp_path:Path):
    cfg=Config(workspace=tmp_path/'ws')
    rows=[{'source_ref':'u/n','episode_id':'e1','step':0,'observation':'search needed','candidates':['search','note'],'action':'search','tool_name':'search','tool_args':{'q':'x'},'tool_result':'found','reward':0.0,'terminal':False,'metadata':{}},{'source_ref':'u/n','episode_id':'e1','step':1,'observation':'evidence found','candidates':['note'],'action':'note','tool_name':'note','tool_args':{'text':'x'},'tool_result':'saved','reward':1.0,'terminal':True,'metadata':{}}]
    write_jsonl(cfg.corpus_dir/'external_traces.jsonl',rows); build_external_episodes(cfg); merge_episodes(cfg); m=build_trajectory_datasets(cfg,0.0); assert m['trajectory_sft_records']==2
    train_trajectory_policy(cfg); assert rank_actions(cfg,'need to search')
