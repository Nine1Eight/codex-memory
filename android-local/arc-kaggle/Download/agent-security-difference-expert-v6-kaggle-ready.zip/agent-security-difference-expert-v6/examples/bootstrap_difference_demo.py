from pathlib import Path
import json, tempfile
import nbformat

from agentsec.config import Config
from agentsec.version_diff import import_version, build_version_diffs, build_diff_learning_dataset
from agentsec.difference_expert import build_cross_notebook_evidence, build_difference_curriculum, train_difference_expert, evaluate_patch
from agentsec.self_improve import propose_changes, experiment_queue, register_trial, learn_from_trials


def write_nb(path: Path, code: str):
    nb = nbformat.v4.new_notebook()
    nb.cells = [nbformat.v4.new_code_cell(code)]
    nbformat.write(nb, path)


def main():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = Config(workspace=td / "workspace")
        # Two independent notebook lineages make similar retry/state changes.
        a1, a2, b1, b2 = [td / n for n in ("a1.ipynb","a2.ipynb","b1.ipynb","b2.ipynb")]
        write_nb(a1, "def choose(x):\n    return act(x)")
        write_nb(a2, "def choose(x):\n    state = x\n    if state:\n        return retry(act(state))\n    return act(x)")
        write_nb(b1, "def policy(obs):\n    return tool(obs)")
        write_nb(b2, "def policy(obs):\n    state = obs\n    if state:\n        return retry(tool(state))\n    return tool(obs)")
        import_version(cfg, "alpha/public", a1, 0.20, "v1")
        import_version(cfg, "alpha/public", a2, 0.34, "v2")
        import_version(cfg, "beta/public", b1, 0.18, "v1")
        import_version(cfg, "beta/public", b2, 0.31, "v2")
        pairs = build_version_diffs(cfg)
        manifest = build_diff_learning_dataset(cfg)
        cross = build_cross_notebook_evidence(cfg, similarity_threshold=0.20)
        curriculum = build_difference_curriculum(cfg)
        model = train_difference_expert(cfg)
        proposals = propose_changes(cfg, "candidate/notebook", max_proposals=6, min_confidence=0.0)
        queue = experiment_queue(cfg, budget=min(3, len(proposals)), exploration_rate=0.34)
        # Feed one deterministic measured result back to prove the closed loop.
        trial = register_trial(cfg, queue[0]["proposal_id"], 0.40, 0.43)
        learned = learn_from_trials(cfg)
        result = {
            "version_diffs": len(pairs),
            "diff_manifest": manifest,
            "cross_notebook": cross,
            "curriculum_rows": curriculum.get("rows", curriculum) if isinstance(curriculum, dict) else len(curriculum),
            "model_type": model.get("model_type"),
            "proposals": len(proposals),
            "queue": len(queue),
            "registered_delta": trial["measured_score_delta"],
            "learn_from_trials": learned,
            "top_queue_item": queue[0],
        }
        print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == "__main__":
    main()
