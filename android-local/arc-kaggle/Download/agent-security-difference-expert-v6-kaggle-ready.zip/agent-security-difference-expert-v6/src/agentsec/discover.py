from __future__ import annotations
from pathlib import Path
import csv
import io
import re
from .config import Config
from .util import run, write_jsonl

REF_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")

def discover(cfg: Config, top: int = 50, sort_by: str = "scoreDescending") -> list[dict]:
    cfg.validate_scope()
    if top < 1 or top > 200:
        raise ValueError("--top must be between 1 and 200")

    out = run([
        "kaggle", "kernels", "list",
        "--competition", cfg.competition,
        "--kernel-type", "notebook",
        "--language", "python",
        "--page-size", str(top),
        "--sort-by", sort_by,
        "--csv",
    ])

    rows = list(csv.DictReader(io.StringIO(out)))
    records = []
    for rank, row in enumerate(rows, start=1):
        # Kaggle CLI field names can evolve. Find the reference defensively.
        ref = (
            row.get("ref")
            or row.get("Ref")
            or row.get("id")
            or row.get("Id")
            or row.get("kernelRef")
        )
        if not ref:
            # fallback: find first owner/slug-looking value
            ref = next((v for v in row.values() if isinstance(v, str) and REF_RE.match(v)), None)
        if not ref:
            continue

        score_raw = (
            row.get("score")
            or row.get("Score")
            or row.get("totalVotes")
            or row.get("TotalVotes")
        )
        score = None
        if score_raw not in (None, ""):
            try:
                score = float(score_raw)
            except ValueError:
                pass

        records.append({
            "rank_at_discovery": rank,
            "ref": ref,
            "public_score": score,
            "metadata": row,
        })

    write_jsonl(cfg.discovered, records)
    return records
