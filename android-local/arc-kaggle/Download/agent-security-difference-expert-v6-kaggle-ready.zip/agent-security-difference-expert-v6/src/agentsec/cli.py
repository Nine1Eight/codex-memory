from __future__ import annotations
import argparse
import json
import shutil
from pathlib import Path

from .config import Config
from .discover import discover
from .snapshot import snapshot
from .normalize import normalize
from .extract import extract
from .dataset import build_dataset
from .train import train, predict
from .report import report
from .trajectory import extract_notebook_output_events, ingest_external_trace_jsonl
from .episodes import reconstruct_from_events, build_external_episodes, merge_episodes
from .trajectory_dataset import build_trajectory_datasets
from .trajectory_policy import train_trajectory_policy, rank_actions
from .version_diff import capture_versions, import_version, build_version_diffs, build_diff_learning_dataset, train_diff_model
from .difference_expert import build_cross_notebook_evidence, train_difference_expert, evaluate_patch, build_difference_curriculum
from .self_improve import propose_changes, experiment_queue, register_trial, learn_from_trials


def _cfg(args) -> Config:
    return Config(workspace=Path(args.workspace))


def main() -> None:
    p = argparse.ArgumentParser(prog="agentsec")
    p.add_argument("--workspace", default="workspace")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor")
    d = sub.add_parser("discover"); d.add_argument("--top", type=int, default=50); d.add_argument("--sort", default="scoreDescending")
    sub.add_parser("snapshot")
    sub.add_parser("normalize")
    sub.add_parser("extract")
    b = sub.add_parser("build-dataset"); b.add_argument("--include-source-text", action="store_true")
    sub.add_parser("train")
    sub.add_parser("report")

    sub.add_parser("extract-events")
    it = sub.add_parser("ingest-trace"); it.add_argument("path")
    sub.add_parser("reconstruct-episodes")
    td = sub.add_parser("build-trajectories"); td.add_argument("--min-quality", type=float, default=0.25)
    sub.add_parser("train-trajectory-policy")
    ra = sub.add_parser("rank-actions"); ra.add_argument("--observation", required=True)

    sub.add_parser("capture-versions")
    iv = sub.add_parser("import-version")
    iv.add_argument("source_ref"); iv.add_argument("path"); iv.add_argument("--score", type=float); iv.add_argument("--label")
    sub.add_parser("build-version-diffs")
    bd = sub.add_parser("build-diff-dataset"); bd.add_argument("--min-abs-delta", type=float, default=0.0)
    sub.add_parser("train-diff-model")

    cross = sub.add_parser("build-cross-notebook-evidence")
    cross.add_argument("--similarity-threshold", type=float, default=0.35)
    cross.add_argument("--min-abs-delta", type=float, default=0.0)
    de = sub.add_parser("train-difference-expert"); de.add_argument("--min-confidence", type=float, default=0.0)
    ep = sub.add_parser("evaluate-patch"); ep.add_argument("--patch-json", required=True)
    sub.add_parser("build-difference-curriculum")
    dp = sub.add_parser("difference-pipeline")
    dp.add_argument("--min-abs-delta", type=float, default=0.0)
    dp.add_argument("--similarity-threshold", type=float, default=0.35)
    dp.add_argument("--min-confidence", type=float, default=0.0)

    pc = sub.add_parser("propose-changes")
    pc.add_argument("--source-ref", default="candidate/notebook")
    pc.add_argument("--max-proposals", type=int, default=12)
    pc.add_argument("--min-confidence", type=float, default=0.05)
    eq = sub.add_parser("experiment-queue")
    eq.add_argument("--budget", type=int, default=5)
    eq.add_argument("--exploration-rate", type=float, default=0.20)
    rt = sub.add_parser("register-trial")
    rt.add_argument("proposal_id")
    rt.add_argument("--before", type=float, required=True)
    rt.add_argument("--after", type=float, required=True)
    rt.add_argument("--status", default="completed")
    rt.add_argument("--notes")
    sub.add_parser("learn-from-trials")

    pr = sub.add_parser("predict"); pr.add_argument("--features-json", required=True); pr.add_argument("--signals", nargs="*")
    pipe = sub.add_parser("pipeline")
    pipe.add_argument("--top", type=int, default=50); pipe.add_argument("--sort", default="scoreDescending"); pipe.add_argument("--include-source-text", action="store_true")

    args = p.parse_args()
    cfg = _cfg(args)
    cfg.validate_scope()

    if args.cmd == "doctor":
        print("competition:", cfg.competition); print("workspace:", cfg.workspace); print("kaggle_cli:", shutil.which("kaggle") or "NOT FOUND")
    elif args.cmd == "discover":
        print(f"discovered {len(discover(cfg, args.top, args.sort))} notebooks")
    elif args.cmd == "snapshot":
        print(f"snapshotted {len(snapshot(cfg))} notebooks")
    elif args.cmd == "normalize":
        print(f"normalized {len(normalize(cfg))} units")
    elif args.cmd == "extract":
        print(f"extracted {len(extract(cfg))} strategy records")
    elif args.cmd == "build-dataset":
        print(json.dumps(build_dataset(cfg, args.include_source_text), indent=2))
    elif args.cmd == "train":
        model = train(cfg); print(f"trained {model['model_type']} with {len(model['centroids'])} strategy families")
    elif args.cmd == "report":
        print(report(cfg))
    elif args.cmd == "extract-events":
        print(f"extracted {len(extract_notebook_output_events(cfg))} observable output events")
    elif args.cmd == "ingest-trace":
        print(f"ingested {len(ingest_external_trace_jsonl(cfg, Path(args.path)))} trace steps")
    elif args.cmd == "reconstruct-episodes":
        r = reconstruct_from_events(cfg); e = build_external_episodes(cfg); m = merge_episodes(cfg)
        print(f"episodes: reconstructed={len(r)}, external={len(e)}, merged={len(m)}")
    elif args.cmd == "build-trajectories":
        print(json.dumps(build_trajectory_datasets(cfg, args.min_quality), indent=2))
    elif args.cmd == "train-trajectory-policy":
        model = train_trajectory_policy(cfg); print(f"trained {model['model_type']} over {len(model['actions'])} actions")
    elif args.cmd == "rank-actions":
        print(json.dumps(rank_actions(cfg, args.observation), indent=2))
    elif args.cmd == "capture-versions":
        print(f"captured {len(capture_versions(cfg))} new content versions")
    elif args.cmd == "import-version":
        print(json.dumps(import_version(cfg, args.source_ref, Path(args.path), args.score, args.label), indent=2))
    elif args.cmd == "build-version-diffs":
        print(f"built {len(build_version_diffs(cfg))} notebook version diffs")
    elif args.cmd == "build-diff-dataset":
        print(json.dumps(build_diff_learning_dataset(cfg, args.min_abs_delta), indent=2))
    elif args.cmd == "train-diff-model":
        model = train_diff_model(cfg); print(f"trained {model['model_type']} from {model['training_rows']} diffs")
    elif args.cmd == "build-cross-notebook-evidence":
        print(json.dumps(build_cross_notebook_evidence(cfg, args.similarity_threshold, args.min_abs_delta), indent=2))
    elif args.cmd == "train-difference-expert":
        model = train_difference_expert(cfg, args.min_confidence); print(f"trained {model['model_type']} from {model['training_rows']} notebook differences")
    elif args.cmd == "evaluate-patch":
        print(json.dumps(evaluate_patch(cfg, json.loads(args.patch_json)), indent=2))
    elif args.cmd == "build-difference-curriculum":
        print(json.dumps(build_difference_curriculum(cfg), indent=2))
    elif args.cmd == "difference-pipeline":
        build_version_diffs(cfg)
        build_diff_learning_dataset(cfg, args.min_abs_delta)
        build_cross_notebook_evidence(cfg, args.similarity_threshold, args.min_abs_delta)
        build_difference_curriculum(cfg)
        model = train_difference_expert(cfg, args.min_confidence)
        print(f"trained {model['model_type']} from {model['training_rows']} notebook differences")
    elif args.cmd == "propose-changes":
        print(json.dumps(propose_changes(cfg, args.source_ref, args.max_proposals, args.min_confidence), indent=2))
    elif args.cmd == "experiment-queue":
        print(json.dumps(experiment_queue(cfg, args.budget, args.exploration_rate), indent=2))
    elif args.cmd == "register-trial":
        print(json.dumps(register_trial(cfg, args.proposal_id, args.before, args.after, args.status, args.notes), indent=2))
    elif args.cmd == "learn-from-trials":
        print(json.dumps(learn_from_trials(cfg), indent=2))
    elif args.cmd == "predict":
        print(json.dumps(predict(cfg, json.loads(args.features_json), args.signals), indent=2))
    elif args.cmd == "pipeline":
        discover(cfg, args.top, args.sort); snapshot(cfg); normalize(cfg); extract(cfg); build_dataset(cfg, args.include_source_text); train(cfg); print(report(cfg))


if __name__ == "__main__":
    main()
