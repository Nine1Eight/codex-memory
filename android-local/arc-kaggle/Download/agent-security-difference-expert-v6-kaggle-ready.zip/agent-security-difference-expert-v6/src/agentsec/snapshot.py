from __future__ import annotations
from pathlib import Path
import json
import time
from .config import Config
from .util import read_jsonl, run, safe_ref, sha256_file

def snapshot(cfg: Config) -> list[dict]:
    cfg.validate_scope()
    records = read_jsonl(cfg.discovered)
    if not records:
        raise RuntimeError("No discovery manifest. Run `agentsec discover` first.")

    results = []
    for rec in records:
        ref = rec["ref"]
        owner, slug = safe_ref(ref)
        dest = cfg.raw_dir / owner / slug
        dest.mkdir(parents=True, exist_ok=True)

        # Pull only public Kaggle notebook source/metadata.
        run(["kaggle", "kernels", "pull", ref, "--path", str(dest), "--metadata"])

        hashes = {}
        for path in sorted(dest.rglob("*")):
            if path.is_file():
                hashes[str(path.relative_to(dest))] = sha256_file(path)

        snap = {
            **rec,
            "captured_unix": int(time.time()),
            "sha256": hashes,
        }
        (dest / "snapshot.json").write_text(
            json.dumps(snap, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        results.append(snap)
    return results
