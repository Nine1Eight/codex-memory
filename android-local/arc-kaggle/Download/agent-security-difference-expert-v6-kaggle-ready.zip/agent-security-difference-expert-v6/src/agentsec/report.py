from __future__ import annotations
import json
from .config import Config

def report(cfg: Config) -> str:
    parts = []
    manifest = cfg.corpus_dir / "manifest.json"
    portfolio = cfg.portfolio_dir / "portfolio.json"

    if manifest.exists():
        m = json.loads(manifest.read_text(encoding="utf-8"))
        parts.append(
            f"Corpus: {m['records']} records from {m['sources']} public notebook sources; "
            f"{m['preference_records']} preference pairs."
        )
        parts.append(f"Splits: {m['splits']}")

    if portfolio.exists():
        p = json.loads(portfolio.read_text(encoding="utf-8"))
        parts.append("Strategy portfolio:")
        for row in p["strategies"]:
            mean = row["mean_public_score"]
            mean_text = "n/a" if mean is None else f"{mean:.6g}"
            parts.append(
                f"  - {row['family']}: records={row['records']}, mean_public_score={mean_text}"
            )

    if not parts:
        return "No built artifacts yet."
    return "\n".join(parts)
