from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any

from .config import Config
from .util import read_jsonl, write_jsonl


def _norm_token_feature(prefix: str, values: dict[str, Any]) -> dict[str, float]:
    out: dict[str, float] = {}
    for key, value in (values or {}).items():
        try:
            v = float(value)
        except Exception:
            continue
        if v == 0:
            continue
        sign = 1.0 if v > 0 else -1.0
        out[f"{prefix}:{key}"] = sign * math.log1p(abs(v))
    return out


def patch_features(patch: dict) -> dict[str, float]:
    """
    Convert a notebook patch into a sparse semantic/structural feature vector.

    Features encode:
      - token additions/removals
      - AST-node additions/removals
      - number of changed units
      - strategy-family tags when supplied
    """
    feats: dict[str, float] = {}
    feats.update(_norm_token_feature("add", patch.get("added_tokens", {})))
    feats.update(_norm_token_feature("remove", patch.get("removed_tokens", {})))
    feats.update(_norm_token_feature("ast", patch.get("ast_delta", {})))

    changed = float(patch.get("changed_units", 0) or 0)
    if changed:
        feats["meta:changed_units"] = math.log1p(changed)

    for family in patch.get("strategy_families", []) or []:
        feats[f"strategy:{family}"] = 1.0
    return feats


def cosine(a: dict[str, float], b: dict[str, float]) -> float:
    if not a or not b:
        return 0.0
    common = set(a) & set(b)
    dot = sum(a[k] * b[k] for k in common)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _effect_direction(delta: float, eps: float = 1e-12) -> str:
    if delta > eps:
        return "improved"
    if delta < -eps:
        return "regressed"
    return "flat"


def build_cross_notebook_evidence(
    cfg: Config,
    similarity_threshold: float = 0.35,
    min_abs_delta: float = 0.0,
) -> dict:
    """
    Find similar changes introduced independently across different notebooks.

    A repeated pattern such as:
      notebook A adds retry/state logic -> score rises
      notebook B adds similar retry/state logic -> score rises
    receives stronger evidence than a single isolated edit.

    This remains associational evidence, not causal proof.
    """
    cfg.validate_scope()
    rows = read_jsonl(cfg.corpus_dir / "diff_regression.jsonl")
    rows = [
        r for r in rows
        if isinstance(r.get("target_score_delta"), (int, float))
        and abs(float(r["target_score_delta"])) >= min_abs_delta
    ]

    enriched = []
    for row in rows:
        enriched.append({
            **row,
            "_features": patch_features(row.get("patch", {})),
        })

    edges = []
    neighbors: dict[str, list[dict]] = defaultdict(list)
    for i, a in enumerate(enriched):
        for b in enriched[i + 1:]:
            if a["source_ref"] == b["source_ref"]:
                continue
            sim = cosine(a["_features"], b["_features"])
            if sim < similarity_threshold:
                continue

            da = float(a["target_score_delta"])
            db = float(b["target_score_delta"])
            agree = _effect_direction(da) == _effect_direction(db)
            edge = {
                "a_pair_id": a["pair_id"],
                "b_pair_id": b["pair_id"],
                "a_source_ref": a["source_ref"],
                "b_source_ref": b["source_ref"],
                "similarity": round(sim, 6),
                "a_delta": da,
                "b_delta": db,
                "direction_agreement": agree,
            }
            edges.append(edge)
            neighbors[a["pair_id"]].append(edge)
            neighbors[b["pair_id"]].append(edge)

    evidence_rows = []
    for row in enriched:
        pair_id = row["pair_id"]
        nbs = neighbors.get(pair_id, [])
        own_delta = float(row["target_score_delta"])
        own_direction = _effect_direction(own_delta)

        independent_sources = set()
        same_direction_weight = 0.0
        opposite_direction_weight = 0.0
        weighted_delta_sum = 0.0
        total_weight = 0.0

        for e in nbs:
            other_source = (
                e["b_source_ref"] if e["a_pair_id"] == pair_id
                else e["a_source_ref"]
            )
            other_delta = e["b_delta"] if e["a_pair_id"] == pair_id else e["a_delta"]
            sim = float(e["similarity"])
            independent_sources.add(other_source)
            weighted_delta_sum += sim * float(other_delta)
            total_weight += sim
            if _effect_direction(float(other_delta)) == own_direction:
                same_direction_weight += sim
            else:
                opposite_direction_weight += sim

        cross_mean = weighted_delta_sum / total_weight if total_weight else 0.0
        agreement = (
            same_direction_weight / (same_direction_weight + opposite_direction_weight)
            if (same_direction_weight + opposite_direction_weight) else 0.0
        )

        # Confidence rises with independent corroboration, similarity and agreement.
        source_support = 1.0 - math.exp(-len(independent_sources) / 3.0)
        corroboration = total_weight / (total_weight + 2.0) if total_weight else 0.0
        confidence = source_support * corroboration * agreement

        evidence_rows.append({
            "pair_id": pair_id,
            "source_ref": row["source_ref"],
            "target_score_delta": own_delta,
            "direction": own_direction,
            "independent_supporting_sources": len(independent_sources),
            "neighbor_count": len(nbs),
            "direction_agreement": round(agreement, 6),
            "cross_notebook_mean_delta": round(cross_mean, 8),
            "difference_confidence": round(confidence, 6),
            "patch": row["patch"],
        })

    write_jsonl(cfg.corpus_dir / "cross_notebook_edges.jsonl", edges)
    write_jsonl(cfg.corpus_dir / "cross_notebook_evidence.jsonl", evidence_rows)

    manifest = {
        "diff_rows": len(enriched),
        "cross_notebook_edges": len(edges),
        "evidence_rows": len(evidence_rows),
        "similarity_threshold": similarity_threshold,
        "min_abs_delta": min_abs_delta,
        "rows_with_independent_support": sum(
            e["independent_supporting_sources"] > 0 for e in evidence_rows
        ),
    }
    (cfg.corpus_dir / "cross_notebook_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return manifest


def train_difference_expert(cfg: Config, min_confidence: float = 0.0) -> dict:
    """
    Build an expert model whose primary knowledge is the effect of *changes*.

    It combines:
      1. within-notebook score deltas,
      2. cross-notebook corroboration,
      3. feature-level positive/negative effect estimates,
      4. contradiction tracking,
      5. uncertainty estimates.

    The model predicts the likely effect of a proposed patch rather than
    merely imitating a high-scoring final notebook.
    """
    cfg.validate_scope()
    rows = read_jsonl(cfg.corpus_dir / "diff_regression.jsonl")
    evidence = {
        r["pair_id"]: r
        for r in read_jsonl(cfg.corpus_dir / "cross_notebook_evidence.jsonl")
    }
    if not rows:
        raise RuntimeError("No difference-learning rows. Build version diffs first.")

    stats = defaultdict(lambda: {
        "weighted_sum": 0.0,
        "weight": 0.0,
        "positive": 0,
        "negative": 0,
        "zero": 0,
        "sources": set(),
        "samples": 0,
    })

    training_examples = []
    for row in rows:
        delta = float(row["target_score_delta"])
        ev = evidence.get(row["pair_id"], {})
        confidence = float(ev.get("difference_confidence", 0.0) or 0.0)

        # Always retain direct evidence; corroborated changes get more weight.
        weight = 1.0 + 3.0 * confidence
        if confidence < min_confidence and confidence > 0:
            weight = 1.0

        feats = patch_features(row.get("patch", {}))
        for feature, magnitude in feats.items():
            s = stats[feature]
            contribution_weight = weight * abs(magnitude)
            s["weighted_sum"] += delta * contribution_weight * (1 if magnitude >= 0 else -1)
            s["weight"] += contribution_weight
            s["samples"] += 1
            s["sources"].add(row["source_ref"])
            if delta > 0:
                s["positive"] += 1
            elif delta < 0:
                s["negative"] += 1
            else:
                s["zero"] += 1

        training_examples.append({
            "pair_id": row["pair_id"],
            "source_ref": row["source_ref"],
            "score_delta": delta,
            "confidence": confidence,
            "weight": weight,
            "features": feats,
        })

    effects = {}
    for feature, s in stats.items():
        if s["weight"] <= 0:
            continue
        mean_effect = s["weighted_sum"] / s["weight"]
        directional = s["positive"] + s["negative"]
        consistency = (
            abs(s["positive"] - s["negative"]) / directional
            if directional else 0.0
        )
        # Reliability favors repeated independent sources and consistency.
        source_factor = 1.0 - math.exp(-len(s["sources"]) / 3.0)
        sample_factor = 1.0 - math.exp(-s["samples"] / 5.0)
        reliability = consistency * source_factor * sample_factor
        effects[feature] = {
            "mean_effect": mean_effect,
            "reliability": reliability,
            "samples": s["samples"],
            "independent_sources": len(s["sources"]),
            "positive_examples": s["positive"],
            "negative_examples": s["negative"],
        }

    model = {
        "model_type": "difference-expert-v1",
        "specialization": "notebook-change-effect-learning",
        "training_rows": len(training_examples),
        "feature_effects": effects,
        "principles": {
            "primary_unit_of_learning": "difference_between_versions",
            "cross_notebook_corroboration": True,
            "contradictions_are_preserved": True,
            "score_delta_is_associational_not_causal": True,
            "final_notebook_score_is_context_not_target_behavior": True,
        },
    }
    cfg.models_dir.mkdir(parents=True, exist_ok=True)
    (cfg.models_dir / "difference_expert.json").write_text(
        json.dumps(model, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    write_jsonl(cfg.corpus_dir / "difference_expert_training.jsonl", training_examples)
    return model


def evaluate_patch(cfg: Config, patch: dict) -> dict:
    """
    Score a proposed notebook change with the learned Difference Expert.
    """
    path = cfg.models_dir / "difference_expert.json"
    if not path.exists():
        raise RuntimeError("Train the Difference Expert first.")
    model = json.loads(path.read_text(encoding="utf-8"))
    feats = patch_features(patch)

    contributions = []
    weighted_sum = 0.0
    total_reliability = 0.0

    for feature, magnitude in feats.items():
        info = model["feature_effects"].get(feature)
        if not info:
            continue
        reliability = float(info["reliability"])
        effect = float(info["mean_effect"])
        contribution = effect * magnitude * reliability
        weighted_sum += contribution
        total_reliability += reliability * abs(magnitude)
        contributions.append({
            "feature": feature,
            "magnitude": magnitude,
            "learned_effect": effect,
            "reliability": reliability,
            "contribution": contribution,
            "independent_sources": info["independent_sources"],
            "samples": info["samples"],
        })

    contributions.sort(key=lambda x: abs(x["contribution"]), reverse=True)
    confidence = 1.0 - math.exp(-total_reliability / 4.0) if total_reliability else 0.0

    return {
        "predicted_score_delta_signal": weighted_sum,
        "direction": (
            "likely_improving" if weighted_sum > 0
            else "likely_regressing" if weighted_sum < 0
            else "unknown"
        ),
        "confidence": confidence,
        "recognized_features": len(contributions),
        "total_patch_features": len(feats),
        "top_contributions": contributions[:25],
        "warning": "Associational prediction from public notebook differences; not causal proof.",
    }


def build_difference_curriculum(cfg: Config) -> dict:
    """
    Create a staged curriculum that teaches the agent difference reasoning.

    Stages:
      A. detect what changed
      B. classify change family
      C. predict direction
      D. predict relative magnitude
      E. compare two patches
      F. generalize across independent notebooks
      G. identify contradictions / uncertainty
    """
    cfg.validate_scope()
    rows = read_jsonl(cfg.corpus_dir / "diff_regression.jsonl")
    evidence = {
        r["pair_id"]: r
        for r in read_jsonl(cfg.corpus_dir / "cross_notebook_evidence.jsonl")
    }

    curriculum = []
    for row in rows:
        patch = row["patch"]
        delta = float(row["target_score_delta"])
        ev = evidence.get(row["pair_id"], {})

        base = {
            "pair_id": row["pair_id"],
            "source_ref": row["source_ref"],
            "patch": patch,
        }

        curriculum.extend([
            {
                **base,
                "stage": "A_change_detection",
                "input": {"patch": patch},
                "target": {
                    "changed_units": patch.get("changed_units", 0),
                    "added_token_count": sum((patch.get("added_tokens") or {}).values()),
                    "removed_token_count": sum((patch.get("removed_tokens") or {}).values()),
                    "ast_change_count": len(patch.get("ast_delta") or {}),
                },
            },
            {
                **base,
                "stage": "C_direction_prediction",
                "input": {"patch": patch},
                "target": {"direction": _effect_direction(delta)},
            },
            {
                **base,
                "stage": "D_magnitude_prediction",
                "input": {"patch": patch},
                "target": {"score_delta": delta},
            },
            {
                **base,
                "stage": "F_cross_notebook_generalization",
                "input": {
                    "patch": patch,
                    "independent_supporting_sources": ev.get("independent_supporting_sources", 0),
                    "direction_agreement": ev.get("direction_agreement", 0.0),
                },
                "target": {
                    "difference_confidence": ev.get("difference_confidence", 0.0),
                    "cross_notebook_mean_delta": ev.get("cross_notebook_mean_delta", 0.0),
                },
            },
        ])

    write_jsonl(cfg.corpus_dir / "difference_curriculum.jsonl", curriculum)
    manifest = {
        "examples": len(curriculum),
        "source_diffs": len(rows),
        "stages": sorted({r["stage"] for r in curriculum}),
    }
    (cfg.corpus_dir / "difference_curriculum_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return manifest
