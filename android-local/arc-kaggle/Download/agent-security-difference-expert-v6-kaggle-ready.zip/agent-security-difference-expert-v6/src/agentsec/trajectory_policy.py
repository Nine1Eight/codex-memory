from __future__ import annotations
from collections import Counter,defaultdict
import json,math,re
from .config import Config
from .util import read_jsonl
TOKEN=re.compile(r'[A-Za-z_][A-Za-z0-9_\-]{1,48}')
def _tokens(v):
    if v is None:return set()
    if not isinstance(v,str):v=json.dumps(v,sort_keys=True,default=str)
    return {x.lower() for x in TOKEN.findall(v)}
def train_trajectory_policy(cfg:Config):
    rows=[r for r in read_jsonl(cfg.corpus_dir/'trajectory_sft.jsonl') if r.get('split')=='train']
    if not rows:raise RuntimeError('No trajectory training rows')
    docs=defaultdict(Counter); counts=Counter()
    for r in rows:
        a=str(r['target']['action']); toks=_tokens(r['input'].get('observation'))
        for h in r['input'].get('recent_history',[]): toks|=_tokens(h.get('observation'))|_tokens(h.get('tool_result'))
        for t in toks:docs[a][t]+=1
        counts[a]+=1
    model={'model_type':'observable-trace-retrieval-policy','actions':{a:{'count':counts[a],'tokens':dict(c.most_common(500))} for a,c in docs.items()}}
    cfg.models_dir.mkdir(parents=True,exist_ok=True); (cfg.models_dir/'trajectory_policy.json').write_text(json.dumps(model,indent=2,sort_keys=True)); return model
def rank_actions(cfg:Config,observation,recent_history=None):
    model=json.loads((cfg.models_dir/'trajectory_policy.json').read_text()); q=_tokens(observation)
    for h in recent_history or []: q|=_tokens(h.get('observation'))|_tokens(h.get('tool_result'))
    out=[]
    for a,info in model['actions'].items():
        overlap=sum(math.log1p(info['tokens'].get(t,0)) for t in q if t in info['tokens']); prior=math.log1p(info['count']); out.append({'action':a,'score':overlap+.05*prior,'token_overlap':overlap,'count':info['count']})
    return sorted(out,key=lambda x:x['score'],reverse=True)
