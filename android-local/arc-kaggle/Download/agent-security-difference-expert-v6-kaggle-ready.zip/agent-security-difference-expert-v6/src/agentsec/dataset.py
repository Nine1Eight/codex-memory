from __future__ import annotations
from collections import defaultdict
import json
import random
from .config import Config
from .util import read_jsonl, write_jsonl

def _structural_view(row: dict) -> dict:
    # Avoid redistributing copied notebook text by default.
    return {
        "strategy_record_id": row["strategy_record_id"],
        "family": row["family"],
        "source_ref": row["source_ref"],
        "source_score": row.get("source_score"),
        "signals": row["signals"],
        "features": row["features"],
    }

def build_dataset(cfg: Config, include_source_text: bool = False) -> dict:
    cfg.validate_scope()
    rows = read_jsonl(cfg.corpus_dir / "strategies.jsonl")
    if not rows:
        raise RuntimeError("No extracted records. Run `agentsec extract` first.")

    # Group-aware split: a notebook ref belongs to only one split.
    refs = sorted({r["source_ref"] for r in rows})
    rng = random.Random(918)
    rng.shuffle(refs)

    n = len(refs)
    n_train = max(1, int(n * 0.8)) if n else 0
    n_val = int(n * 0.1)
    split_map = {}
    for i, ref in enumerate(refs):
        split_map[ref] = "train" if i < n_train else ("validation" if i < n_train+n_val else "test")

    sft = []
    for r in rows:
        inp = {
            "signals": r["signals"],
            "features": r["features"],
        }
        target = {"strategy_family": r["family"]}
        item = {
            "id": r["strategy_record_id"],
            "split": split_map[r["source_ref"]],
            "source_ref": r["source_ref"],
            "source_score": r.get("source_score"),
            "input": inp,
            "target": target,
        }
        if include_source_text:
            item["source_text"] = r.get("text", "")
        sft.append(item)

    # Preference records: compare families within the same notebook using
    # notebook-level score as weak supervision only when scores differ.
    by_family = defaultdict(list)
    for r in rows:
        if r.get("source_score") is not None:
            by_family[r["family"]].append(r)

    prefs = []
    for family, family_rows in by_family.items():
        ordered = sorted(family_rows, key=lambda x: (x["source_score"], x["source_ref"]))
        if len(ordered) < 2:
            continue
        lo = ordered[0]
        hi = ordered[-1]
        if hi["source_score"] == lo["source_score"]:
            continue
        prefs.append({
            "family": family,
            "preferred": _structural_view(hi),
            "rejected": _structural_view(lo),
            "evidence": {
                "preferred_source_score": hi["source_score"],
                "rejected_source_score": lo["source_score"],
            },
        })

    write_jsonl(cfg.corpus_dir / "sft.jsonl", sft)
    write_jsonl(cfg.corpus_dir / "preference.jsonl", prefs)

    manifest = {
        "competition": cfg.competition,
        "records": len(rows),
        "sources": len(refs),
        "sft_records": len(sft),
        "preference_records": len(prefs),
        "splits": {
            split: len({r["source_ref"] for r in sft if r["split"] == split})
            for split in ("train", "validation", "test")
        },
        "source_text_included": include_source_text,
    }
    (cfg.corpus_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return manifest
