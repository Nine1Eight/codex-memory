from __future__ import annotations
from collections import defaultdict
import hashlib
from .config import Config
from .util import read_jsonl, write_jsonl

FAMILIES = (
    "tool-selection",
    "planning",
    "retry",
    "scoring",
    "state",
    "mutation",
    "validation",
    "termination",
)

def extract(cfg: Config) -> list[dict]:
    cfg.validate_scope()
    rows = read_jsonl(cfg.normalized)
    out = []

    for row in rows:
        signals = row.get("signals", [])
        if not signals:
            continue
        for family in signals:
            if family not in FAMILIES:
                continue
            rid = hashlib.sha256(
                f"{row['source_ref']}|{row['source_file']}|{row['unit_index']}|{family}".encode()
            ).hexdigest()[:20]
            out.append({
                "strategy_record_id": rid,
                "family": family,
                "source_ref": row["source_ref"],
                "source_score": row.get("source_score"),
                "source_file": row["source_file"],
                "unit_index": row["unit_index"],
                "unit_type": row["unit_type"],
                "signals": signals,
                "features": row.get("features", {}),
                "text": row.get("text", ""),
            })

    write_jsonl(cfg.corpus_dir / "strategies.jsonl", out)
    return out
