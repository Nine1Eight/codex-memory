from __future__ import annotations
from collections import defaultdict, Counter
import json
import math
from .config import Config
from .util import read_jsonl

FEATURE_KEYS = ("chars","lines","ifs","loops","functions","classes","calls","try_blocks")

def _vector(features: dict) -> list[float]:
    # Log-scale counts to keep huge notebooks from dominating.
    return [math.log1p(float(features.get(k, 0) or 0)) for k in FEATURE_KEYS]

def train(cfg: Config) -> dict:
    """
    Train a lightweight nearest-centroid strategy selector.

    This keeps the repo dependency-light and makes the artifact portable.
    Replace with a fine-tuned LM or ranker later while retaining the same
    corpus schema.
    """
    cfg.validate_scope()
    sft = read_jsonl(cfg.corpus_dir / "sft.jsonl")
    train_rows = [r for r in sft if r["split"] == "train"]
    if not train_rows:
        raise RuntimeError("No training rows. Run `agentsec build-dataset` first.")

    sums = defaultdict(lambda: [0.0] * len(FEATURE_KEYS))
    counts = Counter()
    score_sums = defaultdict(float)
    score_counts = Counter()

    for row in train_rows:
        family = row["target"]["strategy_family"]
        x = _vector(row["input"]["features"])
        for i, v in enumerate(x):
            sums[family][i] += v
        counts[family] += 1
        score = row.get("source_score")
        if isinstance(score, (int, float)):
            score_sums[family] += float(score)
            score_counts[family] += 1

    centroids = {
        family: [v / counts[family] for v in sums[family]]
        for family in counts
    }
    score_prior = {
        family: (score_sums[family] / score_counts[family]) if score_counts[family] else 0.0
        for family in counts
    }

    model = {
        "model_type": "nearest-centroid-strategy-selector",
        "feature_keys": list(FEATURE_KEYS),
        "centroids": centroids,
        "score_prior": score_prior,
        "family_counts": dict(counts),
    }
    cfg.models_dir.mkdir(parents=True, exist_ok=True)
    (cfg.models_dir / "strategy_selector.json").write_text(
        json.dumps(model, indent=2, sort_keys=True),
        encoding="utf-8",
    )

    # Build portfolio ranking.
    portfolio = []
    for family in sorted(counts):
        portfolio.append({
            "family": family,
            "records": counts[family],
            "mean_public_score": score_prior[family] if score_counts[family] else None,
            "scored_records": score_counts[family],
        })
    portfolio.sort(
        key=lambda x: (
            -1 if x["mean_public_score"] is None else x["mean_public_score"],
            x["records"]
        ),
        reverse=True,
    )
    cfg.portfolio_dir.mkdir(parents=True, exist_ok=True)
    (cfg.portfolio_dir / "portfolio.json").write_text(
        json.dumps({"strategies": portfolio}, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return model

def predict(cfg: Config, features: dict, signals: list[str] | None = None) -> list[dict]:
    model_path = cfg.models_dir / "strategy_selector.json"
    if not model_path.exists():
        raise RuntimeError("No trained model. Run `agentsec train` first.")
    model = json.loads(model_path.read_text(encoding="utf-8"))
    x = _vector(features)
    allowed = set(signals or model["centroids"].keys())
    scored = []

    for family, c in model["centroids"].items():
        if family not in allowed:
            continue
        dist = math.sqrt(sum((a-b)**2 for a,b in zip(x,c)))
        prior = float(model["score_prior"].get(family, 0.0))
        # Smaller centroid distance is better; public score is weak prior.
        utility = -dist + 0.10 * prior
        scored.append({
            "family": family,
            "utility": utility,
            "distance": dist,
            "score_prior": prior,
        })
    return sorted(scored, key=lambda z: z["utility"], reverse=True)
