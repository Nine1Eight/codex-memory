from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib, json, re
from typing import Any
import nbformat
from .config import Config
from .util import write_jsonl
EVENT_HINTS = {
    'observation': ('observation','obs','state','context','input','environment'),
    'candidate': ('candidate','option','proposal','plan','branch','choice'),
    'action': ('action','selected','choose','chosen','tool_call','invoke','call'),
    'tool_result': ('tool_result','result','response','output','returned'),
    'reward': ('reward','score','fitness','metric','gain'),
    'terminal': ('done','terminal','success','failure','finished'),
}
KEY_VALUE = re.compile(r'^\s*(?P<key>[A-Za-z_][A-Za-z0-9_\- ]{0,40})\s*[:=]\s*(?P<value>.+?)\s*$')
@dataclass
class TraceEvent:
    event_id: str; source_ref: str; source_file: str; cell_index: int; output_index: int; line_index: int; raw: str; kind: str; value: Any

def _classify_line(line: str):
    s=line.strip()
    if not s: return 'text',''
    if s.startswith('{') and s.endswith('}'):
        try:
            obj=json.loads(s)
            if isinstance(obj,dict):
                keys={str(k).lower() for k in obj}
                for kind,hints in EVENT_HINTS.items():
                    if any(any(h in key for h in hints) for key in keys): return kind,obj
                return 'json',obj
        except Exception: pass
    m=KEY_VALUE.match(s)
    if m:
        key=m.group('key').lower().strip(); value=m.group('value').strip()
        for kind,hints in EVENT_HINTS.items():
            if any(h in key for h in hints):
                if kind=='reward':
                    try: return kind,float(value)
                    except ValueError: pass
                if kind=='terminal':
                    v=value.lower()
                    if v in {'true','yes','1','success','done'}: return kind,True
                    if v in {'false','no','0'}: return kind,False
                return kind,value
    low=s.lower()
    for kind,hints in EVENT_HINTS.items():
        if any(h in low for h in hints): return kind,s
    return 'text',s

def _output_text(output):
    typ=getattr(output,'output_type',None)
    if typ=='stream': return str(output.get('text',''))
    if typ in {'execute_result','display_data'}:
        data=output.get('data',{})
        if 'text/plain' in data: return str(data['text/plain'])
        if 'application/json' in data: return json.dumps(data['application/json'],sort_keys=True,default=str)
    if typ=='error': return '\n'.join(map(str,output.get('traceback') or []))
    return ''

def extract_notebook_output_events(cfg: Config):
    cfg.validate_scope(); events=[]
    for snap in sorted(cfg.raw_dir.glob('*/*/snapshot.json')):
        meta=json.loads(snap.read_text()); ref=meta['ref']
        for nb_path in sorted(snap.parent.glob('*.ipynb')):
            nb=nbformat.read(nb_path,as_version=4)
            for ci,cell in enumerate(nb.cells):
                if cell.get('cell_type')!='code': continue
                for oi,out in enumerate(cell.get('outputs',[])):
                    text=_output_text(out)
                    for li,line in enumerate(text.splitlines()):
                        if not line.strip(): continue
                        kind,value=_classify_line(line)
                        eid=hashlib.sha256(f'{ref}|{nb_path.name}|{ci}|{oi}|{li}|{line}'.encode()).hexdigest()[:24]
                        events.append(asdict(TraceEvent(eid,ref,nb_path.name,ci,oi,li,line,kind,value)))
    write_jsonl(cfg.corpus_dir/'events.jsonl',events); return events

def ingest_external_trace_jsonl(cfg: Config, path: Path):
    cfg.validate_scope(); out=[]
    if not path.exists(): raise FileNotFoundError(path)
    with path.open(encoding='utf-8') as f:
        for lineno,line in enumerate(f,1):
            if not line.strip(): continue
            obj=json.loads(line)
            if not isinstance(obj,dict): raise ValueError(f'{path}:{lineno}: expected JSON object')
            row={
                'source_ref':obj.get('source_ref','external/trace'),
                'episode_id':str(obj.get('episode_id',obj.get('episode','episode-0'))),
                'step':int(obj.get('step',0)),
                'observation':obj.get('observation'),'candidates':obj.get('candidates',[]),
                'action':obj.get('action'),'tool_name':obj.get('tool_name'),'tool_args':obj.get('tool_args'),
                'tool_result':obj.get('tool_result'),'reward':obj.get('reward'),'terminal':obj.get('terminal',False),
                'metadata':obj.get('metadata',{})}
            out.append(row)
    write_jsonl(cfg.corpus_dir/'external_traces.jsonl',out); return out
