from __future__ import annotations
from pathlib import Path
import ast
import json
import re
import nbformat
from .config import Config
from .util import write_jsonl

SIGNAL_PATTERNS = {
    "tool-selection": r"\b(tool|function|action|call|invoke)\b",
    "planning": r"\b(plan|planner|search|beam|tree|branch|candidate)\b",
    "retry": r"\b(retry|retries|retried|retrying|attempt|attempts|backoff|again|loop|loops)\b",
    "scoring": r"\b(score|reward|fitness|metric|rank)\b",
    "state": r"\b(state|memory|history|context|observation)\b",
    "mutation": r"\b(mutate|mutation|variant|rewrite|perturb)\b",
    "validation": r"\b(validate|verify|replay|reproduce|assert|check)\b",
    "termination": r"\b(done|terminal|stop|finish|success|failure)\b",
}

def _code_features(src: str) -> dict:
    f = {
        "chars": len(src),
        "lines": src.count("\n") + 1,
        "ifs": 0,
        "loops": 0,
        "functions": 0,
        "classes": 0,
        "calls": 0,
        "try_blocks": 0,
    }
    try:
        tree = ast.parse(src)
    except SyntaxError:
        return f
    for node in ast.walk(tree):
        if isinstance(node, ast.If): f["ifs"] += 1
        elif isinstance(node, (ast.For, ast.While)): f["loops"] += 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)): f["functions"] += 1
        elif isinstance(node, ast.ClassDef): f["classes"] += 1
        elif isinstance(node, ast.Call): f["calls"] += 1
        elif isinstance(node, ast.Try): f["try_blocks"] += 1
    return f

def _signals(text: str) -> list[str]:
    low = text.lower()
    return sorted(k for k, p in SIGNAL_PATTERNS.items() if re.search(p, low))

def normalize(cfg: Config) -> list[dict]:
    cfg.validate_scope()
    rows = []

    for snap in sorted(cfg.raw_dir.glob("*/*/snapshot.json")):
        meta = json.loads(snap.read_text(encoding="utf-8"))
        ref = meta["ref"]
        score = meta.get("public_score")
        folder = snap.parent
        notebooks = sorted(folder.glob("*.ipynb"))
        scripts = sorted(folder.glob("*.py"))

        for nb_path in notebooks:
            nb = nbformat.read(nb_path, as_version=4)
            for i, cell in enumerate(nb.cells):
                src = cell.get("source", "")
                if not src.strip():
                    continue
                kind = cell.get("cell_type", "unknown")
                rows.append({
                    "source_ref": ref,
                    "source_score": score,
                    "source_file": nb_path.name,
                    "unit_index": i,
                    "unit_type": kind,
                    "signals": _signals(src),
                    "features": _code_features(src) if kind == "code" else {
                        "chars": len(src),
                        "lines": src.count("\n") + 1,
                    },
                    # Keep text locally for extraction, but dataset builder can redact it.
                    "text": src,
                })

        for py_path in scripts:
            src = py_path.read_text(encoding="utf-8", errors="replace")
            rows.append({
                "source_ref": ref,
                "source_score": score,
                "source_file": py_path.name,
                "unit_index": 0,
                "unit_type": "script",
                "signals": _signals(src),
                "features": _code_features(src),
                "text": src,
            })

    write_jsonl(cfg.normalized, rows)
    return rows
