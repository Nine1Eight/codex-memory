from __future__ import annotations
from collections import defaultdict
import hashlib
from .config import Config
from .util import read_jsonl, write_jsonl

def _new_step():
    return {'observation':None,'candidates':[],'action':None,'tool_name':None,'tool_args':None,'tool_result':None,'reward':None,'terminal':False,'evidence_event_ids':[]}

def reconstruct_from_events(cfg: Config):
    cfg.validate_scope(); events=read_jsonl(cfg.corpus_dir/'events.jsonl'); grouped=defaultdict(list)
    for e in events: grouped[(e['source_ref'],e['source_file'])].append(e)
    episodes=[]
    for (ref,file),group in sorted(grouped.items()):
        group.sort(key=lambda e:(e['cell_index'],e['output_index'],e['line_index']))
        steps=[]; cur=_new_step()
        def flush():
            nonlocal cur
            if cur['evidence_event_ids']:
                cur['step']=len(steps); steps.append(cur); cur=_new_step()
        for e in group:
            kind=e['kind']; value=e.get('value') if e.get('value') not in (None,'') else e.get('raw')
            if kind=='observation' and (cur['action'] is not None or cur['tool_result'] is not None or cur['reward'] is not None): flush()
            cur['evidence_event_ids'].append(e['event_id'])
            if kind=='observation': cur['observation']=value
            elif kind=='candidate': cur['candidates'].append(value)
            elif kind=='action':
                if cur['action'] is not None:
                    flush(); cur['evidence_event_ids'].append(e['event_id'])
                cur['action']=value
            elif kind=='tool_result': cur['tool_result']=value
            elif kind=='reward': cur['reward']=value
            elif kind=='terminal': cur['terminal']=bool(value); flush()
        flush()
        if not steps: continue
        present=sum(step.get(k) not in (None,'',[]) for step in steps for k in ('observation','action','tool_result','reward'))
        possible=len(steps)*4
        quality=present/possible if possible else 0.0
        eid=hashlib.sha256(f'{ref}|{file}'.encode()).hexdigest()[:20]
        episodes.append({'episode_id':eid,'source_ref':ref,'source_file':file,'origin':'notebook-output-reconstruction','reconstruction_quality':round(quality,4),'steps':steps})
    write_jsonl(cfg.corpus_dir/'episodes_reconstructed.jsonl',episodes); return episodes

def build_external_episodes(cfg: Config):
    rows=read_jsonl(cfg.corpus_dir/'external_traces.jsonl'); grouped=defaultdict(list)
    for r in rows: grouped[(r['source_ref'],r['episode_id'])].append(r)
    episodes=[]
    for (ref,eid),group in sorted(grouped.items()):
        group.sort(key=lambda x:x['step']); episodes.append({'episode_id':eid,'source_ref':ref,'source_file':None,'origin':'external-trace','reconstruction_quality':1.0,'steps':group})
    write_jsonl(cfg.corpus_dir/'episodes_external.jsonl',episodes); return episodes

def merge_episodes(cfg: Config):
    merged=read_jsonl(cfg.corpus_dir/'episodes_reconstructed.jsonl')+read_jsonl(cfg.corpus_dir/'episodes_external.jsonl')
    write_jsonl(cfg.corpus_dir/'episodes.jsonl',merged); return merged
