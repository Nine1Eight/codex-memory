from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
import ast, difflib, hashlib, json, math, re, shutil, time
import nbformat

from .config import Config
from .util import read_jsonl, sha256_file, write_jsonl

TOK = re.compile(r'[A-Za-z_][A-Za-z0-9_]{1,63}')


def _version_root(cfg: Config) -> Path:
    return cfg.workspace / 'versions'


def _history_path(cfg: Config) -> Path:
    return _version_root(cfg) / 'history.jsonl'


def _files(folder: Path) -> list[Path]:
    return sorted(folder.glob('*.ipynb')) + sorted(folder.glob('*.py'))


def _combined_hash(paths: list[Path]) -> str:
    h = hashlib.sha256()
    for p in paths:
        h.update(p.name.encode())
        h.update(sha256_file(p).encode())
    return h.hexdigest()


def capture_versions(cfg: Config) -> list[dict]:
    """Save a new immutable version whenever a public notebook changes."""
    cfg.validate_scope()
    history = read_jsonl(_history_path(cfg))
    latest = {}
    for row in history:
        latest[row['source_ref']] = row
    created = []
    for snap in sorted(cfg.raw_dir.glob('*/*/snapshot.json')):
        meta = json.loads(snap.read_text(encoding='utf-8'))
        ref = meta['ref']
        paths = _files(snap.parent)
        if not paths:
            continue
        chash = _combined_hash(paths)
        prev = latest.get(ref)
        if prev and prev.get('content_sha256') == chash:
            continue
        version_id = f"{int(time.time())}-{chash[:12]}"
        owner, slug = ref.split('/', 1)
        dest = _version_root(cfg) / owner / slug / version_id
        dest.mkdir(parents=True, exist_ok=True)
        for src in paths:
            shutil.copy2(src, dest / src.name)
        row = {
            'source_ref': ref,
            'version_id': version_id,
            'captured_unix': int(time.time()),
            'public_score': meta.get('public_score'),
            'source_path': str(dest),
            'content_sha256': chash,
        }
        history.append(row)
        latest[ref] = row
        created.append(row)
    write_jsonl(_history_path(cfg), history)
    return created


def import_version(cfg: Config, source_ref: str, notebook_path: Path,
                   public_score: float | None = None,
                   version_label: str | None = None) -> dict:
    cfg.validate_scope()
    if not notebook_path.exists():
        raise FileNotFoundError(notebook_path)
    chash = sha256_file(notebook_path)
    label = version_label or f"import-{int(time.time())}-{chash[:12]}"
    owner, slug = source_ref.split('/', 1)
    dest = _version_root(cfg) / owner / slug / label
    dest.mkdir(parents=True, exist_ok=True)
    shutil.copy2(notebook_path, dest / notebook_path.name)
    row = {
        'source_ref': source_ref,
        'version_id': label,
        'captured_unix': int(time.time()),
        'public_score': public_score,
        'source_path': str(dest),
        'content_sha256': chash,
    }
    history = read_jsonl(_history_path(cfg))
    history.append(row)
    write_jsonl(_history_path(cfg), history)
    return row


def _load_units(version: dict) -> list[dict]:
    folder = Path(version['source_path'])
    out = []
    for path in sorted(folder.glob('*.ipynb')):
        nb = nbformat.read(path, as_version=4)
        for idx, cell in enumerate(nb.cells):
            out.append({'file': path.name, 'unit_index': idx,
                        'unit_type': cell.get('cell_type', 'unknown'),
                        'text': str(cell.get('source', ''))})
    for path in sorted(folder.glob('*.py')):
        out.append({'file': path.name, 'unit_index': 0, 'unit_type': 'script',
                    'text': path.read_text(encoding='utf-8', errors='replace')})
    return out


def _tokens(text: str) -> Counter:
    return Counter(x.lower() for x in TOK.findall(text))


def _ast_counts(text: str) -> Counter:
    c = Counter()
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return c
    for n in ast.walk(tree):
        c[type(n).__name__] += 1
    return c


def diff_pair(old: dict, new: dict) -> dict:
    ou = {(u['file'], u['unit_index'], u['unit_type']): u for u in _load_units(old)}
    nu = {(u['file'], u['unit_index'], u['unit_type']): u for u in _load_units(new)}
    changes, add_all, rem_all, ast_all = [], Counter(), Counter(), Counter()
    for key in sorted(set(ou) | set(nu)):
        before, after = ou.get(key, {}).get('text', ''), nu.get(key, {}).get('text', '')
        if before == after:
            continue
        bt, at = _tokens(before), _tokens(after)
        added, removed = at - bt, bt - at
        add_all.update(added); rem_all.update(removed)
        ba, aa = _ast_counts(before), _ast_counts(after)
        ad = Counter()
        for k in set(ba) | set(aa):
            d = aa[k] - ba[k]
            if d:
                ad[k] = d; ast_all[k] += d
        changes.append({
            'file': key[0], 'unit_index': key[1], 'unit_type': key[2],
            'similarity': round(difflib.SequenceMatcher(a=before,b=after).ratio(), 6),
            'added_tokens': dict(added.most_common(30)),
            'removed_tokens': dict(removed.most_common(30)),
            'ast_delta': dict(ad),
            'unified_diff': '\n'.join(difflib.unified_diff(
                before.splitlines(), after.splitlines(), fromfile='before', tofile='after', lineterm=''))[:20000],
        })
    oscore, nscore = old.get('public_score'), new.get('public_score')
    delta = float(nscore)-float(oscore) if isinstance(oscore,(int,float)) and isinstance(nscore,(int,float)) else None
    pid = hashlib.sha256(f"{old['source_ref']}|{old['version_id']}|{new['version_id']}".encode()).hexdigest()[:24]
    return {
        'pair_id': pid, 'source_ref': old['source_ref'],
        'old_version_id': old['version_id'], 'new_version_id': new['version_id'],
        'old_score': oscore, 'new_score': nscore, 'score_delta': delta,
        'direction': 'improved' if delta is not None and delta>0 else 'regressed' if delta is not None and delta<0 else 'flat_or_unknown',
        'changed_units': len(changes), 'added_tokens': dict(add_all.most_common(100)),
        'removed_tokens': dict(rem_all.most_common(100)), 'ast_delta': dict(ast_all), 'changes': changes,
    }


def build_version_diffs(cfg: Config) -> list[dict]:
    history = read_jsonl(_history_path(cfg))
    by_ref = defaultdict(list)
    seen = set()
    for r in history:
        key=(r['source_ref'],r['version_id'])
        if key not in seen:
            seen.add(key); by_ref[r['source_ref']].append(r)
    pairs=[]
    for _, versions in sorted(by_ref.items()):
        versions.sort(key=lambda x:(x.get('captured_unix',0), x['version_id']))
        for a,b in zip(versions,versions[1:]):
            if a.get('content_sha256') != b.get('content_sha256'):
                pairs.append(diff_pair(a,b))
    write_jsonl(cfg.corpus_dir/'version_diffs.jsonl', pairs)
    return pairs


def build_diff_learning_dataset(cfg: Config, min_abs_delta: float = 0.0) -> dict:
    pairs=read_jsonl(cfg.corpus_dir/'version_diffs.jsonl')
    rows=[]; good=defaultdict(list); bad=defaultdict(list)
    for p in pairs:
        d=p.get('score_delta')
        if not isinstance(d,(int,float)) or abs(d)<min_abs_delta or not p.get('changed_units'):
            continue
        row={'pair_id':p['pair_id'],'source_ref':p['source_ref'],'old_score':p['old_score'],
             'new_score':p['new_score'],'target_score_delta':d,'direction':p['direction'],
             'patch':{'added_tokens':p['added_tokens'],'removed_tokens':p['removed_tokens'],
                      'ast_delta':p['ast_delta'],'changed_units':p['changed_units']},
             'evidence_strength':'weak_leaderboard_supervision'}
        rows.append(row)
        (good if d>0 else bad if d<0 else defaultdict(list))[p['source_ref']].append(row)
    prefs=[]
    for ref in sorted(set(good)&set(bad)):
        for g in good[ref]:
            b=min(bad[ref], key=lambda r:r['target_score_delta'])
            prefs.append({'source_ref':ref,'preferred_patch':g['patch'],'rejected_patch':b['patch'],
                          'preferred_delta':g['target_score_delta'],'rejected_delta':b['target_score_delta']})
    write_jsonl(cfg.corpus_dir/'diff_regression.jsonl', rows)
    write_jsonl(cfg.corpus_dir/'diff_preferences.jsonl', prefs)
    manifest={'version_pairs':len(pairs),'scored_diffs':len(rows),
              'improvements':sum(r['target_score_delta']>0 for r in rows),
              'regressions':sum(r['target_score_delta']<0 for r in rows),
              'preference_pairs':len(prefs),'min_abs_delta':min_abs_delta}
    cfg.corpus_dir.mkdir(parents=True, exist_ok=True)
    (cfg.corpus_dir/'diff_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True),encoding='utf-8')
    return manifest


def train_diff_model(cfg: Config) -> dict:
    rows=read_jsonl(cfg.corpus_dir/'diff_regression.jsonl')
    if not rows: raise RuntimeError('No diff learning rows.')
    effects=defaultdict(lambda:[0.0,0])
    for r in rows:
        y=float(r['target_score_delta']); p=r['patch']
        for t,c in p.get('added_tokens',{}).items(): effects['add:'+t][0]+=y*math.log1p(c); effects['add:'+t][1]+=1
        for t,c in p.get('removed_tokens',{}).items(): effects['remove:'+t][0]+=y*math.log1p(c); effects['remove:'+t][1]+=1
        for n,d in p.get('ast_delta',{}).items(): effects['ast:'+n][0]+=y*(1 if d>0 else -1)*math.log1p(abs(d)); effects['ast:'+n][1]+=1
    model={'model_type':'notebook-difference-effect-model','feature_effects':{k:v[0]/v[1] for k,v in effects.items() if v[1]},
           'training_rows':len(rows),'warning':'Associational weak supervision; score movement is not proof of causation.'}
    cfg.models_dir.mkdir(parents=True, exist_ok=True)
    (cfg.models_dir/'diff_effect_model.json').write_text(json.dumps(model,indent=2,sort_keys=True),encoding='utf-8')
    return model
