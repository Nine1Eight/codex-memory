from dataclasses import dataclass
from pathlib import Path

COMPETITION = "ai-agent-security-multi-step-tool-attacks"

@dataclass(frozen=True)
class Config:
    workspace: Path = Path("workspace")
    competition: str = COMPETITION

    def validate_scope(self) -> None:
        if self.competition != COMPETITION:
            raise ValueError(
                f"This build is competition-scoped and only supports {COMPETITION!r}."
            )

    @property
    def discovered(self) -> Path:
        return self.workspace / "discovered" / "notebooks.jsonl"

    @property
    def raw_dir(self) -> Path:
        return self.workspace / "raw"

    @property
    def normalized(self) -> Path:
        return self.workspace / "normalized" / "records.jsonl"

    @property
    def corpus_dir(self) -> Path:
        return self.workspace / "corpus"

    @property
    def portfolio_dir(self) -> Path:
        return self.workspace / "portfolio"

    @property
    def models_dir(self) -> Path:
        return self.workspace / "models"
