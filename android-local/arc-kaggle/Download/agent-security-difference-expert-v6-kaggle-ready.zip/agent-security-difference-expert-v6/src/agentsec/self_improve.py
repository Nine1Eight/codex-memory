from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from typing import Any

from .config import Config
from .difference_expert import evaluate_patch
from .util import read_jsonl, write_jsonl


@dataclass
class Proposal:
    proposal_id: str
    source_ref: str
    patch: dict[str, Any]
    predicted_direction: str
    predicted_signal: float
    confidence: float
    rationale: dict[str, Any]


def _stable_id(payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode()).hexdigest()[:24]


def _top_features(cfg: Config, limit: int = 40) -> list[tuple[str, dict]]:
    path = cfg.models_dir / "difference_expert.json"
    if not path.exists():
        raise RuntimeError("Train the Difference Expert first.")
    model = json.loads(path.read_text(encoding="utf-8"))
    rows = list(model.get("feature_effects", {}).items())
    rows.sort(
        key=lambda kv: abs(float(kv[1].get("mean_effect", 0.0)))
        * float(kv[1].get("reliability", 0.0)),
        reverse=True,
    )
    return rows[:limit]


def _feature_to_patch(feature: str) -> dict:
    patch = {
        "added_tokens": {},
        "removed_tokens": {},
        "ast_delta": {},
        "changed_units": 1,
        "strategy_families": [],
    }
    if ":" not in feature:
        return patch
    prefix, key = feature.split(":", 1)
    if prefix == "add":
        patch["added_tokens"][key] = 1
    elif prefix == "remove":
        patch["removed_tokens"][key] = 1
    elif prefix == "ast":
        patch["ast_delta"][key] = 1
    elif prefix == "strategy":
        patch["strategy_families"].append(key)
    return patch


def _merge_patches(parts: list[dict]) -> dict:
    out = {
        "added_tokens": {},
        "removed_tokens": {},
        "ast_delta": {},
        "changed_units": 0,
        "strategy_families": [],
    }
    for p in parts:
        for k, v in (p.get("added_tokens") or {}).items():
            out["added_tokens"][k] = out["added_tokens"].get(k, 0) + int(v)
        for k, v in (p.get("removed_tokens") or {}).items():
            out["removed_tokens"][k] = out["removed_tokens"].get(k, 0) + int(v)
        for k, v in (p.get("ast_delta") or {}).items():
            out["ast_delta"][k] = out["ast_delta"].get(k, 0) + int(v)
        out["changed_units"] += int(p.get("changed_units", 0) or 0)
        for fam in p.get("strategy_families", []) or []:
            if fam not in out["strategy_families"]:
                out["strategy_families"].append(fam)
    out["changed_units"] = max(1, out["changed_units"])
    return out


def propose_changes(
    cfg: Config,
    source_ref: str = "candidate/notebook",
    max_proposals: int = 12,
    min_confidence: float = 0.05,
) -> list[dict]:
    """Generate auditable structural change specifications from learned effects."""
    cfg.validate_scope()
    top = _top_features(cfg, limit=max(50, max_proposals * 5))
    positives = [
        (feature, info)
        for feature, info in top
        if float(info.get("mean_effect", 0.0)) > 0
        and float(info.get("reliability", 0.0)) >= min_confidence
    ]

    proposals: list[dict] = []
    for feature, info in positives[:max_proposals]:
        patch = _feature_to_patch(feature)
        ev = evaluate_patch(cfg, patch)
        proposals.append(
            Proposal(
                proposal_id=_stable_id({"source_ref": source_ref, "patch": patch}),
                source_ref=source_ref,
                patch=patch,
                predicted_direction=ev["direction"],
                predicted_signal=float(ev["predicted_score_delta_signal"]),
                confidence=float(ev["confidence"]),
                rationale={
                    "basis_feature": feature,
                    "learned_effect": info.get("mean_effect"),
                    "reliability": info.get("reliability"),
                    "independent_sources": info.get("independent_sources"),
                    "samples": info.get("samples"),
                },
            ).__dict__
        )

    strongest = positives[: min(8, len(positives))]
    for i in range(len(strongest)):
        for j in range(i + 1, len(strongest)):
            if len(proposals) >= max_proposals:
                break
            patch = _merge_patches([
                _feature_to_patch(strongest[i][0]),
                _feature_to_patch(strongest[j][0]),
            ])
            ev = evaluate_patch(cfg, patch)
            proposals.append(
                Proposal(
                    proposal_id=_stable_id({"source_ref": source_ref, "patch": patch}),
                    source_ref=source_ref,
                    patch=patch,
                    predicted_direction=ev["direction"],
                    predicted_signal=float(ev["predicted_score_delta_signal"]),
                    confidence=float(ev["confidence"]),
                    rationale={
                        "basis_features": [strongest[i][0], strongest[j][0]],
                        "composition": "pairwise",
                    },
                ).__dict__
            )
        if len(proposals) >= max_proposals:
            break

    proposals.sort(
        key=lambda r: (
            r["predicted_direction"] == "likely_improving",
            r["confidence"],
            r["predicted_signal"],
        ),
        reverse=True,
    )
    write_jsonl(cfg.corpus_dir / "proposals.jsonl", proposals)
    return proposals


def experiment_queue(cfg: Config, budget: int = 5, exploration_rate: float = 0.20) -> list[dict]:
    """Mix exploitation and uncertainty-seeking exploration in a test queue."""
    props = read_jsonl(cfg.corpus_dir / "proposals.jsonl")
    if not props:
        raise RuntimeError("No proposals. Run propose-changes first.")
    budget = max(1, min(int(budget), len(props)))
    exploration_rate = max(0.0, min(1.0, float(exploration_rate)))

    exploit_n = max(1, int(round(budget * (1.0 - exploration_rate))))
    exploit = sorted(
        props,
        key=lambda p: p["predicted_signal"] * max(p["confidence"], 1e-6),
        reverse=True,
    )[:exploit_n]
    chosen = {p["proposal_id"] for p in exploit}
    remaining = [p for p in props if p["proposal_id"] not in chosen]
    remaining.sort(
        key=lambda p: abs(p["predicted_signal"]) * (1.0 - p["confidence"]),
        reverse=True,
    )
    selected = exploit + remaining[: max(0, budget - len(exploit))]

    queue = []
    for rank, p in enumerate(selected, start=1):
        queue.append({
            "queue_rank": rank,
            "proposal_id": p["proposal_id"],
            "source_ref": p["source_ref"],
            "patch": p["patch"],
            "predicted_direction": p["predicted_direction"],
            "predicted_signal": p["predicted_signal"],
            "confidence": p["confidence"],
            "mode": "exploit" if p["proposal_id"] in chosen else "explore",
        })
    write_jsonl(cfg.corpus_dir / "experiment_queue.jsonl", queue)
    return queue


def register_trial(
    cfg: Config,
    proposal_id: str,
    measured_score_before: float,
    measured_score_after: float,
    status: str = "completed",
    notes: str | None = None,
) -> dict:
    """Register a measured result from a reviewed/sandboxed competition run."""
    cfg.validate_scope()
    proposals = {
        p["proposal_id"]: p
        for p in read_jsonl(cfg.corpus_dir / "proposals.jsonl")
    }
    if proposal_id not in proposals:
        raise ValueError(f"Unknown proposal_id: {proposal_id}")
    p = proposals[proposal_id]
    delta = float(measured_score_after) - float(measured_score_before)
    row = {
        "trial_id": _stable_id({
            "proposal_id": proposal_id,
            "before": measured_score_before,
            "after": measured_score_after,
        }),
        "proposal_id": proposal_id,
        "source_ref": p["source_ref"],
        "patch": p["patch"],
        "predicted_direction": p["predicted_direction"],
        "predicted_signal": p["predicted_signal"],
        "predicted_confidence": p["confidence"],
        "measured_score_before": float(measured_score_before),
        "measured_score_after": float(measured_score_after),
        "measured_score_delta": delta,
        "measured_direction": "improved" if delta > 0 else "regressed" if delta < 0 else "flat",
        "status": status,
        "notes": notes,
    }
    path = cfg.corpus_dir / "trials.jsonl"
    rows = read_jsonl(path)
    rows.append(row)
    write_jsonl(path, rows)
    return row


def learn_from_trials(cfg: Config) -> dict:
    """Feed measured proposal outcomes back into the difference-learning corpus."""
    cfg.validate_scope()
    trials = [
        r for r in read_jsonl(cfg.corpus_dir / "trials.jsonl")
        if r.get("status") == "completed"
    ]
    if not trials:
        raise RuntimeError("No completed trials.")
    rows = read_jsonl(cfg.corpus_dir / "diff_regression.jsonl")
    existing = {r.get("pair_id") for r in rows}
    added = 0
    for t in trials:
        pair_id = f"trial:{t['trial_id']}"
        if pair_id in existing:
            continue
        rows.append({
            "pair_id": pair_id,
            "source_ref": t["source_ref"],
            "old_score": t["measured_score_before"],
            "new_score": t["measured_score_after"],
            "target_score_delta": t["measured_score_delta"],
            "direction": t["measured_direction"],
            "patch": t["patch"],
            "origin": "difference-expert-self-trial",
            "proposal_id": t["proposal_id"],
        })
        existing.add(pair_id)
        added += 1
    write_jsonl(cfg.corpus_dir / "diff_regression.jsonl", rows)
    return {
        "completed_trials": len(trials),
        "new_training_rows_added": added,
        "total_diff_rows": len(rows),
    }
