from __future__ import annotations
import hashlib, json, random
from .config import Config
from .util import read_jsonl, write_jsonl

def _splits(episodes):
    refs=sorted({e['source_ref'] for e in episodes}); r=random.Random(918); r.shuffle(refs); n=len(refs); nt=max(1,int(n*.8)) if n else 0; nv=int(n*.1)
    return {ref:('train' if i<nt else ('validation' if i<nt+nv else 'test')) for i,ref in enumerate(refs)}

def _context(ep,i):
    hist=[{'observation':p.get('observation'),'action':p.get('action'),'tool_result':p.get('tool_result'),'reward':p.get('reward')} for p in ep['steps'][max(0,i-3):i]]
    s=ep['steps'][i]
    return {'recent_history':hist,'observation':s.get('observation'),'candidates':s.get('candidates') or [],'tool_name':s.get('tool_name'),'terminal':bool(s.get('terminal',False))}

def build_trajectory_datasets(cfg: Config,min_quality:float=.25):
    cfg.validate_scope(); eps=[e for e in read_jsonl(cfg.corpus_dir/'episodes.jsonl') if float(e.get('reconstruction_quality',0))>=min_quality]
    if not eps: raise RuntimeError('No episodes meet quality threshold')
    split=_splits(eps); sft=[]; prefs=[]; replay=[]
    for ep in eps:
        sp=split[ep['source_ref']]
        for i,s in enumerate(ep['steps']):
            action=s.get('action'); ctx=_context(ep,i); rid=hashlib.sha256(f"{ep['episode_id']}|{i}".encode()).hexdigest()[:24]
            if action not in (None,''):
                sft.append({'id':rid,'split':sp,'source_ref':ep['source_ref'],'episode_id':ep['episode_id'],'step':i,'quality':ep.get('reconstruction_quality',0),'input':ctx,'target':{'action':action,'tool_args':s.get('tool_args')},'outcome':{'tool_result':s.get('tool_result'),'reward':s.get('reward'),'terminal':s.get('terminal',False)}})
            cands=s.get('candidates') or []
            if action not in (None,'') and cands:
                rej=[c for c in cands if str(c)!=str(action)]
                if rej: prefs.append({'id':rid,'split':sp,'source_ref':ep['source_ref'],'context':ctx,'preferred':action,'rejected':rej,'evidence':{'reward':s.get('reward'),'tool_result_present':s.get('tool_result') is not None}})
            if i+1<len(ep['steps']) and action not in (None,''):
                replay.append({'id':rid,'split':sp,'source_ref':ep['source_ref'],'episode_id':ep['episode_id'],'step':i,'state':ctx,'action':action,'tool_args':s.get('tool_args'),'result':s.get('tool_result'),'reward':s.get('reward'),'next_observation':ep['steps'][i+1].get('observation'),'terminal':bool(s.get('terminal',False)),'quality':ep.get('reconstruction_quality',0)})
    write_jsonl(cfg.corpus_dir/'trajectory_sft.jsonl',sft); write_jsonl(cfg.corpus_dir/'trajectory_preferences.jsonl',prefs); write_jsonl(cfg.corpus_dir/'replay.jsonl',replay)
    m={'episodes_used':len(eps),'trajectory_sft_records':len(sft),'trajectory_preference_records':len(prefs),'replay_records':len(replay),'min_quality':min_quality,'sources':len({e['source_ref'] for e in eps})}
    (cfg.corpus_dir/'trajectory_manifest.json').write_text(json.dumps(m,indent=2,sort_keys=True)); return m
