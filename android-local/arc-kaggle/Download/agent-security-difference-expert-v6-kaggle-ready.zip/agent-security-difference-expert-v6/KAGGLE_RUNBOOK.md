# Kaggle Runbook — ADL Difference Expert

This bundle is scoped to the Kaggle competition `ai-agent-security-multi-step-tool-attacks`.
It analyzes **public competition notebooks and their observable artifacts**. Downloaded
notebooks are parsed; arbitrary notebook code is not automatically executed.

## Recommended Kaggle settings

- Notebook: Python
- Internet: On when using Kaggle CLI discovery/snapshot commands
- Accelerator: None required for the corpus/difference learner
- Persistence: save `/kaggle/working/workspace` as an output if you want the next run
  to compare the newly observed notebook versions against the previous snapshot.

## One-run workflow

```bash
agentsec doctor
agentsec discover --top 50 --sort scoreDescending
agentsec snapshot
agentsec normalize
agentsec extract
agentsec build-dataset
agentsec capture-versions
agentsec build-version-diffs
agentsec build-diff-dataset --min-abs-delta 0.001
```

On the first snapshot there may be no version-to-version differences yet. Re-run after
public notebooks change, or import archived versions with their historical public scores.

Once scored differences exist:

```bash
agentsec build-cross-notebook-evidence --similarity-threshold 0.35 --min-abs-delta 0.001
agentsec build-difference-curriculum
agentsec train-difference-expert
agentsec propose-changes --source-ref candidate/notebook --max-proposals 12
agentsec experiment-queue --budget 5 --exploration-rate 0.20
```

After a reviewed competition experiment produces a real before/after public score:

```bash
agentsec register-trial <PROPOSAL_ID> --before 0.50 --after 0.56
agentsec learn-from-trials
agentsec build-cross-notebook-evidence
agentsec build-difference-curriculum
agentsec train-difference-expert
```

This closes the ADL loop: **difference → predicted effect → measured trial → learned effect**.
