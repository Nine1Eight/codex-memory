#!/usr/bin/env python3
"""B8NN codec: Unicode 8-dot braille glyphs as a byte-exact transport.

Mapping:
    byte b (0..255) <-> Unicode Braille Pattern chr(0x2800 + b)

Usage:
    python b8nn_codec.py decode ARC_AGI_3_FULL_LOSSLESS_NODE.b8glyph restored.json
    python b8nn_codec.py restore-md ARC_AGI_3_FULL_LOSSLESS_NODE.b8glyph restored.md
    python b8nn_codec.py encode input.json output.b8glyph
    python b8nn_codec.py selftest ARC_AGI_3_FULL_LOSSLESS_NODE.b8glyph
"""
from __future__ import annotations
import argparse, json, zlib, hashlib
from pathlib import Path
BRAILLE_BASE = 0x2800
BRAILLE_END = 0x28FF

def bytes_to_braille(data: bytes) -> str:
    return ''.join(chr(BRAILLE_BASE + b) for b in data)

def braille_to_bytes(text: str) -> bytes:
    vals = []
    for ch in text:
        cp = ord(ch)
        if BRAILLE_BASE <= cp <= BRAILLE_END:
            vals.append(cp - BRAILLE_BASE)
    return bytes(vals)

def encode_json_bytes(raw_json: bytes) -> str:
    return bytes_to_braille(zlib.compress(raw_json, level=9))

def decode_to_json_bytes(glyph_text: str) -> bytes:
    return zlib.decompress(braille_to_bytes(glyph_text))

def cmd_encode(args: argparse.Namespace) -> None:
    raw = Path(args.input).read_bytes()
    obj = json.loads(raw.decode('utf-8'))
    canonical = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    Path(args.output).write_text(encode_json_bytes(canonical), encoding='utf-8')

def cmd_decode(args: argparse.Namespace) -> None:
    glyphs = Path(args.input).read_text(encoding='utf-8')
    raw = decode_to_json_bytes(glyphs)
    Path(args.output).write_bytes(raw)

def cmd_restore_md(args: argparse.Namespace) -> None:
    glyphs = Path(args.input).read_text(encoding='utf-8')
    obj = json.loads(decode_to_json_bytes(glyphs).decode('utf-8'))
    if 'source_markdown' not in obj:
        raise SystemExit('No source_markdown field found; use the FULL_LOSSLESS node.')
    Path(args.output).write_text(obj['source_markdown'], encoding='utf-8')
    print(hashlib.sha256(obj['source_markdown'].encode('utf-8')).hexdigest())

def cmd_selftest(args: argparse.Namespace) -> None:
    glyphs = Path(args.input).read_text(encoding='utf-8')
    raw = decode_to_json_bytes(glyphs)
    obj = json.loads(raw.decode('utf-8'))
    print(json.dumps({'ok': True,'format': obj.get('format'),'name': obj.get('name'),'source_sha256': obj.get('source_sha256'),'has_source_markdown': 'source_markdown' in obj,'agent_count': len(obj.get('agent_index', [])),'decoded_json_bytes': len(raw)}, indent=2))

def main() -> None:
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(required=True)
    e = sub.add_parser('encode'); e.add_argument('input'); e.add_argument('output'); e.set_defaults(func=cmd_encode)
    d = sub.add_parser('decode'); d.add_argument('input'); d.add_argument('output'); d.set_defaults(func=cmd_decode)
    r = sub.add_parser('restore-md'); r.add_argument('input'); r.add_argument('output'); r.set_defaults(func=cmd_restore_md)
    s = sub.add_parser('selftest'); s.add_argument('input'); s.set_defaults(func=cmd_selftest)
    args = p.parse_args(); args.func(args)
if __name__ == '__main__':
    main()
