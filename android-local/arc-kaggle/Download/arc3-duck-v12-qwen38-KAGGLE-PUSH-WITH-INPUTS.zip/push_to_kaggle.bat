@echo off
cd /d %~dp0
echo Pushing notebook with ARC + TAAF + vLLM + Qwen3.8 inputs...
kaggle kernels push -p .
pause
