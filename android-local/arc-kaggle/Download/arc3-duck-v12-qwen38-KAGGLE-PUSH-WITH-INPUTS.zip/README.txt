THIS PACKAGE IS THE INPUT-ATTACHING VERSION

Do NOT upload only the .ipynb if you need all four inputs automatically.

Use:
  kaggle kernels push -p "arc3_qwen38_kaggle_push"

kernel-metadata.json attaches:
  competition: arc-prize-2026-arc-agi-3
  dataset: jeroencottaar/taaf-kaggle-source-share
  dataset: driessmit1/arc3-vllm-h100-wheelhouse-v3
  dataset: driessmit1/qwen3-8-27b-fp8-hf-017b9c7a

Required served model:
  Qwen/Qwen3.8-27B-FP8

The .ipynb itself also embeds the numeric source IDs already known from a
working ARC notebook for:
  - ARC competition
  - TAAF source
  - vLLM wheelhouse

The Qwen3.8 dataset is deliberately attached by Kaggle slug through the CLI
metadata, because its internal datasetVersion sourceId is not present in the
downloaded notebook metadata we currently have.

At startup the notebook prints a KAGGLE INPUT PREFLIGHT and aborts before
installation/inference if any required input is missing.
