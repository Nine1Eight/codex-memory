#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Pushing notebook with ARC + TAAF + vLLM + Qwen3.8 inputs..."
kaggle kernels push -p .
