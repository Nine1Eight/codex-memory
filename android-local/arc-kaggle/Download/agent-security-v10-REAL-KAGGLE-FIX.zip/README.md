# V10 REAL KAGGLE FIX

Web-researched fixes applied:

1. Visible committed notebook writes BOTH `attack.py` and a valid four-row `submission.csv`.
2. Hidden rerun starts `JEDAttackInferenceServer().serve()` and lets the gateway overwrite the placeholder.
3. `AttackCandidate.user_messages` is a native `list[str]`, not a tuple.
4. Default remote profile is `fast` (64 returned candidates) to reduce replay timeout/format-error risk.
5. No stale-submission deletion immediately before `serve()`.

Attack SHA-256: `1f46733755921bbf4843910b5bbf1f5fbf4f86b3dc9506387fbd7da84fc3f730`

Submit `ai-agent-security-v10-REAL-SCORED-KAGGLE.ipynb` from the Kaggle notebook UI after **Save & Run All**.
