import zipfile
import os
import argparse

def package_submission(out_zip: str):
    with zipfile.ZipFile(out_zip, 'w') as z:
        for root, dirs, files in os.walk('.'):
            for file in files:
                if not file.endswith('.pyc') and 'runs' not in root:
                    z.write(os.path.join(root, file))
    print(f"Packaged: {out_zip}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="sigil_route_agent_kaggle_submission.zip")
    args = parser.parse_args()
    os.chdir("/home/workdir/artifacts/sigil_route_agent_e2e")
    package_submission(args.out)