import os
from sigil_route_agent.demo import run_demo
# For Kaggle compatibility

def run_competition():
    """Entry point for Kaggle."""
    # Placeholder for competition loop
    print("Sigil Route Agent running in competition mode.")
    # Simulate
    run_demo()  # or adapt

if __name__ == "__main__":
    run_competition()