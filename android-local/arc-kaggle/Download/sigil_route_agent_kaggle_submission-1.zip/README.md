# Sigil Route Agent E2E

Full symbolic reasoning agent for grid puzzles.

See diagrams/full_textual_diagram.txt for architecture.