import pytest
from sigil_route_agent.synthetic import generate_demo_run
from sigil_route_agent.demo import run_demo

def test_demo():
    run_demo("/tmp/test_demo")
    assert True  # placeholder

def test_synthetic():
    generate_demo_run("/tmp/test")
    assert True

if __name__ == "__main__":
    pytest.main()