from typing import List, Optional
from .schema import GameState, Delta, GameObject, ObjectType

class TemporalDeltaEngine:
    def compute_delta(self, state_t: GameState, action: str, state_tp1: GameState) -> Delta:
        delta = Delta(action=action)
        
        # Compare objects
        prev_pos = {obj.position: obj for obj in state_t.objects}
        curr_pos = {obj.position: obj for obj in state_tp1.objects}
        
        for pos, obj in prev_pos.items():
            if pos not in curr_pos:
                delta.deleted.append(obj)
        
        for pos, obj in curr_pos.items():
            if pos not in prev_pos:
                delta.created.append(obj)
            elif prev_pos[pos] != obj:  # position or type change
                delta.moved_objects.append((obj, pos))
        
        # Inventory and terminal
        if state_tp1.inventory != state_t.inventory:
            delta.inventory_changes = [t for t in state_tp1.inventory if t not in state_t.inventory]
        
        if state_tp1.terminal != state_t.terminal:
            delta.terminal_change = True
            delta.description = "Terminal state reached"
        
        return delta