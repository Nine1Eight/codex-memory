from .schema import GameState

class RealityChecker:
    def check_drift(self, predicted: GameState, observed: GameState) -> str:
        if predicted.to_sigil() == observed.to_sigil():
            return "continue"
        # Simple comparison
        if observed.terminal:
            return "terminal"
        return "replan"