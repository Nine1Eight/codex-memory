import numpy as np
from PIL import Image, ImageDraw
import os
from .schema import GameState, GameObject, ObjectType

def create_synthetic_frame(state: GameState, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img = Image.new('RGB', (state.width * 20, state.height * 20), color=(200, 200, 200))
    draw = ImageDraw.Draw(img)
    for obj in state.objects:
        x, y = obj.position
        if obj.type == ObjectType.AGENT:
            color = (255, 0, 0)
        elif obj.type == ObjectType.WALL:
            color = (0, 0, 0)
        elif obj.type == ObjectType.KEY:
            color = (255, 215, 0)
        elif obj.type == ObjectType.GOAL:
            color = (0, 255, 0)
        else:
            color = (128, 128, 128)
        draw.rectangle([x*20, y*20, (x+1)*20, (y+1)*20], fill=color)
    img.save(path)

def generate_demo_run(out_dir: str = "runs/demo"):
    os.makedirs(out_dir, exist_ok=True)
    # Simple demo states
    state1 = GameState(8, 6, [
        GameObject(ObjectType.AGENT, "#2878ff", (1,1)),
        GameObject(ObjectType.KEY, "#fadc28", (4,1)),
        GameObject(ObjectType.DOOR, "#dc8c23", (6,1), {"locked": True}),
        GameObject(ObjectType.GOAL, "#3cdc5a", (6,4)),
    ])
    create_synthetic_frame(state1, f"{out_dir}/frame_000.png")
    
    # Simulate move
    state2 = GameState(8, 6, [
        GameObject(ObjectType.AGENT, "#2878ff", (2,1)),
        GameObject(ObjectType.KEY, "#fadc28", (4,1)),
        GameObject(ObjectType.DOOR, "#dc8c23", (6,1), {"locked": True}),
        GameObject(ObjectType.GOAL, "#3cdc5a", (6,4)),
    ])
    create_synthetic_frame(state2, f"{out_dir}/frame_001.png")
    
    # Save JSON
    import json
    with open(f"{out_dir}/agent_run.json", "w") as f:
        json.dump({"states": [state1.to_sigil(), state2.to_sigil()]}, f, indent=2)
    
    print("Synthetic demo generated.")