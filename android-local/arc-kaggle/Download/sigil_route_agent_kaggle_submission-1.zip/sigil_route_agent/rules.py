from typing import List, Dict
from .schema import Rule, GameState, Delta

class RuleInducer:
    def induce_rules(self, deltas: List[Delta]) -> List[Rule]:
        rules = []
        # Simple rule induction based on patterns
        if any(d.action.startswith('move') for d in deltas):
            rules.append(Rule("directional_move", "agent attempts move", "position changes if no collision"))
        
        if any(len(d.deleted) > 0 and d.action == 'collect' for d in deltas):
            rules.append(Rule("collect_key", "agent on key", "key removed, added to inventory"))
        
        if any(d.terminal_change for d in deltas):
            rules.append(Rule("goal_wins", "agent on goal", "terminal win"))
        
        # Add collision rule
        rules.append(Rule("collision_blocks", "agent moves into wall", "no movement"))
        
        return rules