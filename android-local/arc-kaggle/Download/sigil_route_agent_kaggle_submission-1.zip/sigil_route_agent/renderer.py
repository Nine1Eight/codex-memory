from PIL import Image, ImageDraw
import os
from typing import List
from .schema import GameState

class PredictionRenderer:
    def render_rollout(self, states: List[GameState], out_dir: str) -> str:
        os.makedirs(out_dir, exist_ok=True)
        frames = []
        for i, state in enumerate(states):
            img = Image.new('RGB', (state.width * 20, state.height * 20), color='white')
            draw = ImageDraw.Draw(img)
            for obj in state.objects:
                x, y = obj.position
                color = tuple(int(obj.color.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
                draw.rectangle([x*20, y*20, (x+1)*20, (y+1)*20], fill=color)
            frame_path = f"{out_dir}/frame_{i:03d}.png"
            img.save(frame_path)
            frames.append(frame_path)
        
        # Create GIF
        gif_path = f"{out_dir}/predicted_win.gif"
        images = [Image.open(f) for f in frames]
        images[0].save(gif_path, save_all=True, append_images=images[1:], duration=200, loop=0)
        return gif_path