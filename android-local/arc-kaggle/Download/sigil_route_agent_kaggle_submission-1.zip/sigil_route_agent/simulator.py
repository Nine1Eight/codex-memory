from typing import List
from .schema import GameState, Delta, Rule

class WorldModelSimulator:
    def simulate(self, state: GameState, action: str, rules: List[Rule]) -> GameState:
        """Simulate next state based on rules."""
        next_state = GameState(
            width=state.width,
            height=state.height,
            objects=[obj for obj in state.objects],  # copy
            inventory=state.inventory.copy(),
            terminal=state.terminal,
            frame_id=state.frame_id + 1
        )
        
        # Apply simple rules
        agent = next((obj for obj in next_state.objects if obj.type == 'AGENT'), None)
        if not agent:
            return next_state
        
        dx, dy = 0, 0
        if action == 'up': dy = -1
        elif action == 'down': dy = 1
        elif action == 'left': dx = -1
        elif action == 'right': dx = 1
        
        new_pos = (agent.position[0] + dx, agent.position[1] + dy)
        
        # Check collision
        collision = any(obj.position == new_pos and obj.type == 'WALL' for obj in next_state.objects)
        if not collision and 0 <= new_pos[0] < state.width and 0 <= new_pos[1] < state.height:
            agent.position = new_pos
        
        # Check for key collect, goal, etc.
        for obj in list(next_state.objects):
            if obj.position == agent.position:
                if obj.type == 'KEY':
                    next_state.inventory.append(obj.type)
                    next_state.objects.remove(obj)
                elif obj.type == 'GOAL':
                    next_state.terminal = True
        
        return next_state