from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Any
import json
from enum import Enum

class ObjectType(Enum):
    AGENT = "AGENT"
    WALL = "WALL"
    KEY = "KEY"
    DOOR = "DOOR"
    GOAL = "GOAL"
    HAZARD = "HAZARD"
    UNKNOWN = "UNKNOWN"

@dataclass
class GameObject:
    type: ObjectType
    color: str
    position: Tuple[int, int]
    properties: Dict[str, Any] = field(default_factory=dict)

    def to_sigil(self) -> str:
        props = ""
        if self.properties:
            props = "." + ".".join(f"{k}={v}" for k, v in self.properties.items())
        return f"{self.type.value}.{self.color}@{self.position[0]},{self.position[1]}{props}"

@dataclass
class GameState:
    width: int
    height: int
    objects: List[GameObject]
    inventory: List[ObjectType] = field(default_factory=list)
    terminal: bool = False
    frame_id: int = 0

    def to_sigil(self) -> str:
        grid = f"GRID[{self.width}x{self.height}]"
        obj_strs = [obj.to_sigil() for obj in self.objects]
        inv_str = f"|INV:{','.join(t.value for t in self.inventory)}" if self.inventory else ""
        term_str = "|TERMINAL" if self.terminal else ""
        return f"{grid}|{'|'.join(obj_strs)}{inv_str}{term_str}"

    @classmethod
    def from_sigil(cls, sigil: str) -> 'GameState':
        # Parse sigil string back to state - simplified for now
        parts = sigil.split('|')
        grid_part = parts[0]
        # Extract width height
        import re
        match = re.match(r'GRID\[(\d+)x(\d+)\]', grid_part)
        if match:
            w, h = int(match.group(1)), int(match.group(2))
        else:
            w, h = 0, 0
        objects = []
        for p in parts[1:]:
            # Simplified parser - TODO: full implementation
            if any(p.startswith(t) for t in ['AGENT', 'WALL', 'KEY', 'DOOR', 'GOAL', 'HAZARD']):
                # Placeholder
                pass
        return cls(width=w, height=h, objects=objects)

@dataclass
class Delta:
    action: str
    moved_objects: List[Tuple[GameObject, Tuple[int, int]]] = field(default_factory=list)
    created: List[GameObject] = field(default_factory=list)
    deleted: List[GameObject] = field(default_factory=list)
    inventory_changes: List[ObjectType] = field(default_factory=list)
    terminal_change: bool = False
    description: str = ""

@dataclass
class Rule:
    name: str
    condition: str
    effect: str

@dataclass
class Plan:
    actions: List[str]
    predicted_states: List[GameState]
    confidence: float = 1.0
    summary: str = ""