from typing import List, Optional
from collections import deque
from .schema import GameState, Plan, Rule
from .simulator import WorldModelSimulator
from .rules import RuleInducer

class RoutePlanner:
    def __init__(self):
        self.simulator = WorldModelSimulator()
        self.max_steps = 128

    def plan(self, state: GameState, rules: List[Rule]) -> Plan:
        """BFS planning."""
        queue = deque([(state, [])])
        visited = set()
        
        while queue:
            curr_state, path = queue.popleft()
            state_sigil = curr_state.to_sigil()[:100]  # hash approx
            if state_sigil in visited:
                continue
            visited.add(state_sigil)
            
            if len(path) > self.max_steps:
                break
            
            if curr_state.terminal:
                return Plan(actions=path, predicted_states=[curr_state], confidence=0.9)
            
            for action in ['up', 'down', 'left', 'right']:
                next_state = self.simulator.simulate(curr_state, action, rules)
                new_path = path + [action]
                queue.append((next_state, new_path))
        
        # Fallback greedy
        return self._greedy_fallback(state, rules)

    def _greedy_fallback(self, state: GameState, rules: List[Rule]) -> Plan:
        actions = []
        current = state
        for _ in range(10):  # limited
            for act in ['right', 'down', 'left', 'up']:  # prefer right/down
                next_s = self.simulator.simulate(current, act, rules)
                actions.append(act)
                current = next_s
                if current.terminal:
                    break
            if current.terminal:
                break
        return Plan(actions=actions, predicted_states=[current], confidence=0.5)