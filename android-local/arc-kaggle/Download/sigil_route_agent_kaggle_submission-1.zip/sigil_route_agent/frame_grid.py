from PIL import Image
import numpy as np
from typing import Tuple, List, Optional
from .schema import GameState, GameObject, ObjectType

class FrameGridExtractor:
    def __init__(self):
        self.cell_size = None
        self.grid_width = None
        self.grid_height = None
        self.palette = {}

    def extract_grid(self, frame_path: str) -> Tuple[np.ndarray, GameState]:
        """Extract grid from image frame."""
        img = Image.open(frame_path).convert('RGB')
        pixels = np.array(img)
        
        # Simple detection of grid - assume uniform cell size, for synthetic
        # In real, use edge detection or color clustering
        height, width, _ = pixels.shape
        # Assume standard ARC-like grid, detect cell size by color changes
        self.cell_size = 20  # placeholder for synthetic
        self.grid_width = width // self.cell_size
        self.grid_height = height // self.cell_size
        
        grid = np.zeros((self.grid_height, self.grid_width, 3), dtype=np.uint8)
        for y in range(self.grid_height):
            for x in range(self.grid_width):
                cell = pixels[y*self.cell_size:(y+1)*self.cell_size, x*self.cell_size:(x+1)*self.cell_size]
                avg_color = np.mean(cell, axis=(0,1)).astype(np.uint8)
                grid[y, x] = avg_color
        
        # Discover objects
        objects = self._discover_objects(grid)
        state = GameState(width=self.grid_width, height=self.grid_height, objects=objects, frame_id=0)
        return grid, state

    def _discover_objects(self, grid: np.ndarray) -> List[GameObject]:
        objects = []
        # Placeholder logic for colors to objects
        color_to_type = {
            (255,0,0): ObjectType.AGENT,  # red for agent example
            (0,0,0): ObjectType.WALL,
            # add more
        }
        for y in range(grid.shape[0]):
            for x in range(grid.shape[1]):
                color_tuple = tuple(grid[y, x])
                if color_tuple in color_to_type:
                    obj_type = color_to_type[color_tuple]
                    color_hex = '#{:02x}{:02x}{:02x}'.format(*color_tuple)
                    objects.append(GameObject(obj_type, color_hex, (x, y)))
        return objects