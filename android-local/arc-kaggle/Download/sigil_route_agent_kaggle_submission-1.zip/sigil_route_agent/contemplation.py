def contemplate(plan: 'Plan', budget: int = 10000) -> str:
    """Simulate contemplation budget."""
    summary = f"Planning summary: Selected {len(plan.actions)} actions with confidence {plan.confidence}. "
    summary += "Risk: Low collision probability."
    return summary