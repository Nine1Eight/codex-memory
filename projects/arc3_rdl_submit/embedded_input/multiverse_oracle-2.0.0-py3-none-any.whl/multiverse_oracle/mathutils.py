from __future__ import annotations

import math
from collections.abc import Mapping


def normalize(weights: Mapping[str, float]) -> dict[str, float]:
    if not weights:
        raise ValueError("cannot normalize empty weights")
    total = sum(weights.values())
    if not math.isfinite(total) or total <= 0:
        raise ValueError("weights must have a finite positive sum")
    result = {k: v / total for k, v in weights.items()}
    if any((not math.isfinite(v)) or v < 0 for v in result.values()):
        raise ValueError("weights must be finite and non-negative")
    return result


def entropy_bits(probabilities: Mapping[str, float]) -> float:
    p = normalize(probabilities)
    return -sum(v * math.log2(v) for v in p.values() if v > 0)


def effective_count(probabilities: Mapping[str, float]) -> float:
    p = normalize(probabilities)
    return 1.0 / sum(v * v for v in p.values())


def kl_divergence(p: Mapping[str, float], q: Mapping[str, float], eps: float = 1e-12) -> float:
    keys = set(p) | set(q)
    pp = normalize({k: max(float(p.get(k, 0.0)), eps) for k in keys})
    qq = normalize({k: max(float(q.get(k, 0.0)), eps) for k in keys})
    return sum(pp[k] * math.log2(pp[k] / qq[k]) for k in keys)


def js_divergence(p: Mapping[str, float], q: Mapping[str, float]) -> float:
    keys = set(p) | set(q)
    pp = normalize({k: float(p.get(k, 0.0)) for k in keys})
    qq = normalize({k: float(q.get(k, 0.0)) for k in keys})
    m = {k: 0.5 * (pp[k] + qq[k]) for k in keys}
    # JSD in bits lies in [0,1].
    return max(0.0, min(1.0, 0.5 * kl_divergence(pp, m) + 0.5 * kl_divergence(qq, m)))


def weighted_stats(values: Mapping[str, float], weights: Mapping[str, float]) -> tuple[float, float, float]:
    if set(values) != set(weights):
        raise ValueError("values and weights must have identical branch ids")
    w = normalize(weights)
    mean = sum(w[k] * values[k] for k in values)
    variance = sum(w[k] * (values[k] - mean) ** 2 for k in values)
    worst = min(values.values())
    return mean, variance, worst
