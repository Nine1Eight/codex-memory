from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Mapping

from .types import OracleTelemetry


@dataclass(frozen=True, slots=True)
class ADLOracleMetrics:
    anomaly_score: float
    probability_ghosting: float
    reality_drift: float
    epistemic_leakage: float
    effective_branch_count: float


class ADLOracleAdapter:
    """Converts oracle telemetry into explicit metrics suitable for ADL delta alignment.

    It deliberately does not declare a change winning/losing. That remains the
    responsibility of ADL's real outcome/ablation validation layer.
    """

    @staticmethod
    def metrics(telemetry: OracleTelemetry) -> ADLOracleMetrics:
        return ADLOracleMetrics(
            anomaly_score=telemetry.anomaly_score,
            probability_ghosting=telemetry.probability_ghosting,
            reality_drift=telemetry.reality_drift,
            epistemic_leakage=telemetry.epistemic_leakage,
            effective_branch_count=telemetry.effective_branch_count,
        )

    @staticmethod
    def as_mapping(telemetry: OracleTelemetry) -> Mapping[str, Any]:
        return asdict(ADLOracleAdapter.metrics(telemetry))
