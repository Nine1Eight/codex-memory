from __future__ import annotations

from typing import Any, Iterable

from ..rdl.snapshot import stable_hash
from ..rdl.types import RDLDelta, ReachabilityResult, RuntimeBridge, RuntimeDifferenceEvidence, SemanticMutation
from .causal_graph import RuntimeCausalGraph
from .environment_twin import EnvironmentTwin
from .reverse_path import ReversePathIndex


_FAMILY_CAPABILITIES = {
    "RDL-01": "DISCRETE_RATIO_THRESHOLD_TEST",
    "RDL-02": "DISCRETIZATION_THRESHOLD_TEST",
    "RDL-03": "TOPOLOGY_BOUNDARY_CLASSIFIER",
    "RDL-04": "REGION_BOUNDARY_CLASSIFIER",
    "RDL-05": "ITERATION_CONSUMPTION_CLASSIFIER",
    "RDL-06": "UPDATE_ORDER_CLASSIFIER",
    "RDL-07": "STATE_ALIASING_CLASSIFIER",
    "RDL-08": "NUMERIC_RANGE_CLASSIFIER",
    "RDL-09": "COUNTER_OVERFLOW_CLASSIFIER",
    "RDL-10": "FLAG_IDENTITY_CLASSIFIER",
    "RDL-11": "IDENTIFIER_REPRESENTATION_CLASSIFIER",
    "RDL-12": "STOCHASTIC_TRANSITION_CLASSIFIER",
    "RDL-13": "RESTORE_STATE_CLASSIFIER",
    "RDL-14": "UPDATE_PHASE_CLASSIFIER",
    "RDL-15": "FALLBACK_TRANSITION_CLASSIFIER",
    "RDL-16": "BEHAVIORAL_COMPATIBILITY_CLASSIFIER",
}


class RuntimeGhostBridge:
    def __init__(self, graph: RuntimeCausalGraph | None = None, twin: EnvironmentTwin | None = None) -> None:
        self.graph = graph or RuntimeCausalGraph()
        self.twin = twin or EnvironmentTwin()
        self.reverse_path = ReversePathIndex(self.graph)

    def observe_pair(self, baseline: Any, variant: Any, *, mutation_family: str) -> None:
        self.graph.record(baseline, mutation_family=None)
        self.graph.record(variant, mutation_family=mutation_family)
        self.twin.record(baseline)
        self.twin.record(variant)

    def construct_runtime_bridge(
        self,
        *,
        environment_id: str,
        initial_state_hash: str,
        target_delta: RDLDelta,
        mutation: SemanticMutation,
        reachability: ReachabilityResult,
        evidence_hashes: Iterable[str],
    ) -> RuntimeBridge:
        capability = _FAMILY_CAPABILITIES[mutation.family.value]
        reverse = self.reverse_path.search(current_hash=initial_state_hash, max_depth=24)
        forward_path = reachability.path if reachability.reachable else ()
        reverse_actions = reverse.actions if reverse.found else ()
        if forward_path:
            probe = tuple(forward_path[-2:] if len(forward_path) > 1 else forward_path)
        elif reverse_actions:
            probe = tuple(reverse_actions[:2])
        else:
            probe = ()
        target_parts: list[str] = []
        if target_delta.position_changed:
            target_parts.append("position")
        if target_delta.legal_actions_changed:
            target_parts.append("legal_actions")
        if target_delta.score_delta:
            target_parts.append("score")
        if target_delta.level_delta:
            target_parts.append("level")
        if target_delta.terminal_changed:
            target_parts.append("terminal")
        if not target_parts:
            target_parts.append("state")
        target_condition = "+".join(target_parts)
        payload = {
            "environment": environment_id,
            "source": initial_state_hash,
            "family": mutation.family.value,
            "target": target_condition,
            "forward": tuple(map(str, forward_path)),
            "reverse": reverse_actions,
        }
        bridge_id = f"GB-RDL-{stable_hash(payload)[:16]}"
        confidence = 0.5
        if reachability.reachable:
            confidence += 0.25
        if reverse.found:
            confidence += 0.25
        return RuntimeBridge(
            bridge_id=bridge_id,
            source_state_hash=initial_state_hash,
            target_condition=target_condition,
            missing_capability=capability,
            forward_path=tuple(forward_path),
            reverse_path=tuple(reverse_actions),
            synthesized_probe=probe,
            confidence=min(1.0, confidence),
            evidence_hashes=tuple(dict.fromkeys(str(v) for v in evidence_hashes)),
        )
