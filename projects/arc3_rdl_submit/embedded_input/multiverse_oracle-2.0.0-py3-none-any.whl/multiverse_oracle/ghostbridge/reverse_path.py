from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Iterable

from .causal_graph import RuntimeCausalGraph


@dataclass(frozen=True, slots=True)
class ReversePathResult:
    found: bool
    start_hash: str
    goal_hash: str | None
    actions: tuple[str, ...]
    states: tuple[str, ...]
    missing_bridge_target: str | None


class ReversePathIndex:
    def __init__(self, graph: RuntimeCausalGraph) -> None:
        self.graph = graph

    def search(
        self,
        *,
        current_hash: str,
        goal_hashes: Iterable[str] | None = None,
        max_depth: int = 32,
    ) -> ReversePathResult:
        goals = tuple(goal_hashes or self.graph.success_states())
        if current_hash in goals:
            return ReversePathResult(True, current_hash, current_hash, (), (current_hash,), None)
        queue = deque((goal, tuple(), (goal,)) for goal in goals)
        visited = set(goals)
        closest: str | None = goals[0] if goals else None
        while queue:
            node, reverse_actions, reverse_states = queue.popleft()
            if len(reverse_actions) >= max_depth:
                continue
            predecessors = self.graph.predecessors(node)
            for source, action in predecessors:
                actions = (action, *reverse_actions)
                states = (source, *reverse_states)
                if source == current_hash:
                    return ReversePathResult(True, current_hash, reverse_states[-1], actions, states, None)
                if source in visited:
                    continue
                visited.add(source)
                closest = source
                queue.append((source, actions, states))
        return ReversePathResult(False, current_hash, None, (), (), closest)
