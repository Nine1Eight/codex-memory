from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from ..rdl.types import RDLTransition


@dataclass(slots=True)
class RuntimeCausalEdge:
    source_hash: str
    action_key: str
    target_hash: str
    mutation_family: str | None
    observations: int = 0
    successes: int = 0
    no_effects: int = 0
    total_score_delta: float = 0.0

    @property
    def confidence(self) -> float:
        return (self.observations + 1.0) / (self.observations + 2.0)

    @property
    def success_rate(self) -> float:
        return (self.successes + 1.0) / (self.observations + 2.0)


class RuntimeCausalGraph:
    def __init__(self) -> None:
        self._edges: dict[tuple[str, str, str, str | None], RuntimeCausalEdge] = {}
        self._success_states: set[str] = set()
        self._predecessors: dict[str, set[tuple[str, str]]] = defaultdict(set)

    @staticmethod
    def _action_key(action: Any) -> str:
        return getattr(action, "name", None) or str(action)

    def record(self, transition: RDLTransition, *, mutation_family: str | None = None) -> RuntimeCausalEdge:
        source = transition.before.state_hash
        target = transition.after.state_hash
        action_key = self._action_key(transition.action)
        key = (source, action_key, target, mutation_family)
        edge = self._edges.get(key)
        if edge is None:
            edge = RuntimeCausalEdge(source, action_key, target, mutation_family)
            self._edges[key] = edge
        edge.observations += 1
        score_delta = transition.after.score - transition.before.score
        level_delta = transition.after.level - transition.before.level
        edge.total_score_delta += score_delta
        if score_delta > 0 or level_delta > 0:
            edge.successes += 1
            self._success_states.add(target)
        if source == target:
            edge.no_effects += 1
        self._predecessors[target].add((source, action_key))
        return edge

    def predecessors(self, target_hash: str) -> tuple[tuple[str, str], ...]:
        return tuple(sorted(self._predecessors.get(target_hash, set())))

    def success_states(self) -> tuple[str, ...]:
        return tuple(sorted(self._success_states))

    def edges(self) -> tuple[RuntimeCausalEdge, ...]:
        return tuple(sorted(self._edges.values(), key=lambda e: (e.source_hash, e.action_key, e.target_hash, e.mutation_family or "")))
