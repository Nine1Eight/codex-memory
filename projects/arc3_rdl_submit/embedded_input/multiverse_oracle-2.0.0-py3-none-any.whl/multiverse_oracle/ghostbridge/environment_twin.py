from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Mapping

from ..rdl.types import RDLTransition


@dataclass(frozen=True, slots=True)
class TwinPrediction:
    state_hash: str
    action_key: str
    runtime_profile: str
    next_state_distribution: Mapping[str, float]
    confidence: float
    use_count: int
    success_count: int
    no_impact_count: int


class EnvironmentTwin:
    """Empirical transition twin learned only from observed/controlled trajectories."""

    def __init__(self) -> None:
        self._outcomes: dict[tuple[str, str, str], Counter[str]] = defaultdict(Counter)
        self._uses: Counter[tuple[str, str, str]] = Counter()
        self._successes: Counter[tuple[str, str, str]] = Counter()
        self._no_impacts: Counter[tuple[str, str, str]] = Counter()

    @staticmethod
    def _action_key(action: Any) -> str:
        return getattr(action, "name", None) or str(action)

    def record(self, transition: RDLTransition) -> None:
        key = (transition.before.state_hash, self._action_key(transition.action), transition.runtime_profile)
        self._outcomes[key][transition.after.state_hash] += 1
        self._uses[key] += 1
        if transition.after.score > transition.before.score or transition.after.level > transition.before.level:
            self._successes[key] += 1
        if transition.after.state_hash == transition.before.state_hash:
            self._no_impacts[key] += 1

    def predict(self, state_hash: str, action: Any, runtime_profile: str = "baseline") -> TwinPrediction:
        action_key = self._action_key(action)
        key = (state_hash, action_key, runtime_profile)
        counts = self._outcomes.get(key, Counter())
        total = sum(counts.values())
        distribution = {target: count / total for target, count in sorted(counts.items())} if total else {}
        confidence = total / (total + 2.0)
        return TwinPrediction(
            state_hash=state_hash,
            action_key=action_key,
            runtime_profile=runtime_profile,
            next_state_distribution=distribution,
            confidence=confidence,
            use_count=self._uses[key],
            success_count=self._successes[key],
            no_impact_count=self._no_impacts[key],
        )

    def discrepancy(self, transition: RDLTransition) -> float:
        prediction = self.predict(transition.before.state_hash, transition.action, transition.runtime_profile)
        if not prediction.next_state_distribution:
            return 1.0
        return 1.0 - prediction.next_state_distribution.get(transition.after.state_hash, 0.0)
