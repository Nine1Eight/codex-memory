from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence

from .collapse import ProbabilityCollapseEngine
from .detector import MultiverseOracleAnomalyDetector
from .planner import CrossWorldPlanner, PlannerConfig
from .provenance import EpistemicBoundary
from .types import ActionCandidate, ActionDecision, Branch, CollapseResult, OracleTelemetry, WorldSnapshot


class BranchGenerator(Protocol):
    def generate(self, snapshot: WorldSnapshot, branch_count: int, horizon: int, seed: int) -> list[Branch]:
        """Generate concrete future branches for the supplied observed snapshot."""
        raise TypeError("BranchGenerator is a structural protocol; use a concrete generator")


class BranchEvaluator(Protocol):
    def actions(self, snapshot: WorldSnapshot) -> list[ActionCandidate]:
        """Return concrete executable action candidates for the observed snapshot."""
        raise TypeError("BranchEvaluator is a structural protocol; use a concrete evaluator")

    def evaluate(
        self,
        snapshot: WorldSnapshot,
        branches: Sequence[Branch],
        actions: Sequence[ActionCandidate],
    ) -> Mapping[str, Mapping[str, float]]:
        """Evaluate every candidate action in every supplied branch."""
        raise TypeError("BranchEvaluator is a structural protocol; use a concrete evaluator")

    def observation_likelihoods(
        self,
        branches: Sequence[Branch],
        actual_observation: Mapping[str, Any] | None,
    ) -> Mapping[str, float] | None:
        """Return branch likelihoods for a real observation, or None without evidence."""
        raise TypeError("BranchEvaluator is a structural protocol; use a concrete evaluator")


@dataclass(slots=True)
class OracleConfig:
    branch_count: int = 64
    horizon: int = 8
    seed: int = 918
    strict_epistemic_boundary: bool = True

    def __post_init__(self) -> None:
        if self.branch_count < 1:
            raise ValueError("branch_count must be >= 1")
        if self.horizon < 1:
            raise ValueError("horizon must be >= 1")


@dataclass(frozen=True, slots=True)
class OracleStepResult:
    decision: ActionDecision
    collapse: CollapseResult
    telemetry: OracleTelemetry
    branches: tuple[Branch, ...]
    ranked_decisions: tuple[ActionDecision, ...] = ()


class MultiverseOracleEngine:
    def __init__(
        self,
        branch_generator: BranchGenerator,
        evaluator: BranchEvaluator,
        *,
        config: OracleConfig | None = None,
        planner: CrossWorldPlanner | None = None,
        collapse_engine: ProbabilityCollapseEngine | None = None,
        detector: MultiverseOracleAnomalyDetector | None = None,
    ) -> None:
        self.branch_generator = branch_generator
        self.evaluator = evaluator
        self.config = config or OracleConfig()
        self.planner = planner or CrossWorldPlanner(PlannerConfig())
        self.collapse_engine = collapse_engine or ProbabilityCollapseEngine()
        self.detector = detector or MultiverseOracleAnomalyDetector()
        self.boundary = EpistemicBoundary(strict=self.config.strict_epistemic_boundary)

    def step(
        self,
        snapshot: WorldSnapshot,
        *,
        actual_observation: Mapping[str, Any] | None = None,
        previous_prediction: Mapping[str, Any] | None = None,
        causal_inversion_events: int = 0,
    ) -> OracleStepResult:
        # Hard invariant: executable current-state features may not contain simulated facts.
        leakage = self.boundary.validate_action_features(snapshot.features)

        branches = self.branch_generator.generate(
            snapshot,
            self.config.branch_count,
            self.config.horizon,
            self.config.seed + snapshot.step,
        )
        if not branches:
            raise RuntimeError("branch generator returned no branches")
        likelihoods = self.evaluator.observation_likelihoods(branches, actual_observation)
        collapse = self.collapse_engine.posterior(branches, likelihoods)

        surviving = [b for b in branches if b.branch_id in collapse.surviving_branch_ids]
        posterior = {b.branch_id: collapse.probabilities[b.branch_id] for b in surviving}
        # Renormalization is performed by planner; this intentionally prunes tiny branches.
        actions = self.evaluator.actions(snapshot)
        branch_values = self.evaluator.evaluate(snapshot, surviving, actions)
        ranked_decisions = tuple(self.planner.rank(actions, branch_values, posterior))
        decision = ranked_decisions[0]

        feature_count = len(snapshot.features)
        simulated_count = round(leakage * feature_count)
        telemetry = self.detector.evaluate(
            step=snapshot.step,
            decision=decision,
            collapse=collapse,
            predicted_observation=previous_prediction,
            actual_observation=actual_observation,
            causal_inversion_events=causal_inversion_events,
            action_condition_feature_count=feature_count,
            simulated_action_feature_count=simulated_count,
            diagnostics={
                "generated_branches": len(branches),
                "surviving_branches": len(surviving),
                "strict_epistemic_boundary": self.config.strict_epistemic_boundary,
            },
        )
        return OracleStepResult(decision, collapse, telemetry, tuple(branches), ranked_decisions)
