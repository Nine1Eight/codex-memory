from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(slots=True)
class CausalEdge:
    source: str
    target: str
    support: float = 0.0
    contradictions: float = 0.0
    simulated_support: float = 0.0

    @property
    def empirical_confidence(self) -> float:
        evidence = self.support + self.contradictions
        return self.support / evidence if evidence > 0 else 0.0

    @property
    def phantom_score(self) -> float:
        empirical = self.support + self.contradictions
        if self.simulated_support <= 0 or empirical <= 0:
            return 0.0
        total = empirical + self.simulated_support
        simulation_fraction = self.simulated_support / total
        contradiction_rate = self.contradictions / empirical
        # A phantom bridge needs both substantial simulated support and real-world
        # contradiction. The geometric mean prevents either factor alone from
        # producing a high score.
        return min(1.0, (simulation_fraction * contradiction_rate) ** 0.5)


class CausalTransitionGraph:
    def __init__(self) -> None:
        self._edges: dict[tuple[str, str], CausalEdge] = {}

    def edge(self, source: str, target: str) -> CausalEdge:
        if not source or not target:
            raise ValueError("source and target are required")
        key = (source, target)
        if key not in self._edges:
            self._edges[key] = CausalEdge(source, target)
        return self._edges[key]

    def record_observed(self, source: str, target: str, occurred: bool, weight: float = 1.0) -> None:
        if weight <= 0:
            raise ValueError("weight must be > 0")
        edge = self.edge(source, target)
        if occurred:
            edge.support += weight
        else:
            edge.contradictions += weight

    def record_simulated(self, source: str, target: str, weight: float = 1.0) -> None:
        if weight <= 0:
            raise ValueError("weight must be > 0")
        self.edge(source, target).simulated_support += weight

    def phantom_edges(self, threshold: float = 0.5) -> list[CausalEdge]:
        if not 0 <= threshold <= 1:
            raise ValueError("threshold must be in [0,1]")
        return sorted(
            (e for e in self._edges.values() if e.phantom_score >= threshold),
            key=lambda e: (-e.phantom_score, e.source, e.target),
        )

    def missing_edges(
        self,
        required: Iterable[tuple[str, str]],
        min_empirical_confidence: float = 0.5,
    ) -> list[tuple[str, str]]:
        result = []
        for key in required:
            edge = self._edges.get(key)
            if edge is None or edge.empirical_confidence < min_empirical_confidence:
                result.append(key)
        return result

    def snapshot(self) -> list[dict[str, float | str]]:
        return [
            {
                "source": e.source,
                "target": e.target,
                "support": e.support,
                "contradictions": e.contradictions,
                "simulated_support": e.simulated_support,
                "empirical_confidence": e.empirical_confidence,
                "phantom_score": e.phantom_score,
            }
            for e in sorted(self._edges.values(), key=lambda e: (e.source, e.target))
        ]
