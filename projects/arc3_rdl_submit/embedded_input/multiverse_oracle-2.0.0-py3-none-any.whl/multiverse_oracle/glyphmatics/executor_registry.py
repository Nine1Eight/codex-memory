from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from ..rdl.types import EncodedMechanic, MechanicProbe, RDLMechanic
from .canon333 import CANON333


@dataclass(frozen=True, slots=True)
class MechanicExecutionContext:
    legal_actions: tuple[Any, ...]
    planner_value: float = 0.0
    information_gain: float = 0.0
    potential_reward: float = 1.0
    action_cost: float = 1.0
    failure_risk: float = 0.0
    position: tuple[int, int] | None = None
    grid_shape: tuple[int, int] | None = None
    direction_actions: Mapping[str, Any] = field(default_factory=dict)
    action_aliases: Mapping[str, Any] = field(default_factory=dict)


GlyphHandler = Callable[[EncodedMechanic, RDLMechanic, MechanicExecutionContext], Any | None]


class GlyphExecutorRegistry:
    def __init__(self) -> None:
        self._handlers: dict[int, GlyphHandler] = {}
        self.register(CANON333.by_token("TOROIDAL").glyph_id, self._boundary_wrap_probe)
        self.register(CANON333.by_token("BOUNDARY").glyph_id, self._boundary_wrap_probe)

    def register(self, glyph_id: int, handler: GlyphHandler) -> None:
        if not 1 <= int(glyph_id) <= 333:
            raise ValueError("glyph_id must be in [1,333]")
        if not callable(handler):
            raise TypeError("glyph handler must be callable")
        self._handlers[int(glyph_id)] = handler

    @staticmethod
    def _is_legal(action: Any, legal_actions: Sequence[Any]) -> bool:
        action_repr = getattr(action, "name", None) or str(action)
        return any((getattr(candidate, "name", None) or str(candidate)) == action_repr for candidate in legal_actions)

    @classmethod
    def _fallback_test_action(cls, mechanic: RDLMechanic, context: MechanicExecutionContext) -> Any | None:
        for raw in mechanic.test_actions:
            action = context.action_aliases.get(str(raw), raw)
            if cls._is_legal(action, context.legal_actions):
                return action
        return None

    @classmethod
    def _boundary_wrap_probe(
        cls,
        encoded: EncodedMechanic,
        mechanic: RDLMechanic,
        context: MechanicExecutionContext,
    ) -> Any | None:
        if context.position is not None and context.grid_shape is not None:
            row, col = context.position
            height, width = context.grid_shape
            candidates: list[str] = []
            if row == 0:
                candidates.append("north")
            if row == height - 1:
                candidates.append("south")
            if col == 0:
                candidates.append("west")
            if col == width - 1:
                candidates.append("east")
            for direction in candidates:
                action = context.direction_actions.get(direction)
                if action is not None and cls._is_legal(action, context.legal_actions):
                    return action
        return cls._fallback_test_action(mechanic, context)

    def propose(
        self,
        encoded: EncodedMechanic,
        mechanic: RDLMechanic,
        context: MechanicExecutionContext,
    ) -> MechanicProbe | None:
        handler = self._handlers.get(encoded.glyph_id)
        action = handler(encoded, mechanic, context) if handler is not None else self._fallback_test_action(mechanic, context)
        if action is None:
            return None
        denominator = max(1e-9, context.action_cost + max(0.0, context.failure_risk))
        probe_value = max(0.0, context.information_gain) * max(0.0, context.potential_reward) / denominator
        return MechanicProbe(
            mechanic_id=mechanic.mechanic_id,
            glyph_id=encoded.glyph_id,
            action=action,
            expected_observations=mechanic.predicted_effects,
            probe_value=probe_value,
            information_gain=max(0.0, context.information_gain),
            failure_risk=max(0.0, context.failure_risk),
            reason=f"glyph {encoded.glyph_id}:{encoded.token} proposes a low-cost observable mechanic test",
        )
