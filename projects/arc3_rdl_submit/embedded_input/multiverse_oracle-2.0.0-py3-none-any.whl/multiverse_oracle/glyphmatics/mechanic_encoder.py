from __future__ import annotations

from typing import Any

from ..rdl.snapshot import stable_hash
from ..rdl.types import EncodedMechanic, RDLMechanic
from .canon333 import CANON333, Canon333


_FAMILY_PRIMARY = {
    "RDL-01": "FLOOR_DIV",
    "RDL-02": "ROUND_NEAREST",
    "RDL-03": "TOROIDAL",
    "RDL-04": "SLICE_INCLUSIVE",
    "RDL-05": "ITERATOR_MATERIALIZED",
    "RDL-06": "ORDERED",
    "RDL-07": "COPY_REFERENCE",
    "RDL-08": "DTYPE_SIGNED",
    "RDL-09": "OVERFLOW_WRAP",
    "RDL-10": "BOOL_STRICT",
    "RDL-11": "TEXT_UTF8",
    "RDL-12": "RNG_STATE",
    "RDL-13": "DESERIALIZE",
    "RDL-14": "PHASE",
    "RDL-15": "DEFAULT_VALUE",
    "RDL-16": "LIBRARY_COMPAT",
}


class MechanicEncoder:
    def __init__(self, canon: Canon333 | None = None) -> None:
        self.canon = canon or CANON333

    def _primary_token(self, mechanic: RDLMechanic) -> str:
        text = f"{mechanic.description} {mechanic.invariant}".lower()
        if "opposite boundary" in text or "toroid" in text or "wrap" in text and "boundary" in text:
            return "TOROIDAL"
        if "portal" in text:
            return "PORTAL"
        if "one-way" in text:
            return "ONE_WAY"
        if "overflow" in text and "saturat" in text:
            return "OVERFLOW_SATURATE"
        if "overflow" in text:
            return "OVERFLOW_WRAP"
        if "ordering" in text or "processing order" in text:
            return "ORDERED"
        if "alias" in text or "shared mutable" in text:
            return "COPY_REFERENCE"
        if "stochastic" in text or "random" in text:
            return "RNG_STATE"
        if "restore" in text or "persistence" in text:
            return "DESERIALIZE"
        if "temporal ordering" in text or "update phase" in text:
            return "PHASE"
        if "fallback" in text:
            return "DEFAULT_VALUE"
        return _FAMILY_PRIMARY.get(mechanic.mutation_family, "MECHANIC")

    def encode_mechanic(self, mechanic: RDLMechanic) -> EncodedMechanic:
        token = self._primary_token(mechanic)
        definition = self.canon.by_token(token)
        secondary: list[int] = []
        for concept in ("MECHANIC", "INVARIANT", "VERIFY"):
            concept_id = self.canon.by_token(concept).glyph_id
            if concept_id != definition.glyph_id:
                secondary.append(concept_id)
        signature = stable_hash(
            {
                "mechanic_id": mechanic.mechanic_id,
                "primary": definition.glyph_id,
                "invariant": mechanic.invariant,
                "preconditions": mechanic.preconditions,
                "predicted_effects": mechanic.predicted_effects,
            }
        )
        return EncodedMechanic(
            glyph_id=definition.glyph_id,
            token=definition.token,
            mechanic_id=mechanic.mechanic_id,
            signature=signature,
            parameters=(
                ("secondary_glyphs", tuple(secondary)),
                ("mutation_family", mechanic.mutation_family),
                ("preconditions", mechanic.preconditions),
                ("predicted_effects", mechanic.predicted_effects),
            ),
        )
