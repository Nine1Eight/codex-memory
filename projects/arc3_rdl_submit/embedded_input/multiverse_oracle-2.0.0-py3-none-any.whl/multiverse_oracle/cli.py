from __future__ import annotations

import argparse
import json
from dataclasses import asdict

from .gridworld import GridPursuitEnvironment, GridPursuitOracle, GridState
from .oracle import MultiverseOracleEngine, OracleConfig
from .planner import CrossWorldPlanner, PlannerConfig
from .session import OracleSession


def _point(text: str) -> tuple[int, int]:
    try:
        x, y = text.split(",", 1)
        return int(x), int(y)
    except Exception as exc:
        raise argparse.ArgumentTypeError("point must be X,Y") from exc


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="multiverse-oracle")
    p.add_argument("--width", type=int, default=9)
    p.add_argument("--height", type=int, default=9)
    p.add_argument("--hunter", type=_point, default=(1, 4))
    p.add_argument("--target", type=_point, default=(6, 4))
    p.add_argument("--branches", type=int, default=128)
    p.add_argument("--horizon", type=int, default=8)
    p.add_argument("--seed", type=int, default=918)
    p.add_argument("--risk", type=float, default=0.15)
    p.add_argument("--temperature", type=float, default=1.0)
    p.add_argument("--wall", action="append", type=_point, default=[])
    p.add_argument("--episode-steps", type=int, default=0)
    p.add_argument("--environment-seed", type=int, default=20260825)
    p.add_argument("--json", action="store_true")
    return p


def _engine(args: argparse.Namespace, world: GridPursuitOracle) -> MultiverseOracleEngine:
    return MultiverseOracleEngine(
        world,
        world,
        config=OracleConfig(branch_count=args.branches, horizon=args.horizon, seed=args.seed),
        planner=CrossWorldPlanner(
            PlannerConfig(
                risk_aversion=args.risk,
                weight_temperature=args.temperature,
            )
        ),
    )


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.episode_steps < 0:
        raise SystemExit("--episode-steps must be >= 0")
    state = GridState(args.width, args.height, args.hunter, args.target, frozenset(args.wall))
    world = GridPursuitOracle()
    engine = _engine(args, world)

    if args.episode_steps:
        environment = GridPursuitEnvironment(state, seed=args.environment_seed)
        session = OracleSession(engine, run_id="cli-episode")
        trace: list[dict[str, object]] = []
        captured = False
        total_reward = 0.0
        for _ in range(args.episode_steps):
            actual = None if environment.step_index == 0 else {"target": environment.state.target}
            result = session.step(environment.snapshot(), actual_observation=actual)
            outcome = environment.step(result.decision.action)
            total_reward += outcome.reward
            trace.append(
                {
                    "step": result.telemetry.step,
                    "action": result.decision.action.action_id,
                    "destination": result.decision.action.payload,
                    "target": outcome.state.target,
                    "reward": outcome.reward,
                    "captured": outcome.captured,
                    "anomaly_score": result.telemetry.anomaly_score,
                    "reality_drift": result.telemetry.reality_drift,
                    "surviving_branches": len(result.collapse.surviving_branch_ids),
                }
            )
            if outcome.captured:
                captured = True
                break
        payload = {
            "mode": "episode",
            "captured": captured,
            "steps": len(trace),
            "total_reward": total_reward,
            "summary": asdict(session.summary()),
            "trace": trace,
        }
    else:
        result = engine.step(state.snapshot(0))
        payload = {
            "mode": "single-step",
            "action": result.decision.action.action_id,
            "destination": result.decision.action.payload,
            "score": result.decision.score,
            "expected_value": result.decision.expected_value,
            "variance": result.decision.variance,
            "anomaly": asdict(result.telemetry),
            "surviving_branches": len(result.collapse.surviving_branch_ids),
        }

    if args.json:
        print(json.dumps(payload, indent=2, sort_keys=True, default=str))
    elif payload["mode"] == "episode":
        print(
            f"episode steps={payload['steps']} captured={payload['captured']} "
            f"total_reward={payload['total_reward']:.4f}"
        )
    else:
        print(
            f"action={payload['action']} destination={payload['destination']} "
            f"score={payload['score']:.4f}"
        )
        anomaly = payload["anomaly"]
        print(
            f"anomaly_score={anomaly['anomaly_score']:.4f} "
            f"entropy={anomaly['posterior_entropy_bits']:.4f} bits"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
