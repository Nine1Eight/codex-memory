from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from .types import EpistemicSource, FeatureValue, WorldSnapshot


class EpistemicLeakError(RuntimeError):
    """Raised when simulated or policy-disallowed evidence enters executable context."""


@dataclass(slots=True)
class EpistemicBoundary:
    allow_inferred_for_action: bool = True
    strict: bool = True

    def validate_action_features(self, features: Mapping[str, FeatureValue]) -> float:
        if not features:
            return 0.0
        leaked = [k for k, v in features.items() if v.source is EpistemicSource.SIMULATED]
        leakage = len(leaked) / len(features)
        if leaked and self.strict:
            raise EpistemicLeakError(
                "simulated branch features cannot enter executable action context: " + ", ".join(sorted(leaked))
            )
        if not self.allow_inferred_for_action:
            inferred = [k for k, v in features.items() if v.source is EpistemicSource.INFERRED]
            if inferred and self.strict:
                raise EpistemicLeakError(
                    "inferred features disallowed by policy: " + ", ".join(sorted(inferred))
                )
        return leakage

    def safe_context(self, snapshot: WorldSnapshot) -> dict[str, object]:
        self.validate_action_features(snapshot.features)
        return snapshot.safe_action_context(allow_inferred=self.allow_inferred_for_action)
