from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import Any, Mapping, Sequence

from .types import ActionCandidate, Branch, BranchObservation, EpistemicSource, FeatureValue, WorldSnapshot


Point = tuple[int, int]
MOVES: dict[str, Point] = {
    "STAY": (0, 0),
    "N": (0, -1),
    "S": (0, 1),
    "W": (-1, 0),
    "E": (1, 0),
}


@dataclass(frozen=True, slots=True)
class GridState:
    width: int
    height: int
    hunter: Point
    target: Point
    walls: frozenset[Point] = frozenset()

    def __post_init__(self) -> None:
        if self.width < 1 or self.height < 1:
            raise ValueError("grid dimensions must be positive")
        for p in (self.hunter, self.target, *self.walls):
            if not (0 <= p[0] < self.width and 0 <= p[1] < self.height):
                raise ValueError(f"point outside grid: {p}")
        if self.hunter in self.walls or self.target in self.walls:
            raise ValueError("hunter/target cannot occupy a wall")

    def snapshot(self, step: int) -> WorldSnapshot:
        return WorldSnapshot(
            step=step,
            features={
                "width": FeatureValue(self.width, EpistemicSource.OBSERVED),
                "height": FeatureValue(self.height, EpistemicSource.OBSERVED),
                "hunter": FeatureValue(self.hunter, EpistemicSource.OBSERVED),
                "target": FeatureValue(self.target, EpistemicSource.OBSERVED),
                "walls": FeatureValue(tuple(sorted(self.walls)), EpistemicSource.OBSERVED),
            },
        )


class GridPursuitOracle:
    """Concrete Monte-Carlo branch generator + evaluator for interception planning.

    It predicts stochastic target movement, then values each legal hunter move by
    discounted interception/convergence utility across the generated futures.
    """

    def __init__(self, capture_reward: float = 100.0, distance_penalty: float = 3.0, discount: float = 0.92) -> None:
        if capture_reward <= 0 or distance_penalty < 0 or not 0 < discount <= 1:
            raise ValueError("invalid grid pursuit scoring parameters")
        self.capture_reward = capture_reward
        self.distance_penalty = distance_penalty
        self.discount = discount

    @staticmethod
    def _parse(snapshot: WorldSnapshot) -> GridState:
        p = snapshot.safe_action_context()
        return GridState(
            int(p["width"]),
            int(p["height"]),
            tuple(p["hunter"]),
            tuple(p["target"]),
            frozenset(tuple(x) for x in p["walls"]),
        )

    @staticmethod
    def _legal(point: Point, state: GridState) -> list[tuple[str, Point]]:
        result = []
        for name, delta in MOVES.items():
            nxt = (point[0] + delta[0], point[1] + delta[1])
            if 0 <= nxt[0] < state.width and 0 <= nxt[1] < state.height and nxt not in state.walls:
                result.append((name, nxt))
        return result

    @staticmethod
    def _manhattan(a: Point, b: Point) -> int:
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def _target_move(self, target: Point, hunter: Point, state: GridState, rng: random.Random) -> Point:
        legal = self._legal(target, state)
        # Escape-biased stochastic policy: farther moves are more likely but all legal moves retain support.
        scored = []
        for _, nxt in legal:
            d = self._manhattan(nxt, hunter)
            weight = math.exp(0.7 * d)
            scored.append((nxt, weight))
        total = sum(w for _, w in scored)
        r = rng.random() * total
        running = 0.0
        for nxt, weight in scored:
            running += weight
            if r <= running:
                return nxt
        return scored[-1][0]

    def generate(self, snapshot: WorldSnapshot, branch_count: int, horizon: int, seed: int) -> list[Branch]:
        state = self._parse(snapshot)
        rng = random.Random(seed)
        branches: list[Branch] = []
        # Monte-Carlo samples are equiprobable empirical particles.
        probability = 1.0 / branch_count
        for i in range(branch_count):
            target = state.target
            trajectory: list[BranchObservation] = []
            for h in range(1, horizon + 1):
                target = self._target_move(target, state.hunter, state, rng)
                trajectory.append(BranchObservation(h, {"target": target}))
            branches.append(
                Branch(
                    branch_id=f"b{i:04d}",
                    probability=probability,
                    trajectory=tuple(trajectory),
                    metadata={"seed": seed, "sample": i},
                )
            )
        return branches

    def actions(self, snapshot: WorldSnapshot) -> list[ActionCandidate]:
        state = self._parse(snapshot)
        return [ActionCandidate(name, nxt) for name, nxt in self._legal(state.hunter, state)]

    def evaluate(
        self,
        snapshot: WorldSnapshot,
        branches: Sequence[Branch],
        actions: Sequence[ActionCandidate],
    ) -> Mapping[str, Mapping[str, float]]:
        state = self._parse(snapshot)
        result: dict[str, dict[str, float]] = {}
        for branch in branches:
            target_path = [tuple(obs.features["target"]) for obs in branch.trajectory]
            by_action: dict[str, float] = {}
            for action in actions:
                initial = tuple(action.payload)
                # Dynamic programming over all hunter positions reachable after the
                # first committed action. Within a branch the future target path is
                # known; cross-branch weighting prevents treating any one path as fact.
                frontier: dict[Point, float] = {initial: 0.0}
                best_terminal = -float("inf")
                for idx, target in enumerate(target_path, start=1):
                    discount = self.discount ** (idx - 1)
                    scored_frontier: dict[Point, float] = {}
                    for hunter, accumulated in frontier.items():
                        distance = self._manhattan(hunter, target)
                        if distance == 0:
                            best_terminal = max(
                                best_terminal, accumulated + discount * self.capture_reward
                            )
                            continue
                        proximity = -self.distance_penalty * distance
                        if distance == 1:
                            proximity += 6.0
                        score = accumulated + discount * proximity
                        previous = scored_frontier.get(hunter)
                        if previous is None or score > previous:
                            scored_frontier[hunter] = score

                    if idx == len(target_path):
                        if scored_frontier:
                            best_terminal = max(best_terminal, max(scored_frontier.values()))
                        break

                    next_frontier: dict[Point, float] = {}
                    for hunter, score in scored_frontier.items():
                        for _, nxt in self._legal(hunter, state):
                            previous = next_frontier.get(nxt)
                            if previous is None or score > previous:
                                next_frontier[nxt] = score
                    frontier = next_frontier
                    if not frontier:
                        break

                if best_terminal == -float("inf"):
                    best_terminal = -1e9
                immediate_distance = self._manhattan(initial, state.target)
                by_action[action.action_id] = best_terminal - 0.5 * immediate_distance
            result[branch.branch_id] = by_action
        return result

    def observation_likelihoods(
        self,
        branches: Sequence[Branch],
        actual_observation: Mapping[str, Any] | None,
    ) -> Mapping[str, float] | None:
        if not actual_observation or "target" not in actual_observation:
            return None
        actual = tuple(actual_observation["target"])
        likelihoods = {}
        for branch in branches:
            predicted = tuple(branch.trajectory[0].features["target"])
            distance = self._manhattan(predicted, actual)
            likelihoods[branch.branch_id] = math.exp(-1.5 * distance)
        return likelihoods

    def predict_next_observation(self, branches: Sequence[Branch], probabilities: Mapping[str, float]) -> dict[str, Any]:
        mass: dict[Point, float] = {}
        for branch in branches:
            if not branch.trajectory:
                continue
            target = tuple(branch.trajectory[0].features["target"])
            mass[target] = mass.get(target, 0.0) + probabilities.get(branch.branch_id, 0.0)
        if not mass:
            return {}
        return {"target": max(mass, key=lambda p: (mass[p], -p[0], -p[1]))}


@dataclass(frozen=True, slots=True)
class GridStepOutcome:
    state: GridState
    reward: float
    captured: bool


class GridPursuitEnvironment:
    """Executable stochastic environment used to validate closed-loop oracle behavior."""

    def __init__(self, initial_state: GridState, *, seed: int = 1) -> None:
        self.state = initial_state
        self._rng = random.Random(seed)
        self._dynamics = GridPursuitOracle()
        self.step_index = 0

    def snapshot(self) -> WorldSnapshot:
        return self.state.snapshot(self.step_index)

    def step(self, action: ActionCandidate | str) -> GridStepOutcome:
        action_id = action.action_id if isinstance(action, ActionCandidate) else str(action)
        legal = dict(self._dynamics._legal(self.state.hunter, self.state))
        if action_id not in legal:
            raise ValueError(f"illegal hunter action {action_id!r}; legal={sorted(legal)}")
        hunter = legal[action_id]
        target = self.state.target
        if hunter == target:
            self.state = GridState(self.state.width, self.state.height, hunter, target, self.state.walls)
            self.step_index += 1
            return GridStepOutcome(self.state, self._dynamics.capture_reward, True)

        target = self._dynamics._target_move(target, hunter, self.state, self._rng)
        captured = hunter == target
        distance = self._dynamics._manhattan(hunter, target)
        reward = self._dynamics.capture_reward if captured else -float(distance)
        self.state = GridState(self.state.width, self.state.height, hunter, target, self.state.walls)
        self.step_index += 1
        return GridStepOutcome(self.state, reward, captured)
