from __future__ import annotations

"""Closed-loop ARC-AGI-3 Multiverse Oracle policy."""

from collections import Counter
from dataclasses import asdict
from typing import Any, Mapping

from .adl_adapter import ADLOracleAdapter
from .causal import CausalTransitionGraph
from .ghostbridge_adapter import GhostBridgeOracleAdapter
from .oracle import MultiverseOracleEngine, OracleConfig
from .planner import CrossWorldPlanner, PlannerConfig
from .types import EpistemicSource, FeatureValue, WorldSnapshot
from .glyphmatics.executor_registry import MechanicExecutionContext
from .rdl.types import MechanicProbe
from .runtime_mechanics import RuntimeMechanicOracle
from .arcagi3_types import (
    Grid, ARCActionPlan, ARCDifferenceHypothesis, ARCObservation, ARCPlanAlternative,
    ARCPlanCycle, ARCPlanStep, ARCPolicyConfig,
)
from .arcagi3_state import ARCStateEncoder, ARCFrameAdapter, ARCOnlineDifferenceLearner
from .arcagi3_model import (
    ARCBranchEvaluator, ARCBranchGenerator, ARCClickCandidateGenerator, ARCTransitionModel,
)

class ARCAGI3Policy:
    """Closed-loop ARC-AGI-3 policy using Oracle + ADL + GhostBridge.

    The policy does not require a target grid.  Goals are inferred from real
    progress signals (``levels_completed``/WIN), transition novelty and action
    consequences.  This matches ARC-AGI-3's interactive goal-acquisition setup.
    """

    def __init__(
        self,
        config: ARCPolicyConfig | None = None,
        *,
        runtime_mechanic_oracle: RuntimeMechanicOracle | None = None,
    ) -> None:
        self.config = config or ARCPolicyConfig()
        self.runtime_mechanic_oracle = runtime_mechanic_oracle
        self.encoder = ARCStateEncoder()
        self.frame_adapter = ARCFrameAdapter(self.encoder)
        self.diff_learner = ARCOnlineDifferenceLearner(self.config)
        self.causal_graph = CausalTransitionGraph()
        self.transition_model = ARCTransitionModel(self.causal_graph)
        self.branch_generator = ARCBranchGenerator(self.transition_model, self.config)
        self.branch_evaluator = ARCBranchEvaluator()
        planner = CrossWorldPlanner(
            PlannerConfig(
                risk_aversion=self.config.risk_aversion,
                worst_case_weight=self.config.worst_case_weight,
            )
        )
        self.oracle = MultiverseOracleEngine(
            self.branch_generator,
            self.branch_evaluator,
            config=OracleConfig(
                branch_count=self.config.branch_count,
                horizon=self.config.horizon,
                seed=self.config.seed,
                strict_epistemic_boundary=True,
            ),
            planner=planner,
        )
        self.previous_observation: ARCObservation | None = None
        self.pending_plan: ARCActionPlan | None = None
        self.last_difference: ARCDifferenceHypothesis | None = None
        self.stall_count = 0
        self.step_index = 0
        self.telemetry_history: list[Mapping[str, Any]] = []
        self.plan_cycle_history: list[ARCPlanCycle] = []
        self.feedback_history: list[Mapping[str, Any]] = []
        self._next_replan_reason = "initial_observation"
        self._last_grid_before_action: Grid | None = None
        self.pending_runtime_probe: MechanicProbe | None = None

    def reset_episode(self, *, preserve_learning: bool = True) -> None:
        self.previous_observation = None
        self.pending_plan = None
        self.last_difference = None
        self.stall_count = 0
        self.step_index = 0
        self.telemetry_history.clear()
        self.plan_cycle_history.clear()
        self.feedback_history.clear()
        self._next_replan_reason = "initial_observation"
        self._last_grid_before_action = None
        self.pending_runtime_probe = None
        if not preserve_learning:
            self.causal_graph = CausalTransitionGraph()
            self.transition_model = ARCTransitionModel(self.causal_graph)
            self.branch_generator.model = self.transition_model

    @staticmethod
    def _is_terminal(obs: ARCObservation) -> bool:
        return obs.state_name == "WIN"

    @staticmethod
    def _is_reset_required(obs: ARCObservation) -> bool:
        return obs.state_name in {"GAME_OVER", "NOT_STARTED", "NOT_PLAYED"}

    def _ingest_feedback(self, obs: ARCObservation) -> ARCDifferenceHypothesis | None:
        """Commit one *real* action result to ADL/GhostBridge/causal memory.

        The pending plan is consumed exactly once. This makes terminal WIN and
        GAME_OVER transitions learnable even when the execution loop stops before
        asking the policy for another action.
        """
        if self.previous_observation is None or self.pending_plan is None:
            return None

        executed = self.pending_plan
        before = self.previous_observation
        diff = self.diff_learner.compare(before, obs)
        self.last_difference = diff
        self.transition_model.record(before, executed, diff)

        predicted_distribution: Mapping[str, float] = {}
        if executed.planning_cycle is not None:
            predicted_distribution = executed.planning_cycle.predicted_outcome_distribution
        predicted = (
            max(predicted_distribution, key=predicted_distribution.get)
            if predicted_distribution
            else "UNKNOWN"
        )
        prediction_matched = predicted == diff.outcome_class

        if diff.outcome_class in {"NO_CHANGE", "GAME_OVER"}:
            self.stall_count += 1
        elif diff.outcome_class in {"PROGRESS", "WIN"}:
            self.stall_count = 0
        else:
            self.stall_count = max(0, self.stall_count - 1)

        if diff.outcome_class == "WIN":
            reason = "terminal_win_feedback"
        elif diff.outcome_class == "GAME_OVER":
            reason = "game_over_feedback"
        elif diff.outcome_class == "PROGRESS":
            reason = "progress_feedback"
        elif diff.outcome_class == "NO_CHANGE":
            reason = "stall_feedback"
        elif not prediction_matched and predicted != "UNKNOWN":
            reason = f"prediction_mismatch:{predicted}->{diff.outcome_class}"
        else:
            reason = "new_real_observation"
        self._next_replan_reason = reason
        runtime_probe_feedback = None
        if self.pending_runtime_probe is not None and self.runtime_mechanic_oracle is not None:
            confirmed = diff.outcome_class in {"CHANGE", "PROGRESS", "WIN"}
            posterior = self.runtime_mechanic_oracle.record_probe_result(
                self.pending_runtime_probe.mechanic_id,
                confirmed=confirmed,
                reliability=0.90,
            )
            runtime_probe_feedback = {
                "mechanic_id": self.pending_runtime_probe.mechanic_id,
                "glyph_id": self.pending_runtime_probe.glyph_id,
                "confirmed": confirmed,
                "posterior": posterior,
            }
            self.pending_runtime_probe = None

        self.feedback_history.append(
            {
                "action_step": before.step,
                "candidate_id": executed.candidate_id,
                "actual_state_key": obs.key.compact,
                "actual_outcome": diff.outcome_class,
                "predicted_modal_outcome": predicted,
                "prediction_matched": prediction_matched,
                "utility": diff.utility,
                "levels_delta": diff.levels_delta,
                "stall_count": self.stall_count,
                "replan_reason": reason,
                "runtime_probe_feedback": runtime_probe_feedback,
            }
        )
        # Consume the pending action so a caller that explicitly ingests this
        # frame and then calls plan(frame) cannot double-count the transition.
        self.pending_plan = None
        return diff

    def ingest_result(self, frame: Any, *, fallback_game_id: str = "") -> ARCObservation:
        """Immediately ingest an EnvironmentWrapper result frame.

        Agent-framework integrations can omit this call because ``plan`` ingests
        the prior pending action on the next choose_action invocation. Direct
        environment loops should call it after every env.step/reset.
        """
        obs = self.frame_adapter.from_frame(
            frame, step=self.step_index, fallback_game_id=fallback_game_id
        )
        self._ingest_feedback(obs)
        return obs

    @staticmethod
    def _simple_payload(action_name: str) -> dict[str, int]:
        return {}

    def _candidate_payloads(self, obs: ARCObservation) -> dict[str, dict[str, int]]:
        legal = set(obs.available_action_names)
        if self._is_reset_required(obs):
            return {"RESET": {}}
        payloads: dict[str, dict[str, int]] = {}
        for name in sorted(legal):
            if name == "RESET":
                continue
            if name == "ACTION6":
                for x, y in ARCClickCandidateGenerator.generate(
                    obs.settled_grid,
                    self._last_grid_before_action,
                    limit=self.config.max_click_candidates,
                ):
                    payloads[f"ACTION6:{x}:{y}"] = {"x": x, "y": y}
            elif name.startswith("ACTION"):
                payloads[name] = self._simple_payload(name)
        # If the runtime reports no legal non-reset action, fail closed to RESET.
        if not payloads:
            payloads["RESET"] = {}
        return payloads

    def _filter_phantoms(self, obs: ARCObservation, payloads: dict[str, dict[str, int]]) -> dict[str, dict[str, int]]:
        if len(payloads) <= 1:
            return payloads
        safe = {
            cid: data
            for cid, data in payloads.items()
            if self.transition_model.phantom_risk(obs, cid) < self.config.phantom_fail_closed_threshold
        }
        return safe or payloads

    def _hard_stall_choice(self, obs: ARCObservation, payloads: Mapping[str, Mapping[str, int]]) -> str:
        # Deterministic least-tried legal strategy shift.  It cannot emit an
        # unavailable action and avoids arbitrary Python hash/random behavior.
        return min(
            payloads,
            key=lambda cid: (
                self.transition_model.action_visits[cid],
                self.transition_model.phantom_risk(obs, cid),
                cid,
            ),
        )

    def _snapshot(self, obs: ARCObservation, payloads: Mapping[str, Mapping[str, int]]) -> WorldSnapshot:
        return WorldSnapshot(
            step=self.step_index,
            features={
                "game_id": FeatureValue(obs.game_id, EpistemicSource.OBSERVED),
                "state_name": FeatureValue(obs.state_name, EpistemicSource.OBSERVED),
                "levels_completed": FeatureValue(obs.levels_completed, EpistemicSource.OBSERVED),
                "win_levels": FeatureValue(obs.win_levels, EpistemicSource.OBSERVED),
                "state_key": FeatureValue(obs.key.compact, EpistemicSource.OBSERVED),
                "available_actions": FeatureValue(obs.available_action_names, EpistemicSource.OBSERVED),
                "motion_fraction": FeatureValue(obs.motion_fraction, EpistemicSource.OBSERVED),
                "stall_count": FeatureValue(self.stall_count, EpistemicSource.INFERRED, confidence=1.0),
                "arc_observation": FeatureValue(obs, EpistemicSource.INFERRED, confidence=1.0),
                "action_candidate_ids": FeatureValue(tuple(payloads), EpistemicSource.INFERRED, confidence=1.0),
                "action_candidate_payloads": FeatureValue(dict(payloads), EpistemicSource.INFERRED, confidence=1.0),
            },
        )

    @staticmethod
    def _normalize_mass(mass: Mapping[str, float]) -> dict[str, float]:
        total = sum(max(0.0, float(v)) for v in mass.values())
        if total <= 0.0:
            return {}
        return {str(k): max(0.0, float(v)) / total for k, v in mass.items()}

    def _build_plan_cycle(
        self,
        obs: ARCObservation,
        payloads: Mapping[str, Mapping[str, int]],
        result: Any,
        chosen_id: str,
        *,
        replan_reason: str,
    ) -> ARCPlanCycle:
        """Collapse sampled future worlds into an inspectable action sequence.

        This is a receding-horizon plan, not a promise to execute simulated
        future steps. Only the first action is committed. Every subsequent real
        frame invalidates the unexecuted tail and causes a fresh plan cycle.
        """
        surviving = set(result.collapse.surviving_branch_ids)
        posterior = {
            bid: p
            for bid, p in result.collapse.probabilities.items()
            if bid in surviving
        }
        posterior = self._normalize_mass(posterior)

        outcome_mass: Counter[str] = Counter()
        path_mass: Counter[tuple[str, ...]] = Counter()
        for branch in result.branches:
            if branch.branch_id not in surviving:
                continue
            weight = posterior.get(branch.branch_id, 0.0)
            predicted = branch.metadata.get("predicted_outcomes", {}).get(chosen_id)
            if predicted is not None:
                outcome_mass[str(predicted)] += weight
            path = tuple(str(v) for v in branch.metadata.get("rollouts", {}).get(chosen_id, ()))
            if path:
                path_mass[path] += weight

        outcome_distribution = self._normalize_mass(outcome_mass)
        if path_mass:
            representative_path, representative_support = max(
                path_mass.items(), key=lambda item: (item[1], item[0])
            )
        else:
            modal = max(outcome_distribution, key=outcome_distribution.get) if outcome_distribution else "UNKNOWN"
            representative_path = (f"{chosen_id}>{modal}",)
            representative_support = 1.0

        steps: list[ARCPlanStep] = []
        for depth, encoded in enumerate(representative_path, start=1):
            if ">" in encoded:
                cid, outcome = encoded.rsplit(">", 1)
            else:
                cid, outcome = encoded, "UNKNOWN"
            if cid not in payloads:
                # A future abstract continuation must remain executable under the
                # root legal action set. Unknown branch artifacts are discarded.
                continue
            steps.append(
                ARCPlanStep(
                    depth=depth,
                    candidate_id=cid,
                    action_name=ARCTransitionModel.base_action(cid),
                    data=dict(payloads[cid]),
                    predicted_outcome=outcome,
                    branch_support=float(representative_support),
                )
            )
        if not steps or steps[0].candidate_id != chosen_id:
            modal = max(outcome_distribution, key=outcome_distribution.get) if outcome_distribution else "UNKNOWN"
            steps.insert(
                0,
                ARCPlanStep(
                    depth=1,
                    candidate_id=chosen_id,
                    action_name=ARCTransitionModel.base_action(chosen_id),
                    data=dict(payloads[chosen_id]),
                    predicted_outcome=modal,
                    branch_support=float(representative_support),
                ),
            )

        alternatives: list[ARCPlanAlternative] = []
        for rank, decision in enumerate(result.ranked_decisions, start=1):
            cid = decision.action.action_id
            if cid not in payloads:
                continue
            alternatives.append(
                ARCPlanAlternative(
                    rank=rank,
                    candidate_id=cid,
                    action_name=ARCTransitionModel.base_action(cid),
                    data=dict(payloads[cid]),
                    robust_score=float(decision.score),
                    expected_value=float(decision.expected_value),
                    variance=float(decision.variance),
                    worst_case=float(decision.worst_case),
                    phantom_risk=float(self.transition_model.phantom_risk(obs, cid)),
                )
            )

        selected_decision = next(
            (d for d in result.ranked_decisions if d.action.action_id == chosen_id),
            result.decision,
        )
        return ARCPlanCycle(
            cycle_id=len(self.plan_cycle_history),
            root_state_key=obs.key.compact,
            replan_reason=replan_reason,
            selected_candidate_id=chosen_id,
            selected_score=float(selected_decision.score),
            selected_expected_value=float(selected_decision.expected_value),
            predicted_outcome_distribution=outcome_distribution,
            representative_path_support=float(representative_support),
            steps=tuple(steps[: self.config.horizon]),
            alternatives=tuple(alternatives),
        )

    def _reset_plan_cycle(self, obs: ARCObservation, replan_reason: str) -> ARCPlanCycle:
        return ARCPlanCycle(
            cycle_id=len(self.plan_cycle_history),
            root_state_key=obs.key.compact,
            replan_reason=replan_reason,
            selected_candidate_id="RESET",
            selected_score=0.0,
            selected_expected_value=0.0,
            predicted_outcome_distribution={"RESET": 1.0},
            representative_path_support=1.0,
            steps=(
                ARCPlanStep(
                    depth=1,
                    candidate_id="RESET",
                    action_name="RESET",
                    data={},
                    predicted_outcome="RESET",
                    branch_support=1.0,
                ),
            ),
            alternatives=(
                ARCPlanAlternative(
                    rank=1,
                    candidate_id="RESET",
                    action_name="RESET",
                    data={},
                    robust_score=0.0,
                    expected_value=0.0,
                    variance=0.0,
                    worst_case=0.0,
                    phantom_risk=0.0,
                ),
            ),
        )

    def plan(self, frame: Any, *, fallback_game_id: str = "") -> ARCActionPlan:
        """Build one receding-horizon plan and return its first executable action.

        The planning loop is model-predictive control: every call first consumes
        the real result of the previously executed action, updates ADL/causal
        evidence, generates a fresh multiverse plan, and commits exactly one
        legal action. The simulated tail is diagnostic/strategic context only.
        """
        obs = self.frame_adapter.from_frame(
            frame, step=self.step_index, fallback_game_id=fallback_game_id
        )
        self._ingest_feedback(obs)
        replan_reason = self._next_replan_reason

        if self._is_terminal(obs):
            raise RuntimeError("cannot plan an action after WIN")

        payloads = self._filter_phantoms(obs, self._candidate_payloads(obs))
        result = None
        if self._is_reset_required(obs):
            chosen_id = "RESET"
            decision_score = expected = 0.0
            oracle_telemetry: Mapping[str, Any] = {
                "anomaly_score": 0.0,
                "epistemic_leakage": 0.0,
                "reason": "reset-required terminal/start state",
            }
            plan_cycle = self._reset_plan_cycle(obs, replan_reason)
        else:
            snapshot = self._snapshot(obs, payloads)
            result = self.oracle.step(snapshot)
            chosen_id = result.decision.action.action_id
            selected_decision = result.decision
            oracle_telemetry = ADLOracleAdapter.as_mapping(result.telemetry)
            oracle_telemetry = {
                **oracle_telemetry,
                "posterior_entropy_bits": result.telemetry.posterior_entropy_bits,
                "selected_action_id": result.telemetry.selected_action_id,
                "ranked_candidate_count": len(result.ranked_decisions),
            }
            if self.stall_count >= self.config.hard_stall:
                chosen_id = self._hard_stall_choice(obs, payloads)
                selected_decision = next(
                    (d for d in result.ranked_decisions if d.action.action_id == chosen_id),
                    result.decision,
                )
                oracle_telemetry = {
                    **oracle_telemetry,
                    "hard_stall_override": True,
                    "oracle_original_selection": result.decision.action.action_id,
                    "selected_action_id": chosen_id,
                }
            runtime_probe = None
            if self.config.runtime_mechanics_enabled and self.runtime_mechanic_oracle is not None:
                action_aliases: dict[str, str] = {}
                for candidate_id in payloads:
                    base = ARCTransitionModel.base_action(candidate_id)
                    action_aliases.setdefault(base, candidate_id)
                    action_aliases.setdefault(candidate_id, candidate_id)
                observation_terms = [
                    "state",
                    "transition",
                    "stall" if self.stall_count >= self.config.soft_stall else "progress",
                ]
                mechanic_context = MechanicExecutionContext(
                    legal_actions=tuple(payloads),
                    planner_value=max(0.0, float(selected_decision.expected_value)),
                    potential_reward=self.config.runtime_probe_potential_reward,
                    action_cost=self.config.runtime_probe_action_cost,
                    failure_risk=self.config.runtime_probe_failure_risk,
                    grid_shape=(len(obs.settled_grid), len(obs.settled_grid[0]) if obs.settled_grid else 0),
                    action_aliases=action_aliases,
                )
                runtime_probe = self.runtime_mechanic_oracle.recommend_probe(
                    mechanic_context, observation_terms=observation_terms
                )
                if runtime_probe is not None:
                    probe_id = action_aliases.get(str(runtime_probe.action), str(runtime_probe.action))
                    if probe_id in payloads:
                        chosen_id = probe_id
                        selected_decision = next(
                            (d for d in result.ranked_decisions if d.action.action_id == chosen_id),
                            selected_decision,
                        )
                        self.pending_runtime_probe = runtime_probe
                        oracle_telemetry = {
                            **oracle_telemetry,
                            "runtime_mechanic_probe": {
                                "mechanic_id": runtime_probe.mechanic_id,
                                "glyph_id": runtime_probe.glyph_id,
                                "probe_value": runtime_probe.probe_value,
                                "information_gain": runtime_probe.information_gain,
                                "selected_action_id": chosen_id,
                            },
                            "selected_action_id": chosen_id,
                        }

            decision_score = float(selected_decision.score)
            expected = float(selected_decision.expected_value)
            plan_cycle = self._build_plan_cycle(
                obs, payloads, result, chosen_id, replan_reason=replan_reason
            )

        data = dict(payloads[chosen_id])
        action_name = ARCTransitionModel.base_action(chosen_id)
        phantom = self.transition_model.phantom_risk(obs, chosen_id)
        required = [(self.transition_model.source_node(obs, chosen_id), "PROGRESS")]
        diagnosis = GhostBridgeOracleAdapter.diagnose(
            self.causal_graph,
            required,
            phantom_threshold=self.config.phantom_fail_closed_threshold,
        )
        reasoning = {
            "system": "multiverse_oracle_arcagi3",
            "control": "receding_horizon_model_predictive_planning",
            "state_key": obs.key.compact,
            "state": obs.state_name,
            "levels_completed": obs.levels_completed,
            "win_levels": obs.win_levels,
            "available_actions": list(obs.available_action_names),
            "candidate_id": chosen_id,
            "candidate_count": len(payloads),
            "stall_count": self.stall_count,
            "phantom_risk": phantom,
            "replan_reason": replan_reason,
            "adl_last_difference": self.last_difference.as_mapping() if self.last_difference else None,
            "adl_oracle_metrics": dict(oracle_telemetry),
            "ghostbridge": {
                "missing_bridges": list(diagnosis.missing_bridges),
                "phantom_bridges": list(diagnosis.phantom_bridges),
            },
            "planning_loop": asdict(plan_cycle),
        }
        plan = ARCActionPlan(
            action_name=action_name,
            data=data,
            candidate_id=chosen_id,
            oracle_score=float(decision_score),
            expected_value=float(expected),
            phantom_risk=float(phantom),
            stall_count=self.stall_count,
            reasoning=reasoning,
            planning_cycle=plan_cycle,
        )
        self.previous_observation = obs
        self.pending_plan = plan
        self._last_grid_before_action = obs.settled_grid
        self.telemetry_history.append(reasoning)
        self.plan_cycle_history.append(plan_cycle)
        self._next_replan_reason = "awaiting_real_feedback"
        self.step_index += 1
        return plan

    def summary(self) -> dict[str, Any]:
        return {
            "steps": self.step_index,
            "stall_count": self.stall_count,
            "last_difference": self.last_difference.as_mapping() if self.last_difference else None,
            "planning_cycles": len(self.plan_cycle_history),
            "feedback_events": len(self.feedback_history),
            "last_replan_reason": self._next_replan_reason,
            "last_feedback": dict(self.feedback_history[-1]) if self.feedback_history else None,
            "causal_edges": self.causal_graph.snapshot(),
            "global_action_stats": {
                action: asdict(stats) for action, stats in sorted(self.transition_model.global_stats.items())
            },
            "max_epistemic_leakage": max(
                (
                    float(t.get("adl_oracle_metrics", {}).get("epistemic_leakage", 0.0))
                    for t in self.telemetry_history
                ),
                default=0.0,
            ),
        }
