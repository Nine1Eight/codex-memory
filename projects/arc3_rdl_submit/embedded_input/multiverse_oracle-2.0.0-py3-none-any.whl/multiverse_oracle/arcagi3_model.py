from __future__ import annotations

"""ARC action candidates, causal transition learning, branch generation, and evaluation."""

from collections import Counter, defaultdict, deque
import math
import random
from typing import Any, Mapping, Sequence

from .arcagi3_types import (
    Grid, ARCActionPlan, ARCDifferenceHypothesis, ARCObservation, ARCPolicyConfig, OutcomeStats,
)
from .causal import CausalTransitionGraph
from .types import ActionCandidate, Branch, BranchObservation, WorldSnapshot

class ARCClickCandidateGenerator:
    @staticmethod
    def _components(grid: Grid, color: int) -> list[list[tuple[int, int]]]:
        if not grid:
            return []
        h, w = len(grid), len(grid[0])
        seen: set[tuple[int, int]] = set()
        out: list[list[tuple[int, int]]] = []
        for y in range(h):
            for x in range(w):
                if grid[y][x] != color or (x, y) in seen:
                    continue
                q = deque([(x, y)])
                seen.add((x, y))
                comp: list[tuple[int, int]] = []
                while q:
                    cx, cy = q.popleft()
                    comp.append((cx, cy))
                    for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                        if 0 <= nx < w and 0 <= ny < h and (nx, ny) not in seen and grid[ny][nx] == color:
                            seen.add((nx, ny))
                            q.append((nx, ny))
                out.append(comp)
        return out

    @classmethod
    def generate(
        cls,
        grid: Grid,
        previous: Grid | None,
        *,
        limit: int,
    ) -> list[tuple[int, int]]:
        if not grid:
            return [(32, 32)]
        h, w = len(grid), len(grid[0])
        candidates: list[tuple[int, int]] = []

        # Highest priority: cells that changed on the last real action.
        if previous and len(previous) == h and len(previous[0]) == w:
            changed = [(x, y) for y in range(h) for x in range(w) if previous[y][x] != grid[y][x]]
            if changed:
                candidates.append((round(sum(x for x, _ in changed) / len(changed)), round(sum(y for _, y in changed) / len(changed))))
                candidates.extend(changed[: min(6, len(changed))])

        counts = Counter(v for row in grid for v in row)
        background = max(counts, key=lambda c: (counts[c], -c))
        # Rare/non-background connected components are strong generic click hypotheses.
        for color, _ in sorted(counts.items(), key=lambda kv: (kv[1], kv[0])):
            if color == background:
                continue
            for comp in sorted(cls._components(grid, color), key=lambda c: (len(c), c[0])):
                xs, ys = [p[0] for p in comp], [p[1] for p in comp]
                candidates.append((round(sum(xs) / len(xs)), round(sum(ys) / len(ys))))
                candidates.append((min(xs), min(ys)))
                if len(candidates) >= limit * 2:
                    break
            if len(candidates) >= limit * 2:
                break

        # Spatial fallback points ensure ACTION6 is always executable.
        candidates.extend(
            [
                (w // 2, h // 2),
                (w // 4, h // 4),
                (3 * w // 4, h // 4),
                (w // 4, 3 * h // 4),
                (3 * w // 4, 3 * h // 4),
            ]
        )
        deduped: list[tuple[int, int]] = []
        seen: set[tuple[int, int]] = set()
        for x, y in candidates:
            point = (max(0, min(63, int(x))), max(0, min(63, int(y))))
            if point not in seen:
                seen.add(point)
                deduped.append(point)
            if len(deduped) >= limit:
                break
        return deduped


class ARCTransitionModel:
    def __init__(self, causal_graph: CausalTransitionGraph | None = None) -> None:
        self.causal_graph = causal_graph or CausalTransitionGraph()
        self.global_stats: dict[str, OutcomeStats] = defaultdict(OutcomeStats)
        self.local_stats: dict[tuple[str, str], OutcomeStats] = defaultdict(OutcomeStats)
        self.outcome_counts: dict[tuple[str, str], Counter[str]] = defaultdict(Counter)
        self.action_visits: Counter[str] = Counter()

    @staticmethod
    def base_action(candidate_id: str) -> str:
        return candidate_id.split(":", 1)[0]

    @staticmethod
    def source_node(obs: ARCObservation, candidate_id: str) -> str:
        return f"{obs.game_id}|L{obs.levels_completed}|{obs.key.compact}|{candidate_id}"

    def record(self, before: ARCObservation, plan: ARCActionPlan, diff: ARCDifferenceHypothesis) -> None:
        cid = plan.candidate_id
        base = self.base_action(cid)
        self.global_stats[base].record(diff.outcome_class, diff.utility)
        self.local_stats[(before.key.structural_hash, cid)].record(diff.outcome_class, diff.utility)
        self.outcome_counts[(before.key.structural_hash, cid)][diff.outcome_class] += 1
        self.action_visits[cid] += 1

        source = self.source_node(before, cid)
        actual = diff.outcome_class
        # Mark actual outcome as supported and competing previously simulated
        # outcomes as contradicted. This lets phantom score emerge from evidence.
        self.causal_graph.record_observed(source, actual, True)
        for outcome in ("PROGRESS", "CHANGE", "NO_CHANGE", "GAME_OVER", "WIN"):
            edge = self.causal_graph.edge(source, outcome)
            if outcome != actual and edge.simulated_support > 0:
                self.causal_graph.record_observed(source, outcome, False)

    def stats_for(self, obs: ARCObservation, candidate_id: str) -> tuple[OutcomeStats, OutcomeStats]:
        base = self.base_action(candidate_id)
        return self.global_stats[base], self.local_stats[(obs.key.structural_hash, candidate_id)]

    def phantom_risk(self, obs: ARCObservation, candidate_id: str) -> float:
        source = self.source_node(obs, candidate_id)
        return max(
            self.causal_graph.edge(source, "PROGRESS").phantom_score,
            self.causal_graph.edge(source, "CHANGE").phantom_score,
        )


class ARCBranchGenerator:
    def __init__(self, model: ARCTransitionModel, config: ARCPolicyConfig) -> None:
        self.model = model
        self.config = config

    @staticmethod
    def _candidate_ids(snapshot: WorldSnapshot) -> tuple[str, ...]:
        value = snapshot.features["action_candidate_ids"].value
        return tuple(str(x) for x in value)

    @staticmethod
    def _obs_from_snapshot(snapshot: WorldSnapshot) -> ARCObservation:
        return snapshot.features["arc_observation"].value

    @staticmethod
    def _beta(rng: random.Random, success: float, failure: float) -> float:
        return rng.betavariate(max(0.001, success), max(0.001, failure))

    @staticmethod
    def _sample_outcome(rng: random.Random, weights: Mapping[str, float]) -> str:
        total = sum(max(0.0, float(v)) for v in weights.values())
        if total <= 0.0:
            return "NO_CHANGE"
        threshold = rng.random() * total
        acc = 0.0
        for outcome, value in weights.items():
            acc += max(0.0, float(value))
            if threshold <= acc:
                return outcome
        return next(reversed(weights))

    def _outcome_utility(self, outcome: str) -> float:
        if outcome == "WIN":
            return self.config.win_reward + self.config.progress_reward
        if outcome == "PROGRESS":
            return self.config.progress_reward
        if outcome == "CHANGE":
            return self.config.visual_change_reward
        if outcome == "GAME_OVER":
            return -self.config.game_over_penalty
        return -self.config.no_change_penalty

    def generate(self, snapshot: WorldSnapshot, branch_count: int, horizon: int, seed: int) -> list[Branch]:
        rng = random.Random(seed)
        obs = self._obs_from_snapshot(snapshot)
        candidate_ids = self._candidate_ids(snapshot)
        if not candidate_ids:
            raise ValueError("ARC branch generation requires at least one candidate")
        branches: list[Branch] = []
        for i in range(branch_count):
            # Each branch is one sampled causal world.  Bayesian Beta posteriors
            # are sampled independently for every legal action, then each possible
            # first action is rolled through that same world for ``horizon`` hops.
            models: dict[str, dict[str, Any]] = {}
            for cid in candidate_ids:
                global_s, local_s = self.model.stats_for(obs, cid)
                trials = global_s.trials + 2 * local_s.trials
                progress = global_s.progress + 2 * local_s.progress
                changed = global_s.changed + 2 * local_s.changed
                failures = global_s.failures + 2 * local_s.failures
                wins = global_s.wins + 2 * local_s.wins
                p_progress = self._beta(rng, 1 + progress, 7 + max(0, trials - progress))
                p_change = self._beta(rng, 1 + changed, 2 + max(0, trials - changed))
                p_failure = self._beta(rng, 1 + failures, 12 + max(0, trials - failures))
                p_win = self._beta(rng, 0.5 + wins, 20 + max(0, trials - wins))
                empirical_mean = (
                    (global_s.total_utility + 2 * local_s.total_utility) / trials
                    if trials
                    else 0.0
                )
                novelty = self.config.novelty_bonus / math.sqrt(1.0 + trials)
                if snapshot.features["stall_count"].value >= self.config.soft_stall:
                    novelty *= 1.8
                phantom = self.model.phantom_risk(obs, cid)
                outcome_weights = {
                    "WIN": p_win,
                    "PROGRESS": p_progress * (1.0 - p_win),
                    "GAME_OVER": p_failure,
                    "CHANGE": p_change * (1.0 - p_progress) * (1.0 - p_failure),
                    "NO_CHANGE": max(0.01, 1.0 - p_change),
                }
                expected_outcome = sum(
                    weight * self._outcome_utility(outcome)
                    for outcome, weight in outcome_weights.items()
                ) / max(1e-12, sum(outcome_weights.values()))
                models[cid] = {
                    "weights": outcome_weights,
                    "bias": 0.35 * empirical_mean + novelty - self.config.action_cost - 4.0 * phantom,
                    "expected": expected_outcome,
                    "phantom": phantom,
                }

            action_values: dict[str, float] = {}
            predicted_outcomes: dict[str, str] = {}
            rollouts: dict[str, tuple[str, ...]] = {}
            for first_cid in candidate_ids:
                cid = first_cid
                total_value = 0.0
                discount = 1.0
                path: list[str] = []
                previous_outcome: str | None = None
                for depth in range(horizon):
                    model = models[cid]
                    outcome = self._sample_outcome(rng, model["weights"])
                    if depth == 0:
                        predicted_outcomes[first_cid] = outcome
                    path.append(f"{cid}>{outcome}")
                    repeat_penalty = 0.5 if depth > 0 and previous_outcome == "NO_CHANGE" and cid == first_cid else 0.0
                    total_value += discount * (model["bias"] + self._outcome_utility(outcome) - repeat_penalty)
                    if outcome in {"WIN", "GAME_OVER"}:
                        break
                    previous_outcome = outcome
                    discount *= self.config.rollout_discount
                    # In the abstract future state, choose the continuation action
                    # with the highest sampled expected utility.  If the prior hop
                    # was a no-op, prefer a different action on ties.
                    cid = max(
                        candidate_ids,
                        key=lambda next_cid: (
                            models[next_cid]["bias"] + models[next_cid]["expected"]
                            - (0.6 if previous_outcome == "NO_CHANGE" and next_cid == cid else 0.0),
                            -self.model.action_visits[next_cid],
                            next_cid,
                        ),
                    )
                action_values[first_cid] = total_value
                rollouts[first_cid] = tuple(path)
                self.model.causal_graph.record_simulated(
                    self.model.source_node(obs, first_cid),
                    predicted_outcomes[first_cid],
                    weight=self.config.simulation_evidence_scale / branch_count,
                )

            trajectory = tuple(
                BranchObservation(
                    step_offset=offset,
                    features={"world_hypothesis": i, "abstract_rollout_depth": offset},
                )
                for offset in range(1, horizon + 1)
            )
            branches.append(
                Branch(
                    branch_id=f"arc-{snapshot.step}-{i}",
                    probability=1.0,
                    trajectory=trajectory,
                    metadata={
                        "action_values": action_values,
                        "predicted_outcomes": predicted_outcomes,
                        "rollouts": rollouts,
                    },
                )
            )
        return branches


class ARCBranchEvaluator:
    def __init__(self) -> None:
        self._latest_prediction: dict[str, Any] = {}

    @staticmethod
    def _candidate_payloads(snapshot: WorldSnapshot) -> Mapping[str, Mapping[str, Any]]:
        return snapshot.features["action_candidate_payloads"].value

    def actions(self, snapshot: WorldSnapshot) -> list[ActionCandidate]:
        payloads = self._candidate_payloads(snapshot)
        return [ActionCandidate(action_id=cid, payload=dict(payload)) for cid, payload in payloads.items()]

    def evaluate(
        self,
        snapshot: WorldSnapshot,
        branches: Sequence[Branch],
        actions: Sequence[ActionCandidate],
    ) -> Mapping[str, Mapping[str, float]]:
        ids = {a.action_id for a in actions}
        out: dict[str, dict[str, float]] = {}
        for branch in branches:
            values = {str(k): float(v) for k, v in branch.metadata["action_values"].items()}
            missing = ids - set(values)
            if missing:
                raise ValueError(f"branch missing ARC action values: {sorted(missing)}")
            out[branch.branch_id] = {k: values[k] for k in ids}
        return out

    def observation_likelihoods(
        self,
        branches: Sequence[Branch],
        actual_observation: Mapping[str, Any] | None,
    ) -> Mapping[str, float] | None:
        # Evidence is incorporated into the Beta posteriors before branch
        # generation. Reusing it here would double-count the observation.
        return None

    def predict_next_observation(
        self,
        branches: Sequence[Branch],
        probabilities: Mapping[str, float],
    ) -> Mapping[str, Any]:
        if not branches:
            return {}
        # Aggregate branch-level modal outcome for the selected future model.
        outcome_mass: Counter[str] = Counter()
        for branch in branches:
            weight = float(probabilities.get(branch.branch_id, 0.0))
            for outcome in branch.metadata.get("predicted_outcomes", {}).values():
                outcome_mass[outcome] += weight
        pred = max(outcome_mass, key=outcome_mass.get) if outcome_mass else "UNKNOWN"
        self._latest_prediction = {"outcome_class": pred}
        return self._latest_prediction
