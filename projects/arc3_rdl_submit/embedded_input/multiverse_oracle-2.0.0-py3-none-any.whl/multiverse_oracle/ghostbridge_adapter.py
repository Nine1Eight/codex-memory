from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .causal import CausalEdge, CausalTransitionGraph


@dataclass(frozen=True, slots=True)
class GhostBridgeDiagnosis:
    missing_bridges: tuple[tuple[str, str], ...]
    phantom_bridges: tuple[tuple[str, str, float], ...]


class GhostBridgeOracleAdapter:
    """Adds phantom-bridge elimination to ordinary missing-bridge detection."""

    @staticmethod
    def diagnose(
        graph: CausalTransitionGraph,
        required_edges: Iterable[tuple[str, str]],
        *,
        missing_confidence_threshold: float = 0.5,
        phantom_threshold: float = 0.5,
    ) -> GhostBridgeDiagnosis:
        missing = tuple(graph.missing_edges(required_edges, missing_confidence_threshold))
        phantom: list[CausalEdge] = graph.phantom_edges(phantom_threshold)
        return GhostBridgeDiagnosis(
            missing_bridges=missing,
            phantom_bridges=tuple((e.source, e.target, e.phantom_score) for e in phantom),
        )
