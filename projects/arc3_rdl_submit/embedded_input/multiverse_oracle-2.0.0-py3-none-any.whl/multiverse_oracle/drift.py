from __future__ import annotations

import math
from collections.abc import Mapping
from typing import Any


def feature_distance(predicted: Any, actual: Any) -> float:
    if predicted is None and actual is None:
        return 0.0
    if isinstance(predicted, bool) or isinstance(actual, bool):
        return 0.0 if predicted == actual else 1.0
    if isinstance(predicted, (int, float)) and isinstance(actual, (int, float)):
        if not (math.isfinite(float(predicted)) and math.isfinite(float(actual))):
            return 1.0
        scale = max(1.0, abs(float(predicted)), abs(float(actual)))
        return min(1.0, abs(float(predicted) - float(actual)) / scale)
    return 0.0 if predicted == actual else 1.0


def reality_drift(predicted: Mapping[str, Any], actual: Mapping[str, Any]) -> float:
    keys = set(predicted) | set(actual)
    if not keys:
        return 0.0
    return sum(feature_distance(predicted.get(k), actual.get(k)) for k in keys) / len(keys)
