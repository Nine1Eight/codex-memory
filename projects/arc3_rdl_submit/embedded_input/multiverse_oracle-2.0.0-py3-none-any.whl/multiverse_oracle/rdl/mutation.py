from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from .scanner import SemanticSourceScanner
from .semantic_registry import DEFAULT_SEMANTIC_REGISTRY, SemanticRegistry
from .types import MutationFamily, RDLMode, SemanticMutation


class MutationRegistry:
    """Discovers controlled semantic interventions without blind source corruption."""

    def __init__(self, registry: SemanticRegistry | None = None) -> None:
        self.registry = registry or DEFAULT_SEMANTIC_REGISTRY

    def discover(
        self,
        *,
        mode: RDLMode,
        source_root: str | Path | None = None,
        supported_families: Iterable[MutationFamily] | None = None,
        max_mutations: int | None = None,
    ) -> tuple[SemanticMutation, ...]:
        if mode is not RDLMode.DEEP_PUBLIC:
            return ()
        supported = set(supported_families or MutationFamily)
        mutations: list[SemanticMutation] = []
        if source_root is not None:
            report = SemanticSourceScanner(mode=mode).scan_path(source_root)
            filtered = [finding for finding in report.findings if finding.mutation_family in supported]
            mutations.extend(self.registry.variants_for_findings(filtered))
        else:
            for family in MutationFamily:
                if family in supported:
                    mutations.extend(self.registry.variants_for_family(family))

        dedup: dict[str, SemanticMutation] = {}
        for mutation in mutations:
            dedup.setdefault(mutation.mutation_id, mutation)
        ordered = tuple(sorted(dedup.values(), key=lambda m: m.mutation_id))
        if max_mutations is not None:
            return ordered[: max(0, int(max_mutations))]
        return ordered

    def by_family(self, family: MutationFamily) -> tuple[SemanticMutation, ...]:
        return self.registry.variants_for_family(family)
