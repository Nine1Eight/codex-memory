from __future__ import annotations

from dataclasses import dataclass, field

from .types import RDLMode


@dataclass(frozen=True, slots=True)
class RDLWeights:
    state_topology: float = 0.25
    score_reward: float = 0.20
    terminal_state: float = 0.15
    legal_actions: float = 0.15
    object_topology: float = 0.10
    counters: float = 0.10
    events_rng: float = 0.05

    def __post_init__(self) -> None:
        values = (
            self.state_topology,
            self.score_reward,
            self.terminal_state,
            self.legal_actions,
            self.object_topology,
            self.counters,
            self.events_rng,
        )
        if any(v < 0.0 for v in values):
            raise ValueError("RDL weights must be non-negative")
        if abs(sum(values) - 1.0) > 1e-9:
            raise ValueError("RDL weights must sum to 1.0")


@dataclass(frozen=True, slots=True)
class CausalValidationConfig:
    seeds: tuple[int, ...] = (918, 919, 920, 921, 922)
    causal_threshold: float = 0.70
    reproducibility_threshold: float = 0.75
    minimum_effect_distance: float = 1e-9
    max_adjacent_states: int = 3
    max_alternate_actions: int = 3

    def __post_init__(self) -> None:
        if not self.seeds:
            raise ValueError("at least one causal-validation seed is required")
        if len(set(self.seeds)) != len(self.seeds):
            raise ValueError("causal-validation seeds must be unique")
        for name, value in (
            ("causal_threshold", self.causal_threshold),
            ("reproducibility_threshold", self.reproducibility_threshold),
        ):
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be in [0,1]")
        if self.minimum_effect_distance < 0.0:
            raise ValueError("minimum_effect_distance cannot be negative")


@dataclass(frozen=True, slots=True)
class RDLConfig:
    mode: RDLMode = RDLMode.DEEP_PUBLIC
    weights: RDLWeights = field(default_factory=RDLWeights)
    causal: CausalValidationConfig = field(default_factory=CausalValidationConfig)
    acceptance_threshold: float = 0.50
    max_mutations: int = 64
    max_actions_per_mutation: int = 16
    reachability_max_depth: int = 8
    reachability_max_nodes: int = 2048
    execution_cost_reference_ns: int = 10_000_000
    require_same_precondition_hash: bool = True
    fail_on_variant_exception: bool = False
    allow_public_source_analysis: bool = False

    def __post_init__(self) -> None:
        if not 0.0 <= self.acceptance_threshold <= 1.0:
            raise ValueError("acceptance_threshold must be in [0,1]")
        if self.max_mutations < 1:
            raise ValueError("max_mutations must be >= 1")
        if self.max_actions_per_mutation < 1:
            raise ValueError("max_actions_per_mutation must be >= 1")
        if self.reachability_max_depth < 0:
            raise ValueError("reachability_max_depth cannot be negative")
        if self.reachability_max_nodes < 1:
            raise ValueError("reachability_max_nodes must be >= 1")
        if self.execution_cost_reference_ns <= 0:
            raise ValueError("execution_cost_reference_ns must be > 0")
