from __future__ import annotations

from statistics import fmean
from typing import Any, Iterable, Sequence

from .config import CausalValidationConfig
from .delta import RDLDeltaExtractor
from .executor import PairedDifferentialExecutor
from .types import CausalValidationResult, RDLSnapshot, SemanticMutation


class RDLCausalValidator:
    """Intervention validator using ON/OFF controls across seeds, states, and actions."""

    def __init__(
        self,
        executor: PairedDifferentialExecutor,
        delta_extractor: RDLDeltaExtractor,
        config: CausalValidationConfig | None = None,
    ) -> None:
        self.executor = executor
        self.delta_extractor = delta_extractor
        self.config = config or CausalValidationConfig()

    def validate(
        self,
        *,
        environment: Any,
        mutation: SemanticMutation,
        action: Any,
        initial_snapshot: RDLSnapshot | None = None,
        adjacent_environments: Sequence[Any] = (),
        alternate_actions: Sequence[Any] = (),
    ) -> CausalValidationResult:
        cfg = self.config
        intervention_flags: list[bool] = []
        control_flags: list[bool] = []
        reversal_flags: list[bool] = []
        distances: list[float] = []
        evidence_count = 0

        # Primary same-state/same-action trials establish causality. Alternate
        # states/actions are specificity/generality probes and must not dilute a
        # genuinely action-specific mechanic.
        for seed in cfg.seeds:
            paired = self.executor.run(
                environment,
                action=action,
                mutation=mutation,
                seed=seed,
                initial_snapshot=initial_snapshot,
            )
            delta = self.delta_extractor.compare(paired.baseline, paired.variant)
            intervention_flags.append(delta.semantic_distance > cfg.minimum_effect_distance)
            distances.append(delta.semantic_distance)
            evidence_count += 1

            control_left, control_right = self.executor.control_pair(
                environment,
                action=action,
                seed=seed,
                initial_snapshot=initial_snapshot,
            )
            control_delta = self.delta_extractor.compare(control_left, control_right)
            control_flags.append(control_delta.semantic_distance > cfg.minimum_effect_distance)
            evidence_count += 1

            reverse_left, reverse_right = self.executor.control_pair(
                environment,
                action=action,
                seed=seed,
                initial_snapshot=initial_snapshot,
            )
            reverse_delta = self.delta_extractor.compare(reverse_left, reverse_right)
            reversal_flags.append(reverse_delta.semantic_distance <= cfg.minimum_effect_distance)
            evidence_count += 1

        # Specificity/generality probes are recorded as extra evidence. They do
        # not determine primary reproducibility because many valid mechanics are
        # intentionally conditional on one action or state boundary.
        ancillary_cases: list[tuple[Any, Any, RDLSnapshot | None]] = []
        for adjacent in adjacent_environments[: cfg.max_adjacent_states]:
            try:
                snap = self.executor.adapter.snapshot(adjacent)
            except Exception:
                snap = None
            ancillary_cases.append((adjacent, action, snap))
        for alt_action in alternate_actions[: cfg.max_alternate_actions]:
            ancillary_cases.append((environment, alt_action, initial_snapshot))
        for case_environment, case_action, case_snapshot in ancillary_cases:
            seed = cfg.seeds[0]
            paired = self.executor.run(
                case_environment,
                action=case_action,
                mutation=mutation,
                seed=seed,
                initial_snapshot=case_snapshot,
            )
            distances.append(self.delta_extractor.compare(paired.baseline, paired.variant).semantic_distance)
            evidence_count += 1

        intervention_rate = fmean(intervention_flags) if intervention_flags else 0.0
        baseline_rate = fmean(control_flags) if control_flags else 0.0
        reversibility = fmean(reversal_flags) if reversal_flags else 0.0
        reproducibility = intervention_rate * (1.0 - baseline_rate)
        causal_confidence = max(0.0, min(1.0, reproducibility * reversibility))
        causal = causal_confidence >= cfg.causal_threshold and reproducibility >= cfg.reproducibility_threshold
        if not intervention_flags:
            reason = "no intervention evidence"
        elif baseline_rate > 0.0:
            reason = "control instability detected"
        elif not causal:
            reason = "effect did not meet causal/reproducibility thresholds"
        else:
            reason = "intervention effect reproduced and disappeared when mutation was removed"
        return CausalValidationResult(
            causal=causal,
            causal_confidence=causal_confidence,
            reproducibility=reproducibility,
            intervention_effect_rate=intervention_rate,
            baseline_effect_rate=baseline_rate,
            reversibility=reversibility,
            seed_count=len(cfg.seeds),
            adjacent_state_count=min(len(adjacent_environments), cfg.max_adjacent_states),
            alternate_action_count=min(len(alternate_actions), cfg.max_alternate_actions),
            mean_semantic_distance=fmean(distances) if distances else 0.0,
            evidence_count=evidence_count,
            reason=reason,
        )
