from __future__ import annotations

import math
from typing import Any, Iterable

from .config import RDLWeights
from .types import RDLDelta, RDLTransition


def _grid_distance(a: tuple[tuple[int, ...], ...], b: tuple[tuple[int, ...], ...]) -> float:
    if not a and not b:
        return 0.0
    if len(a) != len(b):
        return 1.0
    if a and b and any(len(ra) != len(rb) for ra, rb in zip(a, b)):
        return 1.0
    total = sum(len(row) for row in a)
    if total == 0:
        return 0.0
    changed = sum(1 for ra, rb in zip(a, b) for va, vb in zip(ra, rb) if va != vb)
    return min(1.0, changed / total)


def _set_distance(a: Iterable[Any], b: Iterable[Any]) -> float:
    sa = {repr(v) for v in a}
    sb = {repr(v) for v in b}
    union = sa | sb
    if not union:
        return 0.0
    return 1.0 - len(sa & sb) / len(union)


def _counter_distance(a: tuple[tuple[str, float], ...], b: tuple[tuple[str, float], ...]) -> float:
    da = dict(a)
    db = dict(b)
    keys = set(da) | set(db)
    if not keys:
        return 0.0
    distances: list[float] = []
    for key in keys:
        av = da.get(key, 0.0)
        bv = db.get(key, 0.0)
        scale = max(1.0, abs(av), abs(bv))
        distances.append(min(1.0, abs(av - bv) / scale))
    return sum(distances) / len(distances)


def _reward_distance(score_delta: float, level_delta: int) -> float:
    score_component = 1.0 - math.exp(-abs(float(score_delta)))
    level_component = 1.0 - math.exp(-abs(int(level_delta)))
    return min(1.0, 0.7 * score_component + 0.3 * level_component)


class RDLDeltaExtractor:
    def __init__(self, weights: RDLWeights | None = None) -> None:
        self.weights = weights or RDLWeights()

    def compare(self, baseline: RDLTransition, variant: RDLTransition) -> RDLDelta:
        b = baseline.after
        v = variant.after
        score_delta = v.score - b.score
        level_delta = v.level - b.level
        state_distance = _grid_distance(b.grid, v.grid)
        position_changed = b.player_position != v.player_position
        if position_changed:
            state_distance = min(1.0, max(state_distance, 0.25))
        action_distance = _set_distance(b.legal_actions, v.legal_actions)
        object_distance = _set_distance(b.objects, v.objects)
        counter_distance = _counter_distance(b.counters, v.counters)
        event_distance = _set_distance(b.events, v.events)
        rng_changed = b.rng_hash != v.rng_hash
        event_rng_distance = min(1.0, 0.75 * event_distance + 0.25 * float(rng_changed))
        terminal_distance = float(b.terminal != v.terminal)
        reward_distance = _reward_distance(score_delta, level_delta)
        exception_changed = baseline.exception != variant.exception
        if exception_changed:
            event_rng_distance = min(1.0, max(event_rng_distance, 0.5))

        w = self.weights
        semantic_distance = (
            w.state_topology * state_distance
            + w.score_reward * reward_distance
            + w.terminal_state * terminal_distance
            + w.legal_actions * action_distance
            + w.object_topology * object_distance
            + w.counters * counter_distance
            + w.events_rng * event_rng_distance
        )
        return RDLDelta(
            baseline_hash=b.state_hash,
            variant_hash=v.state_hash,
            state_changed=b.state_hash != v.state_hash or state_distance > 0.0,
            score_delta=score_delta,
            terminal_changed=bool(terminal_distance),
            legal_actions_changed=action_distance > 0.0,
            position_changed=position_changed,
            object_changed=object_distance > 0.0,
            counters_changed=counter_distance > 0.0,
            events_changed=event_distance > 0.0,
            rng_changed=rng_changed,
            semantic_distance=min(1.0, max(0.0, semantic_distance)),
            state_distance=state_distance,
            reward_distance=reward_distance,
            action_distance=action_distance,
            terminal_distance=terminal_distance,
            object_distance=object_distance,
            counter_distance=counter_distance,
            event_rng_distance=event_rng_distance,
            level_delta=level_delta,
            exception_changed=exception_changed,
        )
