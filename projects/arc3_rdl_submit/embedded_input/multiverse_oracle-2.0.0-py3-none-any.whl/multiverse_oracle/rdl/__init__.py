from .types import (
    CausalValidationResult,
    EncodedMechanic,
    MechanicProbe,
    MutationFamily,
    PairedExecution,
    RDLClassification,
    RDLDelta,
    RDLFindingScore,
    RDLMechanic,
    RDLMode,
    RDLRunReport,
    RDLSnapshot,
    RDLTransition,
    ReachabilityResult,
    RuntimeADLResult,
    RuntimeBridge,
    RuntimeDifferenceEvidence,
    ScannerReport,
    SemanticMutation,
    SourceFinding,
)
from .config import CausalValidationConfig, RDLConfig, RDLWeights
from .snapshot import SnapshotBuilder, stable_hash
from .scanner import SemanticSourceScanner
from .semantic_registry import DEFAULT_SEMANTIC_REGISTRY, SemanticFamilySpec, SemanticRegistry
from .mutation import MutationRegistry
from .executor import (
    PairedDifferentialExecutor,
    PreconditionMismatchError,
    RDLEnvironmentAdapter,
    RDLExecutionError,
    UnsupportedMutationError,
)
from .delta import RDLDeltaExtractor
from .causal import RDLCausalValidator
from .reachability import RDLReachabilityAnalyzer
from .scorer import RDLFindingScorer
from .generalizer import RDLMechanicGeneralizer
from .mechanic import MechanicBelief, MechanicCompiler
from .knowledge_base import RDLKnowledgeBase

__all__ = [
    "CausalValidationResult",
    "EncodedMechanic",
    "MechanicProbe",
    "MutationFamily",
    "PairedExecution",
    "RDLClassification",
    "RDLDelta",
    "RDLFindingScore",
    "RDLMechanic",
    "RDLMode",
    "RDLRunReport",
    "RDLSnapshot",
    "RDLTransition",
    "ReachabilityResult",
    "RuntimeADLResult",
    "RuntimeBridge",
    "RuntimeDifferenceEvidence",
    "ScannerReport",
    "SemanticMutation",
    "SourceFinding",
    "CausalValidationConfig",
    "RDLConfig",
    "RDLWeights",
    "SnapshotBuilder",
    "stable_hash",
    "SemanticSourceScanner",
    "DEFAULT_SEMANTIC_REGISTRY",
    "SemanticFamilySpec",
    "SemanticRegistry",
    "MutationRegistry",
    "PairedDifferentialExecutor",
    "PreconditionMismatchError",
    "RDLEnvironmentAdapter",
    "RDLExecutionError",
    "UnsupportedMutationError",
    "RDLDeltaExtractor",
    "RDLCausalValidator",
    "RDLReachabilityAnalyzer",
    "RDLFindingScorer",
    "RDLMechanicGeneralizer",
    "MechanicBelief",
    "MechanicCompiler",
    "RDLKnowledgeBase",
]


def __getattr__(name: str):
    if name == "RDLOrchestrator":
        from .orchestrator import RDLOrchestrator
        return RDLOrchestrator
    raise AttributeError(name)

__all__.append("RDLOrchestrator")
