from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Iterable, Mapping, Sequence

from .types import RDLSnapshot


def _json_default(value: Any) -> Any:
    if hasattr(value, "name"):
        return str(value.name)
    if hasattr(value, "value"):
        raw = value.value
        if isinstance(raw, (str, int, float, bool)) or raw is None:
            return raw
    if isinstance(value, bytes):
        return {"__bytes__": value.hex()}
    if isinstance(value, set):
        return sorted(value, key=repr)
    if hasattr(value, "tolist"):
        return value.tolist()
    return repr(value)


def stable_hash(value: Any) -> str:
    payload = json.dumps(
        value,
        default=_json_default,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def normalize_grid(grid: Any) -> tuple[tuple[int, ...], ...]:
    if grid is None:
        return ()
    if hasattr(grid, "tolist"):
        grid = grid.tolist()
    rows: list[tuple[int, ...]] = []
    for row in grid:
        rows.append(tuple(int(v) for v in row))
    if rows:
        width = len(rows[0])
        if any(len(row) != width for row in rows):
            raise ValueError("grid must be rectangular")
    return tuple(rows)


def freeze_objects(objects: Iterable[Sequence[Any]] | None) -> tuple[tuple[Any, ...], ...]:
    if objects is None:
        return ()
    frozen = [tuple(item) for item in objects]
    return tuple(sorted(frozen, key=repr))


def freeze_counters(counters: Mapping[str, Any] | Iterable[tuple[str, Any]] | None) -> tuple[tuple[str, float], ...]:
    if counters is None:
        return ()
    items = counters.items() if isinstance(counters, Mapping) else counters
    result: list[tuple[str, float]] = []
    for key, value in items:
        number = float(value)
        if not math.isfinite(number):
            raise ValueError(f"counter {key!r} must be finite")
        result.append((str(key), number))
    return tuple(sorted(result))


def freeze_metadata(metadata: Mapping[str, Any] | Iterable[tuple[str, Any]] | None) -> tuple[tuple[str, str], ...]:
    if metadata is None:
        return ()
    items = metadata.items() if isinstance(metadata, Mapping) else metadata
    return tuple(sorted((str(k), str(v)) for k, v in items))


class SnapshotBuilder:
    @staticmethod
    def build(
        *,
        grid: Any,
        score: float = 0.0,
        level: int = 0,
        terminal: bool = False,
        legal_actions: Iterable[Any] = (),
        player_position: tuple[int, int] | None = None,
        objects: Iterable[Sequence[Any]] | None = None,
        counters: Mapping[str, Any] | Iterable[tuple[str, Any]] | None = None,
        events: Iterable[str] = (),
        rng_state: Any = None,
        metadata: Mapping[str, Any] | Iterable[tuple[str, Any]] | None = None,
        state_extra: Any = None,
    ) -> RDLSnapshot:
        normalized_grid = normalize_grid(grid)
        score_value = float(score)
        if not math.isfinite(score_value):
            raise ValueError("snapshot score must be finite")
        level_value = int(level)
        if level_value < 0:
            raise ValueError("snapshot level cannot be negative")
        position = None if player_position is None else (int(player_position[0]), int(player_position[1]))
        frozen_objects = freeze_objects(objects)
        frozen_counters = freeze_counters(counters)
        frozen_events = tuple(str(event) for event in events)
        frozen_metadata = freeze_metadata(metadata)
        rng_hash = None if rng_state is None else stable_hash(rng_state)
        state_payload = {
            "grid": normalized_grid,
            "score": score_value,
            "level": level_value,
            "terminal": bool(terminal),
            "legal_actions": tuple(repr(a) for a in legal_actions),
            "player_position": position,
            "objects": frozen_objects,
            "counters": frozen_counters,
            "events": frozen_events,
            "rng_hash": rng_hash,
            "metadata": frozen_metadata,
            "state_extra": state_extra,
        }
        state_hash = stable_hash(state_payload)
        return RDLSnapshot(
            state_hash=state_hash,
            grid=normalized_grid,
            score=score_value,
            level=level_value,
            terminal=bool(terminal),
            legal_actions=tuple(legal_actions),
            player_position=position,
            objects=frozen_objects,
            counters=frozen_counters,
            events=frozen_events,
            rng_hash=rng_hash,
            metadata=frozen_metadata,
        )

    @staticmethod
    def from_mapping(data: Mapping[str, Any]) -> RDLSnapshot:
        return SnapshotBuilder.build(
            grid=data.get("grid", ()),
            score=data.get("score", 0.0),
            level=data.get("level", 0),
            terminal=data.get("terminal", False),
            legal_actions=data.get("legal_actions", ()),
            player_position=data.get("player_position"),
            objects=data.get("objects"),
            counters=data.get("counters"),
            events=data.get("events", ()),
            rng_state=data.get("rng_state"),
            metadata=data.get("metadata"),
            state_extra=data.get("state_extra"),
        )
