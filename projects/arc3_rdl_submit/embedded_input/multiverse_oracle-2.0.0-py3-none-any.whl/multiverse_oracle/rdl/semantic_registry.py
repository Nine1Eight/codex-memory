from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

from .types import MutationFamily, SemanticMutation, SourceFinding


@dataclass(frozen=True, slots=True)
class SemanticFamilySpec:
    family: MutationFamily
    name: str
    description: str
    variants: tuple[tuple[str, tuple[tuple[str, Any], ...]], ...]


_SPECS: tuple[SemanticFamilySpec, ...] = (
    SemanticFamilySpec(MutationFamily.DIVISION, "Division", "Division mode changes quotient semantics at integral boundaries.", (
        ("floor", (("mode", "floor"),)), ("truncate", (("mode", "truncate"),)), ("true", (("mode", "true"),)),
    )),
    SemanticFamilySpec(MutationFamily.ROUNDING, "Rounding", "Rounding policy changes threshold and coordinate discretization.", (
        ("floor", (("mode", "floor"),)), ("ceil", (("mode", "ceil"),)), ("bankers", (("mode", "round"),)), ("truncate", (("mode", "truncate"),)),
    )),
    SemanticFamilySpec(MutationFamily.NEGATIVE_INDEXING, "Negative indexing", "Negative or out-of-bounds coordinates may wrap, clamp, reject, or raise.", (
        ("wrap", (("mode", "wrap"),)), ("clamp", (("mode", "clamp"),)), ("bounds", (("mode", "bounds"),)),
    )),
    SemanticFamilySpec(MutationFamily.SLICE_BOUNDARIES, "Slice boundaries", "Inclusive/exclusive endpoints and overflow clipping can alter selected topology.", (
        ("exclusive", (("end", "exclusive"),)), ("inclusive", (("end", "inclusive"),)), ("clip", (("overflow", "clip"),)),
    )),
    SemanticFamilySpec(MutationFamily.ITERATOR_SEMANTICS, "Iterator semantics", "Lazy, materialized, and reusable iteration change mutation visibility and consumption.", (
        ("lazy", (("mode", "lazy"),)), ("materialized", (("mode", "materialized"),)), ("reusable", (("mode", "reusable"),)),
    )),
    SemanticFamilySpec(MutationFamily.ORDERING, "Ordering", "Insertion, sorted, or intentionally order-independent traversal can change update order.", (
        ("insertion", (("mode", "insertion"),)), ("sorted", (("mode", "sorted"),)), ("reverse", (("mode", "reverse"),)),
    )),
    SemanticFamilySpec(MutationFamily.COPY_SEMANTICS, "Copy semantics", "Aliasing, shallow copies, and deep copies alter state mutation propagation.", (
        ("reference", (("mode", "reference"),)), ("shallow", (("mode", "shallow"),)), ("deep", (("mode", "deep"),)),
    )),
    SemanticFamilySpec(MutationFamily.NUMERIC_DTYPE, "Numeric dtype", "Signedness and integer width change representable state and comparisons.", (
        ("int8", (("dtype", "int8"),)), ("uint8", (("dtype", "uint8"),)), ("int32", (("dtype", "int32"),)), ("int64", (("dtype", "int64"),)),
    )),
    SemanticFamilySpec(MutationFamily.OVERFLOW, "Overflow", "Overflow may wrap, saturate, or fail.", (
        ("wrap", (("mode", "wrap"),)), ("saturate", (("mode", "saturate"),)), ("error", (("mode", "error"),)),
    )),
    SemanticFamilySpec(MutationFamily.BOOL_INT_COERCION, "Bool/int coercion", "Boolean, integer, enum, and flag coercion can change branch conditions.", (
        ("strict_bool", (("mode", "strict_bool"),)), ("int_coerce", (("mode", "int_coerce"),)), ("enum_value", (("mode", "enum_value"),)),
    )),
    SemanticFamilySpec(MutationFamily.STRING_BYTES, "String/bytes", "Encoding, decoding, and comparison modes can change identifiers and serialized state.", (
        ("utf8_text", (("mode", "utf8_text"),)), ("raw_bytes", (("mode", "raw_bytes"),)), ("strict_decode", (("mode", "strict_decode"),)),
    )),
    SemanticFamilySpec(MutationFamily.RNG, "RNG", "Seed, call order, and state consumption change stochastic transition paths.", (
        ("same_seed", (("mode", "same_seed"),)), ("consume_one", (("mode", "consume_one"),)), ("alternate_stream", (("mode", "alternate_stream"),)),
    )),
    SemanticFamilySpec(MutationFamily.SERIALIZATION, "Serialization", "Restore defaults, missing fields, and representation conversion alter reconstructed state.", (
        ("strict", (("mode", "strict"),)), ("defaults", (("mode", "defaults"),)), ("drop_missing", (("mode", "drop_missing"),)),
    )),
    SemanticFamilySpec(MutationFamily.MUTATION_TIMING, "Mutation timing", "Before/after iteration and staged updates change causal ordering.", (
        ("before", (("mode", "before"),)), ("after", (("mode", "after"),)), ("staged", (("mode", "staged"),)),
    )),
    SemanticFamilySpec(MutationFamily.EXCEPTIONS_DEFAULTS, "Exceptions/defaults", "Failure, default, and continue policies alter fallback transitions.", (
        ("raise", (("mode", "raise"),)), ("default", (("mode", "default"),)), ("continue", (("mode", "continue"),)),
    )),
    SemanticFamilySpec(MutationFamily.LIBRARY_BEHAVIOR, "Library behavior", "Framework/API implementation choices can alter observable behavior.", (
        ("baseline", (("mode", "baseline"),)), ("compat", (("mode", "compat"),)), ("strict", (("mode", "strict"),)),
    )),
)


class SemanticRegistry:
    def __init__(self, specs: Iterable[SemanticFamilySpec] = _SPECS) -> None:
        self._specs = {spec.family: spec for spec in specs}
        missing = set(MutationFamily) - set(self._specs)
        if missing:
            raise ValueError(f"semantic registry missing families: {sorted(f.value for f in missing)}")

    def spec(self, family: MutationFamily) -> SemanticFamilySpec:
        return self._specs[family]

    def all_specs(self) -> tuple[SemanticFamilySpec, ...]:
        return tuple(self._specs[family] for family in MutationFamily)

    def variants_for_family(
        self,
        family: MutationFamily,
        *,
        source_finding: SourceFinding | None = None,
    ) -> tuple[SemanticMutation, ...]:
        spec = self.spec(family)
        result: list[SemanticMutation] = []
        for variant_name, parameters in spec.variants:
            finding_suffix = ""
            if source_finding is not None:
                finding_suffix = f"@{source_finding.file_path}:{source_finding.line}:{source_finding.column}"
            result.append(
                SemanticMutation(
                    mutation_id=f"{family.value}:{variant_name}{finding_suffix}",
                    family=family,
                    variant_name=variant_name,
                    parameters=parameters,
                    source_finding=source_finding,
                )
            )
        return tuple(result)

    def variants_for_findings(self, findings: Iterable[SourceFinding]) -> tuple[SemanticMutation, ...]:
        mutations: list[SemanticMutation] = []
        seen: set[tuple[MutationFamily, str, int, int]] = set()
        for finding in findings:
            key = (finding.mutation_family, finding.file_path, finding.line, finding.column)
            if key in seen:
                continue
            seen.add(key)
            mutations.extend(self.variants_for_family(finding.mutation_family, source_finding=finding))
        return tuple(mutations)


DEFAULT_SEMANTIC_REGISTRY = SemanticRegistry()
