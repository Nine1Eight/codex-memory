from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Sequence


class RDLMode(str, Enum):
    """Execution policy for Runtime Difference Learning."""

    DEEP_PUBLIC = "deep_public"
    COMPILED = "compiled"
    OBSERVATIONAL = "observational"


class MutationFamily(str, Enum):
    DIVISION = "RDL-01"
    ROUNDING = "RDL-02"
    NEGATIVE_INDEXING = "RDL-03"
    SLICE_BOUNDARIES = "RDL-04"
    ITERATOR_SEMANTICS = "RDL-05"
    ORDERING = "RDL-06"
    COPY_SEMANTICS = "RDL-07"
    NUMERIC_DTYPE = "RDL-08"
    OVERFLOW = "RDL-09"
    BOOL_INT_COERCION = "RDL-10"
    STRING_BYTES = "RDL-11"
    RNG = "RDL-12"
    SERIALIZATION = "RDL-13"
    MUTATION_TIMING = "RDL-14"
    EXCEPTIONS_DEFAULTS = "RDL-15"
    LIBRARY_BEHAVIOR = "RDL-16"


class RDLClassification(str, Enum):
    NO_EFFECT = "RDL_NO_EFFECT"
    VISUAL_ONLY = "RDL_VISUAL_ONLY"
    STATE_EFFECT = "RDL_STATE_EFFECT"
    ACTION_EFFECT = "RDL_ACTION_EFFECT"
    REWARD_EFFECT = "RDL_REWARD_EFFECT"
    TERMINAL_EFFECT = "RDL_TERMINAL_EFFECT"
    PATH_EFFECT = "RDL_PATH_EFFECT"
    CAUSAL_MECHANIC = "RDL_CAUSAL_MECHANIC"
    TRANSFERABLE_MECHANIC = "RDL_TRANSFERABLE_MECHANIC"
    REJECTED = "RDL_REJECTED"


@dataclass(frozen=True, slots=True)
class RDLSnapshot:
    state_hash: str
    grid: tuple[tuple[int, ...], ...]
    score: float
    level: int
    terminal: bool
    legal_actions: tuple[Any, ...]
    player_position: tuple[int, int] | None = None
    objects: tuple[tuple[Any, ...], ...] = ()
    counters: tuple[tuple[str, float], ...] = ()
    events: tuple[str, ...] = ()
    rng_hash: str | None = None
    metadata: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class RDLTransition:
    before: RDLSnapshot
    action: Any
    after: RDLSnapshot
    runtime_profile: str
    mutation_id: str | None
    elapsed_ns: int
    exception: str | None = None


@dataclass(frozen=True, slots=True)
class RDLDelta:
    baseline_hash: str
    variant_hash: str
    state_changed: bool
    score_delta: float
    terminal_changed: bool
    legal_actions_changed: bool
    position_changed: bool
    object_changed: bool
    counters_changed: bool
    events_changed: bool
    rng_changed: bool
    semantic_distance: float
    state_distance: float = 0.0
    reward_distance: float = 0.0
    action_distance: float = 0.0
    terminal_distance: float = 0.0
    object_distance: float = 0.0
    counter_distance: float = 0.0
    event_rng_distance: float = 0.0
    level_delta: int = 0
    exception_changed: bool = False


@dataclass(frozen=True, slots=True)
class SourceFinding:
    mutation_family: MutationFamily
    file_path: str
    line: int
    column: int
    evidence: str
    symbol: str = ""


@dataclass(frozen=True, slots=True)
class ScannerReport:
    findings: tuple[SourceFinding, ...]
    files_scanned: int
    parse_errors: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class SemanticMutation:
    mutation_id: str
    family: MutationFamily
    variant_name: str
    parameters: tuple[tuple[str, Any], ...] = ()
    source_finding: SourceFinding | None = None

    @property
    def parameter_map(self) -> dict[str, Any]:
        return dict(self.parameters)


@dataclass(frozen=True, slots=True)
class PairedExecution:
    baseline: RDLTransition
    variant: RDLTransition
    seed: int
    mutation: SemanticMutation


@dataclass(frozen=True, slots=True)
class CausalValidationResult:
    causal: bool
    causal_confidence: float
    reproducibility: float
    intervention_effect_rate: float
    baseline_effect_rate: float
    reversibility: float
    seed_count: int
    adjacent_state_count: int
    alternate_action_count: int
    mean_semantic_distance: float
    evidence_count: int
    reason: str


@dataclass(frozen=True, slots=True)
class ReachabilityResult:
    reachable: bool
    path: tuple[Any, ...]
    visited_states: int
    depth: int | None
    target_hash: str | None
    reason: str


@dataclass(frozen=True, slots=True)
class RuntimeADLResult:
    winning: bool
    outcome_effect: float
    causal_confidence: float
    strategic_value: float
    reason: str
    metrics: tuple[tuple[str, float], ...] = ()


@dataclass(frozen=True, slots=True)
class RuntimeDifferenceEvidence:
    mutation_id: str
    mutation_family: str
    baseline: RDLTransition
    variant: RDLTransition
    delta: RDLDelta
    causal_confidence: float
    reproducibility: float
    reachable: bool
    minimum_reach_cost: int | None
    outcome_effect: float
    information_gain: float
    generalized_hypothesis: str
    provenance_hash: str


@dataclass(frozen=True, slots=True)
class RuntimeBridge:
    bridge_id: str
    source_state_hash: str
    target_condition: str
    missing_capability: str
    forward_path: tuple[Any, ...]
    reverse_path: tuple[Any, ...]
    synthesized_probe: tuple[Any, ...]
    confidence: float
    evidence_hashes: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class RDLMechanic:
    mechanic_id: str
    mutation_family: str
    description: str
    invariant: str
    required_observations: tuple[str, ...]
    preconditions: tuple[str, ...]
    predicted_effects: tuple[str, ...]
    test_actions: tuple[Any, ...]
    causal_confidence: float
    reproducibility: float
    reachability: float
    generality: float
    utility: float
    source_games: tuple[str, ...]
    glyph_id: int | None = None
    provenance_hashes: tuple[str, ...] = ()
    invalidated: bool = False

    def score(self, *, impact: float = 1.0, cost: float = 0.0) -> float:
        values = (
            max(0.0, min(1.0, impact)),
            max(0.0, min(1.0, self.causal_confidence)),
            max(0.0, min(1.0, self.reproducibility)),
            max(0.0, min(1.0, self.reachability)),
            max(0.0, min(1.0, self.generality)),
            max(0.0, min(1.0, self.utility)),
            1.0 - max(0.0, min(1.0, cost)),
        )
        result = 1.0
        for value in values:
            result *= value
        return result


@dataclass(frozen=True, slots=True)
class RDLFindingScore:
    score: float
    impact: float
    causality: float
    reproducibility: float
    reachability: float
    generality: float
    utility: float
    cost: float
    classification: RDLClassification


@dataclass(frozen=True, slots=True)
class EncodedMechanic:
    glyph_id: int
    token: str
    mechanic_id: str
    signature: str
    parameters: tuple[tuple[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class MechanicProbe:
    mechanic_id: str
    glyph_id: int
    action: Any
    expected_observations: tuple[str, ...]
    probe_value: float
    information_gain: float
    failure_risk: float
    reason: str


@dataclass(frozen=True, slots=True)
class RDLRunReport:
    environment_id: str
    mode: RDLMode
    mutations_considered: int
    experiments_run: int
    causal_findings: int
    accepted_mechanics: tuple[RDLMechanic, ...]
    rejected_reasons: tuple[str, ...]
    elapsed_ns: int
