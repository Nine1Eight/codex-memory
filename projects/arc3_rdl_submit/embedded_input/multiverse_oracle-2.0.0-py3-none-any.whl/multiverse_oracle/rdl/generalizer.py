from __future__ import annotations

from dataclasses import replace
from typing import Iterable

from .snapshot import stable_hash
from .types import (
    CausalValidationResult,
    MutationFamily,
    RDLDelta,
    RDLMechanic,
    ReachabilityResult,
    RuntimeADLResult,
    RuntimeBridge,
    SemanticMutation,
)


_TEMPLATES: dict[MutationFamily, tuple[str, str, tuple[str, ...], tuple[str, ...]]] = {
    MutationFamily.DIVISION: (
        "Discrete quotient semantics can move threshold or coordinate boundaries.",
        "A calculation-derived transition may change when a ratio crosses an integer boundary.",
        ("ratio-sensitive state", "discrete threshold"),
        ("threshold crossing", "coordinate/quantity change"),
    ),
    MutationFamily.ROUNDING: (
        "A discretization threshold can choose a neighboring state or cell.",
        "Near-half or boundary values may map to different discrete outcomes.",
        ("continuous/intermediate quantity", "discrete target"),
        ("neighboring-cell selection", "threshold-dependent outcome"),
    ),
    MutationFamily.NEGATIVE_INDEXING: (
        "An out-of-bound directional transition may connect to, clamp at, or reject the opposite boundary.",
        "Boundary topology is not assumed Euclidean until an edge interaction is observed.",
        ("agent/object adjacent to boundary", "outward action legal or testable"),
        ("opposite-edge arrival", "clamped position", "rejected move"),
    ),
    MutationFamily.SLICE_BOUNDARIES: (
        "A region-selection boundary may include or exclude its terminal cell.",
        "Effects at a region edge can reveal inclusive/exclusive topology.",
        ("effect spans a bounded region",),
        ("edge-cell inclusion change", "region-size change"),
    ),
    MutationFamily.ITERATOR_SEMANTICS: (
        "State updates can depend on whether entities are consumed once or materialized before mutation.",
        "Repeated traversal may or may not observe the same entity set.",
        ("multi-entity update", "repeated traversal"),
        ("entity-count divergence", "second-pass divergence"),
    ),
    MutationFamily.ORDERING: (
        "Entity processing order can change collision, priority, or update outcomes.",
        "When updates interact, ordering may be a latent mechanic.",
        ("multiple interacting entities",),
        ("order-sensitive collision", "priority-dependent state"),
    ),
    MutationFamily.COPY_SEMANTICS: (
        "Two apparent state objects may share mutable identity or evolve independently.",
        "Mutation can propagate across linked representations when aliasing exists.",
        ("duplicated/linked state representation",),
        ("coupled mutation", "independent mutation"),
    ),
    MutationFamily.NUMERIC_DTYPE: (
        "Numeric representation can change sign, precision, or range-sensitive transitions.",
        "Large or signed values near representation limits may alter mechanics.",
        ("numeric counter/value near representational boundary",),
        ("sign change", "range-dependent transition"),
    ),
    MutationFamily.OVERFLOW: (
        "A bounded counter may wrap, saturate, or reject overflow.",
        "Crossing a numeric limit can produce a discontinuous state transition.",
        ("counter/value near maximum or minimum",),
        ("wraparound", "saturation", "error/fallback"),
    ),
    MutationFamily.BOOL_INT_COERCION: (
        "Flags, enums, and numeric values may share or reject equivalent truth states.",
        "A branch can depend on strict type/state identity rather than visual equivalence.",
        ("flag/enum-like state",),
        ("branch divergence", "legal-action divergence"),
    ),
    MutationFamily.STRING_BYTES: (
        "Identifier representation can change equality or routing behavior.",
        "Text/byte normalization may gate a state transition or lookup.",
        ("encoded identifier or token",),
        ("lookup/routing divergence", "event-name divergence"),
    ),
    MutationFamily.RNG: (
        "Random-state consumption order can change otherwise identical action outcomes.",
        "Stochastic mechanics require stateful RNG hypotheses rather than independent-noise assumptions.",
        ("same observed state/action can produce multiple outcomes",),
        ("seed-stable distribution", "consumption-order divergence"),
    ),
    MutationFamily.SERIALIZATION: (
        "Restored state can differ when fields are missing, defaulted, or normalized.",
        "State persistence may introduce or remove latent counters/flags.",
        ("reset/restore/checkpoint boundary",),
        ("defaulted counter", "missing-field behavior"),
    ),
    MutationFamily.MUTATION_TIMING: (
        "The same updates can differ when applied before, during, or after an update phase.",
        "Temporal ordering of mutations is part of the transition mechanic.",
        ("multi-phase update", "interacting entities"),
        ("one-tick delay", "collision/order divergence"),
    ),
    MutationFamily.EXCEPTIONS_DEFAULTS: (
        "An invalid or missing condition may fail, default, or continue with fallback behavior.",
        "Failure handling can define a reachable alternative transition.",
        ("invalid/edge-case action or missing condition",),
        ("fallback transition", "no-op", "terminal/error state"),
    ),
    MutationFamily.LIBRARY_BEHAVIOR: (
        "Equivalent high-level operations may have version-sensitive observable semantics.",
        "A mechanic should be trusted only after direct behavioral observation, not library identity.",
        ("framework-mediated operation",),
        ("observable transition divergence",),
    ),
}


class RDLMechanicGeneralizer:
    @staticmethod
    def generalized_hypothesis(family: MutationFamily, delta: RDLDelta) -> str:
        description, invariant, _, _ = _TEMPLATES[family]
        effects: list[str] = []
        if delta.position_changed:
            effects.append("position")
        if delta.legal_actions_changed:
            effects.append("legal-actions")
        if abs(delta.score_delta) > 1e-12 or delta.level_delta:
            effects.append("reward/progress")
        if delta.terminal_changed:
            effects.append("terminal")
        if delta.object_changed:
            effects.append("object-topology")
        if delta.counters_changed:
            effects.append("counter")
        effect_text = ", ".join(effects) if effects else "state"
        return f"{invariant} Observed divergence dimensions: {effect_text}."

    def build_mechanic(
        self,
        *,
        environment_id: str,
        mutation: SemanticMutation,
        delta: RDLDelta,
        causal: CausalValidationResult,
        reachability: ReachabilityResult,
        adl_result: RuntimeADLResult,
        bridge: RuntimeBridge,
        generality: float,
        utility: float,
        provenance_hashes: Iterable[str],
        glyph_id: int | None = None,
    ) -> RDLMechanic:
        description, invariant, preconditions, predicted = _TEMPLATES[mutation.family]
        required: list[str] = ["state transition before/after candidate action"]
        if delta.position_changed:
            required.append("agent/object position")
        if delta.legal_actions_changed:
            required.append("legal action set")
        if delta.counters_changed:
            required.append("observable counter or repeated-transition evidence")
        if delta.rng_changed:
            required.append("repeat trials under controlled/observed stochastic state")
        test_actions = bridge.synthesized_probe or bridge.forward_path
        # Mechanic identity is deliberately environment-neutral so independent
        # public games can converge on the same transferable primitive. Game and
        # bridge provenance are stored separately and never define the mechanic.
        payload = {
            "family": mutation.family.value,
            "invariant": invariant,
            "preconditions": preconditions,
            "predicted": predicted,
        }
        mechanic_id = f"RDL-M-{stable_hash(payload)[:16]}"
        return RDLMechanic(
            mechanic_id=mechanic_id,
            mutation_family=mutation.family.value,
            description=description,
            invariant=invariant,
            required_observations=tuple(required),
            preconditions=preconditions,
            predicted_effects=predicted,
            test_actions=tuple(test_actions),
            causal_confidence=causal.causal_confidence,
            reproducibility=causal.reproducibility,
            reachability=1.0 if reachability.reachable else 0.0,
            generality=max(0.0, min(1.0, generality)),
            utility=max(0.0, min(1.0, utility)),
            source_games=(environment_id,),
            glyph_id=glyph_id,
            provenance_hashes=tuple(dict.fromkeys(str(v) for v in provenance_hashes)),
        )
