from __future__ import annotations

import ast
from pathlib import Path
from typing import Iterable

from .types import MutationFamily, RDLMode, ScannerReport, SourceFinding


def _name(node: ast.AST | None) -> str:
    if node is None:
        return ""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


def _negative_constant(node: ast.AST) -> bool:
    return isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub) and isinstance(node.operand, ast.Constant) and isinstance(node.operand.value, int)


class _SemanticVisitor(ast.NodeVisitor):
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path
        self.findings: list[SourceFinding] = []

    def add(self, node: ast.AST, family: MutationFamily, evidence: str, symbol: str = "") -> None:
        self.findings.append(
            SourceFinding(
                mutation_family=family,
                file_path=self.file_path,
                line=int(getattr(node, "lineno", 0) or 0),
                column=int(getattr(node, "col_offset", 0) or 0),
                evidence=evidence,
                symbol=symbol,
            )
        )

    def visit_BinOp(self, node: ast.BinOp) -> None:
        if isinstance(node.op, (ast.Div, ast.FloorDiv)):
            self.add(node, MutationFamily.DIVISION, type(node.op).__name__)
        if isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Pow, ast.LShift)):
            self.add(node, MutationFamily.OVERFLOW, f"overflow-sensitive arithmetic {type(node.op).__name__}")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        name = _name(node.func)
        leaf = name.rsplit(".", 1)[-1]
        if leaf in {"round", "floor", "ceil", "trunc"}:
            self.add(node, MutationFamily.ROUNDING, f"rounding call {name}", name)
        if leaf in {"map", "filter", "zip", "iter", "next"}:
            self.add(node, MutationFamily.ITERATOR_SEMANTICS, f"iterator call {name}", name)
        if leaf in {"sorted"}:
            self.add(node, MutationFamily.ORDERING, f"ordering call {name}", name)
        if leaf in {"copy", "deepcopy"} or name.endswith(".copy"):
            self.add(node, MutationFamily.COPY_SEMANTICS, f"copy call {name}", name)
        if leaf in {"int8", "uint8", "int16", "uint16", "int32", "uint32", "int64", "uint64"}:
            self.add(node, MutationFamily.NUMERIC_DTYPE, f"numeric dtype {name}", name)
        if leaf in {"bool", "int"}:
            self.add(node, MutationFamily.BOOL_INT_COERCION, f"coercion call {name}", name)
        if leaf in {"encode", "decode", "bytes", "str"}:
            self.add(node, MutationFamily.STRING_BYTES, f"string/bytes call {name}", name)
        if any(part in name.lower().split(".") for part in {"random", "randint", "randrange", "choice", "shuffle", "seed", "default_rng"}):
            self.add(node, MutationFamily.RNG, f"rng call {name}", name)
        if leaf in {"dumps", "loads", "dump", "load", "getstate", "setstate", "asdict"} or any(x in name.lower() for x in ("json.", "pickle.", "serialize", "deserialize")):
            self.add(node, MutationFamily.SERIALIZATION, f"serialization call {name}", name)
        if leaf in {"append", "extend", "insert", "pop", "remove", "clear", "update", "setdefault"}:
            self.add(node, MutationFamily.MUTATION_TIMING, f"mutation call {name}", name)
        if leaf in {"get", "getattr", "setdefault"}:
            self.add(node, MutationFamily.EXCEPTIONS_DEFAULTS, f"default/fallback call {name}", name)
        self.generic_visit(node)

    def visit_Subscript(self, node: ast.Subscript) -> None:
        if _negative_constant(node.slice):
            self.add(node, MutationFamily.NEGATIVE_INDEXING, "negative subscript")
        if isinstance(node.slice, ast.Slice):
            self.add(node, MutationFamily.SLICE_BOUNDARIES, "slice expression")
            if node.slice.lower is not None and _negative_constant(node.slice.lower):
                self.add(node, MutationFamily.NEGATIVE_INDEXING, "negative slice lower bound")
            if node.slice.upper is not None and _negative_constant(node.slice.upper):
                self.add(node, MutationFamily.NEGATIVE_INDEXING, "negative slice upper bound")
        self.generic_visit(node)

    def visit_For(self, node: ast.For) -> None:
        iterator_name = _name(node.iter)
        if iterator_name or isinstance(node.iter, (ast.Call, ast.Dict, ast.Set, ast.GeneratorExp)):
            self.add(node, MutationFamily.ORDERING, f"for-loop traversal {iterator_name or type(node.iter).__name__}", iterator_name)
            self.add(node, MutationFamily.ITERATOR_SEMANTICS, "for-loop iterator consumption", iterator_name)
        self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> None:
        values = [node.left, *node.comparators]
        if any(isinstance(v, ast.Constant) and isinstance(v.value, bool) for v in values) and any(
            isinstance(v, ast.Constant) and isinstance(v.value, int) and not isinstance(v.value, bool) for v in values
        ):
            self.add(node, MutationFamily.BOOL_INT_COERCION, "bool/int comparison")
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try) -> None:
        self.add(node, MutationFamily.EXCEPTIONS_DEFAULTS, "try/except fallback")
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            root = alias.name.split(".", 1)[0]
            if root not in {"__future__", "typing", "dataclasses", "collections", "math", "time", "copy", "json", "random", "hashlib", "pathlib", "enum"}:
                self.add(node, MutationFamily.LIBRARY_BEHAVIOR, f"library import {alias.name}", alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        root = module.split(".", 1)[0]
        if root and root not in {"__future__", "typing", "dataclasses", "collections", "math", "time", "copy", "json", "random", "hashlib", "pathlib", "enum"}:
            self.add(node, MutationFamily.LIBRARY_BEHAVIOR, f"library import {module}", module)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        annotation = _name(node.annotation)
        if any(token in annotation.lower() for token in ("int8", "uint8", "int16", "int32", "int64")):
            self.add(node, MutationFamily.NUMERIC_DTYPE, f"dtype annotation {annotation}", annotation)
        self.generic_visit(node)


class SemanticSourceScanner:
    """Static scanner for semantic-sensitivity sites in public Python environments.

    The scanner never rewrites code. It only emits hypotheses. Mutation execution
    is separately gated by a deep-public adapter and paired causal testing.
    """

    def __init__(self, *, mode: RDLMode = RDLMode.DEEP_PUBLIC) -> None:
        self.mode = mode

    def scan_file(self, path: str | Path) -> tuple[SourceFinding, ...]:
        if self.mode is not RDLMode.DEEP_PUBLIC:
            raise PermissionError("source scanning is permitted only in RDL_DEEP_PUBLIC mode")
        file_path = Path(path)
        text = file_path.read_text(encoding="utf-8")
        tree = ast.parse(text, filename=str(file_path))
        visitor = _SemanticVisitor(str(file_path))
        visitor.visit(tree)
        return tuple(visitor.findings)

    def scan_path(self, root: str | Path) -> ScannerReport:
        if self.mode is not RDLMode.DEEP_PUBLIC:
            raise PermissionError("source scanning is permitted only in RDL_DEEP_PUBLIC mode")
        root_path = Path(root)
        if not root_path.exists():
            raise FileNotFoundError(root_path)
        paths = [root_path] if root_path.is_file() else sorted(root_path.rglob("*.py"))
        findings: list[SourceFinding] = []
        errors: list[tuple[str, str]] = []
        scanned = 0
        for path in paths:
            if path.name.startswith("."):
                continue
            scanned += 1
            try:
                findings.extend(self.scan_file(path))
            except (SyntaxError, UnicodeDecodeError, OSError) as exc:
                errors.append((str(path), f"{type(exc).__name__}: {exc}"))
        findings.sort(key=lambda f: (f.file_path, f.line, f.column, f.mutation_family.value, f.evidence))
        return ScannerReport(tuple(findings), scanned, tuple(errors))
