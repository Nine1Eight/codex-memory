from __future__ import annotations

from collections import deque
from typing import Any, Callable

from .executor import RDLEnvironmentAdapter
from .types import RDLSnapshot, ReachabilityResult


class RDLReachabilityAnalyzer:
    def __init__(self, adapter: RDLEnvironmentAdapter) -> None:
        self.adapter = adapter

    def shortest_path(
        self,
        environment: Any,
        *,
        target: Callable[[RDLSnapshot], bool],
        max_depth: int = 8,
        max_nodes: int = 2048,
    ) -> ReachabilityResult:
        if max_depth < 0:
            raise ValueError("max_depth cannot be negative")
        if max_nodes < 1:
            raise ValueError("max_nodes must be >= 1")
        root_env = self.adapter.clone(environment)
        root = self.adapter.snapshot(root_env)
        if target(root):
            return ReachabilityResult(True, (), 1, 0, root.state_hash, "target already satisfied")

        queue = deque([(root_env, root, tuple())])
        visited = {root.state_hash}
        while queue and len(visited) < max_nodes:
            current_env, current, path = queue.popleft()
            if len(path) >= max_depth or current.terminal:
                continue
            try:
                actions = self.adapter.legal_actions(current_env)
            except Exception:
                continue
            for action in actions:
                child_env = self.adapter.clone(current_env)
                transition = self.adapter.execute(
                    child_env,
                    action,
                    runtime_profile="reachability",
                    mutation_id=None,
                )
                if transition.exception is not None:
                    continue
                child = transition.after
                child_path = (*path, action)
                if target(child):
                    return ReachabilityResult(
                        True,
                        child_path,
                        len(visited) + 1,
                        len(child_path),
                        child.state_hash,
                        "target reached by bounded forward search",
                    )
                if child.state_hash in visited:
                    continue
                visited.add(child.state_hash)
                if len(visited) >= max_nodes:
                    break
                queue.append((child_env, child, child_path))
        return ReachabilityResult(
            False,
            (),
            len(visited),
            None,
            None,
            "target not reached within configured depth/node budget",
        )
