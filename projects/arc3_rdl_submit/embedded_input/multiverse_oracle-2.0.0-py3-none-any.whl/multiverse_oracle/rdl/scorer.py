from __future__ import annotations

import math

from .types import (
    CausalValidationResult,
    RDLClassification,
    RDLDelta,
    RDLFindingScore,
    ReachabilityResult,
    RuntimeADLResult,
)


class RDLFindingScorer:
    @staticmethod
    def classify(
        delta: RDLDelta,
        causal: CausalValidationResult | None = None,
        *,
        transferable: bool = False,
        rejected: bool = False,
    ) -> RDLClassification:
        if rejected:
            return RDLClassification.REJECTED
        if delta.semantic_distance <= 0.0:
            return RDLClassification.NO_EFFECT
        if causal is not None and causal.causal:
            return RDLClassification.TRANSFERABLE_MECHANIC if transferable else RDLClassification.CAUSAL_MECHANIC
        if delta.terminal_changed:
            return RDLClassification.TERMINAL_EFFECT
        if abs(delta.score_delta) > 1e-12 or delta.level_delta != 0:
            return RDLClassification.REWARD_EFFECT
        if delta.legal_actions_changed:
            return RDLClassification.ACTION_EFFECT
        if delta.object_changed or delta.position_changed:
            return RDLClassification.PATH_EFFECT
        if delta.counters_changed:
            return RDLClassification.STATE_EFFECT
        if delta.state_changed:
            return RDLClassification.VISUAL_ONLY
        return RDLClassification.STATE_EFFECT

    @staticmethod
    def impact(delta: RDLDelta, adl_result: RuntimeADLResult | None = None) -> float:
        structural = max(
            delta.state_distance,
            delta.reward_distance,
            delta.action_distance,
            delta.terminal_distance,
            delta.object_distance,
            delta.counter_distance,
            delta.event_rng_distance,
        )
        if adl_result is None:
            return min(1.0, max(delta.semantic_distance, structural))
        positive_outcome = 1.0 - math.exp(-max(0.0, adl_result.outcome_effect))
        return min(1.0, max(delta.semantic_distance, structural, positive_outcome))

    @staticmethod
    def generality(causal: CausalValidationResult) -> float:
        # Causal evidence across neighboring states/actions earns transfer credit;
        # seed-only reproducibility still starts at a conservative 0.5.
        breadth = causal.adjacent_state_count + causal.alternate_action_count
        return min(1.0, 0.5 + 0.1 * breadth + 0.2 * causal.reproducibility)

    @staticmethod
    def utility(adl_result: RuntimeADLResult) -> float:
        strategic = max(0.0, min(1.0, adl_result.strategic_value))
        outcome = 1.0 - math.exp(-max(0.0, adl_result.outcome_effect))
        return min(1.0, 0.55 * strategic + 0.45 * outcome)

    def score(
        self,
        *,
        delta: RDLDelta,
        causal: CausalValidationResult,
        reachability: ReachabilityResult,
        adl_result: RuntimeADLResult,
        execution_cost: float,
    ) -> RDLFindingScore:
        impact = self.impact(delta, adl_result)
        causality = max(0.0, min(1.0, causal.causal_confidence))
        reproducibility = max(0.0, min(1.0, causal.reproducibility))
        reach = 1.0 if reachability.reachable else 0.0
        generality = self.generality(causal)
        utility = self.utility(adl_result)
        cost = max(0.0, min(1.0, execution_cost))
        score = impact * causality * reproducibility * reach * generality * utility * (1.0 - cost)
        classification = self.classify(
            delta,
            causal,
            transferable=causal.causal and generality >= 0.75,
        )
        return RDLFindingScore(
            score=max(0.0, min(1.0, score)),
            impact=impact,
            causality=causality,
            reproducibility=reproducibility,
            reachability=reach,
            generality=generality,
            utility=utility,
            cost=cost,
            classification=classification,
        )
