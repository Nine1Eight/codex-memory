from __future__ import annotations

from dataclasses import asdict, replace
import json
from pathlib import Path
import sqlite3
import threading
import time
from typing import Any, Iterable, Mapping

from .mechanic import MechanicBelief, MechanicCompiler
from .types import EncodedMechanic, RDLMechanic


def _json_default(value: Any) -> Any:
    if hasattr(value, "value"):
        return value.value
    if hasattr(value, "name"):
        return value.name
    return repr(value)


def _dumps(value: Any) -> str:
    return json.dumps(value, default=_json_default, sort_keys=True, separators=(",", ":"))


class RDLKnowledgeBase:
    """Durable SQLite mechanic/evidence store with Bayesian invalidation support."""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._memory_connection: sqlite3.Connection | None = None
        if self.path == ":memory:":
            self._memory_connection = sqlite3.connect(":memory:", check_same_thread=False)
            self._memory_connection.row_factory = sqlite3.Row
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        if self._memory_connection is not None:
            return self._memory_connection
        conn = sqlite3.connect(self.path, timeout=30.0)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _close_if_needed(self, conn: sqlite3.Connection) -> None:
        if conn is not self._memory_connection:
            conn.close()

    def _initialize(self) -> None:
        with self._lock:
            conn = self._connect()
            try:
                conn.executescript(
                    """
                    CREATE TABLE IF NOT EXISTS mechanics (
                        mechanic_id TEXT PRIMARY KEY,
                        mutation_family TEXT NOT NULL,
                        description TEXT NOT NULL,
                        invariant_text TEXT NOT NULL,
                        required_observations_json TEXT NOT NULL,
                        preconditions_json TEXT NOT NULL,
                        predicted_effects_json TEXT NOT NULL,
                        test_actions_json TEXT NOT NULL,
                        causal_confidence REAL NOT NULL,
                        reproducibility REAL NOT NULL,
                        reachability REAL NOT NULL,
                        generality REAL NOT NULL,
                        utility REAL NOT NULL,
                        source_games_json TEXT NOT NULL,
                        glyph_id INTEGER,
                        provenance_hashes_json TEXT NOT NULL,
                        invalidated INTEGER NOT NULL DEFAULT 0,
                        belief REAL NOT NULL,
                        confirmations INTEGER NOT NULL DEFAULT 0,
                        contradictions INTEGER NOT NULL DEFAULT 0,
                        observations INTEGER NOT NULL DEFAULT 0,
                        updated_ns INTEGER NOT NULL
                    );
                    CREATE TABLE IF NOT EXISTS evidence (
                        evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        mechanic_id TEXT NOT NULL,
                        environment_id TEXT NOT NULL,
                        provenance_hash TEXT NOT NULL,
                        evidence_json TEXT NOT NULL,
                        created_ns INTEGER NOT NULL,
                        FOREIGN KEY(mechanic_id) REFERENCES mechanics(mechanic_id)
                    );
                    CREATE INDEX IF NOT EXISTS idx_mechanics_family ON mechanics(mutation_family);
                    CREATE INDEX IF NOT EXISTS idx_mechanics_glyph ON mechanics(glyph_id);
                    CREATE INDEX IF NOT EXISTS idx_evidence_mechanic ON evidence(mechanic_id);
                    """
                )
                conn.commit()
            finally:
                self._close_if_needed(conn)

    def store(
        self,
        *,
        environment_id: str,
        mechanic: RDLMechanic,
        glyph: EncodedMechanic | None,
        evidence: Mapping[str, Any],
        provenance_hash: str,
    ) -> RDLMechanic:
        MechanicCompiler.validate(mechanic)
        if glyph is not None:
            mechanic = replace(mechanic, glyph_id=glyph.glyph_id)
        existing = self.get(mechanic.mechanic_id)
        if existing is not None:
            mechanic = replace(
                mechanic,
                source_games=tuple(sorted(set(existing.source_games) | set(mechanic.source_games))),
                provenance_hashes=tuple(sorted(set(existing.provenance_hashes) | set(mechanic.provenance_hashes))),
            )
        initial_belief = max(0.01, min(0.99, mechanic.causal_confidence * mechanic.reproducibility))
        now = time.time_ns()
        with self._lock:
            conn = self._connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute(
                    """
                    INSERT INTO mechanics (
                        mechanic_id, mutation_family, description, invariant_text,
                        required_observations_json, preconditions_json, predicted_effects_json,
                        test_actions_json, causal_confidence, reproducibility, reachability,
                        generality, utility, source_games_json, glyph_id, provenance_hashes_json,
                        invalidated, belief, confirmations, contradictions, observations, updated_ns
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?)
                    ON CONFLICT(mechanic_id) DO UPDATE SET
                        mutation_family=excluded.mutation_family,
                        description=excluded.description,
                        invariant_text=excluded.invariant_text,
                        required_observations_json=excluded.required_observations_json,
                        preconditions_json=excluded.preconditions_json,
                        predicted_effects_json=excluded.predicted_effects_json,
                        test_actions_json=excluded.test_actions_json,
                        causal_confidence=MAX(mechanics.causal_confidence, excluded.causal_confidence),
                        reproducibility=MAX(mechanics.reproducibility, excluded.reproducibility),
                        reachability=MAX(mechanics.reachability, excluded.reachability),
                        generality=MAX(mechanics.generality, excluded.generality),
                        utility=MAX(mechanics.utility, excluded.utility),
                        source_games_json=excluded.source_games_json,
                        glyph_id=COALESCE(excluded.glyph_id, mechanics.glyph_id),
                        provenance_hashes_json=excluded.provenance_hashes_json,
                        belief=MAX(mechanics.belief, excluded.belief),
                        updated_ns=excluded.updated_ns
                    """,
                    (
                        mechanic.mechanic_id,
                        mechanic.mutation_family,
                        mechanic.description,
                        mechanic.invariant,
                        _dumps(mechanic.required_observations),
                        _dumps(mechanic.preconditions),
                        _dumps(mechanic.predicted_effects),
                        _dumps(mechanic.test_actions),
                        mechanic.causal_confidence,
                        mechanic.reproducibility,
                        mechanic.reachability,
                        mechanic.generality,
                        mechanic.utility,
                        _dumps(mechanic.source_games),
                        mechanic.glyph_id,
                        _dumps(mechanic.provenance_hashes),
                        int(mechanic.invalidated),
                        initial_belief,
                        now,
                    ),
                )
                conn.execute(
                    """
                    INSERT INTO evidence(mechanic_id, environment_id, provenance_hash, evidence_json, created_ns)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (mechanic.mechanic_id, str(environment_id), str(provenance_hash), _dumps(evidence), now),
                )
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                self._close_if_needed(conn)
        return mechanic

    @staticmethod
    def _row_to_mechanic(row: sqlite3.Row) -> RDLMechanic:
        return RDLMechanic(
            mechanic_id=row["mechanic_id"],
            mutation_family=row["mutation_family"],
            description=row["description"],
            invariant=row["invariant_text"],
            required_observations=tuple(json.loads(row["required_observations_json"])),
            preconditions=tuple(json.loads(row["preconditions_json"])),
            predicted_effects=tuple(json.loads(row["predicted_effects_json"])),
            test_actions=tuple(json.loads(row["test_actions_json"])),
            causal_confidence=float(row["causal_confidence"]),
            reproducibility=float(row["reproducibility"]),
            reachability=float(row["reachability"]),
            generality=float(row["generality"]),
            utility=float(row["utility"]),
            source_games=tuple(json.loads(row["source_games_json"])),
            glyph_id=None if row["glyph_id"] is None else int(row["glyph_id"]),
            provenance_hashes=tuple(json.loads(row["provenance_hashes_json"])),
            invalidated=bool(row["invalidated"]),
        )

    def get(self, mechanic_id: str) -> RDLMechanic | None:
        with self._lock:
            conn = self._connect()
            try:
                row = conn.execute("SELECT * FROM mechanics WHERE mechanic_id=?", (mechanic_id,)).fetchone()
                return None if row is None else self._row_to_mechanic(row)
            finally:
                self._close_if_needed(conn)

    def query(
        self,
        *,
        mutation_family: str | None = None,
        min_belief: float = 0.0,
        include_invalidated: bool = False,
        limit: int = 100,
    ) -> tuple[RDLMechanic, ...]:
        clauses = ["belief >= ?"]
        args: list[Any] = [float(min_belief)]
        if mutation_family is not None:
            clauses.append("mutation_family = ?")
            args.append(str(mutation_family))
        if not include_invalidated:
            clauses.append("invalidated = 0")
        args.append(max(1, int(limit)))
        sql = f"SELECT * FROM mechanics WHERE {' AND '.join(clauses)} ORDER BY belief DESC, utility DESC, mechanic_id LIMIT ?"
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(sql, args).fetchall()
                return tuple(self._row_to_mechanic(row) for row in rows)
            finally:
                self._close_if_needed(conn)

    def belief(self, mechanic_id: str) -> MechanicBelief | None:
        with self._lock:
            conn = self._connect()
            try:
                row = conn.execute(
                    "SELECT mechanic_id, belief, confirmations, contradictions, observations, invalidated FROM mechanics WHERE mechanic_id=?",
                    (mechanic_id,),
                ).fetchone()
                if row is None:
                    return None
                return MechanicBelief(
                    mechanic_id=row["mechanic_id"],
                    probability=float(row["belief"]),
                    confirmations=int(row["confirmations"]),
                    contradictions=int(row["contradictions"]),
                    observations=int(row["observations"]),
                    invalidated=bool(row["invalidated"]),
                )
            finally:
                self._close_if_needed(conn)

    def record_observation(self, mechanic_id: str, *, confirmed: bool, reliability: float = 0.90) -> float:
        belief = self.belief(mechanic_id)
        if belief is None:
            raise KeyError(mechanic_id)
        posterior = belief.update(confirmed=confirmed, reliability=reliability)
        with self._lock:
            conn = self._connect()
            try:
                conn.execute(
                    """
                    UPDATE mechanics
                    SET belief=?, confirmations=?, contradictions=?, observations=?, updated_ns=?
                    WHERE mechanic_id=?
                    """,
                    (
                        posterior,
                        belief.confirmations,
                        belief.contradictions,
                        belief.observations,
                        time.time_ns(),
                        mechanic_id,
                    ),
                )
                conn.commit()
            finally:
                self._close_if_needed(conn)
        return posterior

    def invalidate(self, mechanic_id: str, *, reason: str = "contradictory evidence") -> None:
        with self._lock:
            conn = self._connect()
            try:
                cursor = conn.execute(
                    "UPDATE mechanics SET invalidated=1, belief=MIN(belief, 0.000001), updated_ns=? WHERE mechanic_id=?",
                    (time.time_ns(), mechanic_id),
                )
                if cursor.rowcount == 0:
                    raise KeyError(mechanic_id)
                conn.execute(
                    "INSERT INTO evidence(mechanic_id, environment_id, provenance_hash, evidence_json, created_ns) VALUES (?, ?, ?, ?, ?)",
                    (mechanic_id, "invalidation", "manual", _dumps({"reason": reason}), time.time_ns()),
                )
                conn.commit()
            finally:
                self._close_if_needed(conn)

    def evidence(self, mechanic_id: str) -> tuple[Mapping[str, Any], ...]:
        with self._lock:
            conn = self._connect()
            try:
                rows = conn.execute(
                    "SELECT environment_id, provenance_hash, evidence_json, created_ns FROM evidence WHERE mechanic_id=? ORDER BY evidence_id",
                    (mechanic_id,),
                ).fetchall()
                return tuple(
                    {
                        "environment_id": row["environment_id"],
                        "provenance_hash": row["provenance_hash"],
                        "evidence": json.loads(row["evidence_json"]),
                        "created_ns": int(row["created_ns"]),
                    }
                    for row in rows
                )
            finally:
                self._close_if_needed(conn)


    def export_compiled(self, destination: str | Path, *, min_belief: float = 0.20) -> "RDLKnowledgeBase":
        """Export a sanitized runtime bundle with generalized mechanics only.

        The destination contains no experiment evidence rows and no source-game
        identifiers. Provenance is retained only as non-reversible hashes.
        """
        dest = Path(destination)
        if dest.exists():
            dest.unlink()
        compiled = RDLKnowledgeBase(dest)
        for mechanic in self.query(min_belief=min_belief, include_invalidated=False, limit=100000):
            belief = self.belief(mechanic.mechanic_id)
            sanitized = replace(mechanic, source_games=("public-corpus",))
            # Insert directly so no evidence row is copied across the build boundary.
            now = time.time_ns()
            conn = compiled._connect()
            try:
                conn.execute(
                    """
                    INSERT INTO mechanics (
                        mechanic_id, mutation_family, description, invariant_text,
                        required_observations_json, preconditions_json, predicted_effects_json,
                        test_actions_json, causal_confidence, reproducibility, reachability,
                        generality, utility, source_games_json, glyph_id, provenance_hashes_json,
                        invalidated, belief, confirmations, contradictions, observations, updated_ns
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
                    """,
                    (
                        sanitized.mechanic_id, sanitized.mutation_family, sanitized.description, sanitized.invariant,
                        _dumps(sanitized.required_observations), _dumps(sanitized.preconditions), _dumps(sanitized.predicted_effects),
                        _dumps(sanitized.test_actions), sanitized.causal_confidence, sanitized.reproducibility, sanitized.reachability,
                        sanitized.generality, sanitized.utility, _dumps(sanitized.source_games), sanitized.glyph_id,
                        _dumps(sanitized.provenance_hashes),
                        belief.probability if belief is not None else sanitized.causal_confidence * sanitized.reproducibility,
                        belief.confirmations if belief is not None else 0,
                        belief.contradictions if belief is not None else 0,
                        belief.observations if belief is not None else 0,
                        now,
                    ),
                )
                conn.commit()
            finally:
                compiled._close_if_needed(conn)
        return compiled

    def close(self) -> None:
        with self._lock:
            if self._memory_connection is not None:
                self._memory_connection.close()
                self._memory_connection = None
