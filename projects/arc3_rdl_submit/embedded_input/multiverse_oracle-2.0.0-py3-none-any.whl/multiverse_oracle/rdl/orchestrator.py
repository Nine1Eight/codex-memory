from __future__ import annotations

from dataclasses import asdict, replace
import time
from typing import Any, Iterable, Mapping, Sequence

from ..adl.runtime_adapter import RuntimeADLAdapter
from ..ghostbridge.rdl_bridge import RuntimeGhostBridge
from ..glyphmatics.mechanic_encoder import MechanicEncoder
from .config import RDLConfig
from .delta import RDLDeltaExtractor
from .executor import (
    PairedDifferentialExecutor,
    PreconditionMismatchError,
    RDLEnvironmentAdapter,
    RDLExecutionError,
    UnsupportedMutationError,
)
from .generalizer import RDLMechanicGeneralizer
from .knowledge_base import RDLKnowledgeBase
from .mutation import MutationRegistry
from .reachability import RDLReachabilityAnalyzer
from .scorer import RDLFindingScorer
from .snapshot import stable_hash
from .types import (
    RDLClassification,
    RDLMode,
    RDLRunReport,
    RDLTransition,
    RuntimeDifferenceEvidence,
)
from .causal import RDLCausalValidator


class RDLOrchestrator:
    """Production ownership boundary for RDL -> ADL -> GhostBridge -> GlyphMatics."""

    def __init__(
        self,
        *,
        adapter: RDLEnvironmentAdapter,
        knowledge_base: RDLKnowledgeBase,
        config: RDLConfig | None = None,
        mutation_registry: MutationRegistry | None = None,
        adl: RuntimeADLAdapter | None = None,
        ghostbridge: RuntimeGhostBridge | None = None,
        glyph_encoder: MechanicEncoder | None = None,
    ) -> None:
        self.adapter = adapter
        self.knowledge_base = knowledge_base
        self.config = config or RDLConfig()
        self.mutation_registry = mutation_registry or MutationRegistry()
        self.adl = adl or RuntimeADLAdapter()
        self.ghostbridge = ghostbridge or RuntimeGhostBridge()
        self.glyph_encoder = glyph_encoder or MechanicEncoder()
        self.delta_extractor = RDLDeltaExtractor(self.config.weights)
        self.paired_executor = PairedDifferentialExecutor(
            adapter,
            require_same_precondition_hash=self.config.require_same_precondition_hash,
        )
        self.causal_validator = RDLCausalValidator(
            self.paired_executor,
            self.delta_extractor,
            self.config.causal,
        )
        self.reachability = RDLReachabilityAnalyzer(adapter)
        self.scorer = RDLFindingScorer()
        self.generalizer = RDLMechanicGeneralizer()

    def run_deep(
        self,
        *,
        environment: Any,
        environment_id: str,
        source_root: str | None = None,
        adjacent_environments: Sequence[Any] = (),
    ) -> RDLRunReport:
        if self.config.mode is not RDLMode.DEEP_PUBLIC:
            raise PermissionError("run_deep requires RDL_DEEP_PUBLIC mode")
        if source_root is not None and not self.config.allow_public_source_analysis:
            raise PermissionError(
                "source-root analysis is disabled unless allow_public_source_analysis=True is explicitly set for a verified public environment corpus"
            )
        start = time.perf_counter_ns()
        initial_snapshot = self.adapter.snapshot(environment)
        supported = self.adapter.supported_families(environment)
        if not supported:
            raise RDLExecutionError("environment exposes no controlled semantic intervention families")
        mutations = self.mutation_registry.discover(
            mode=self.config.mode,
            source_root=source_root,
            supported_families=supported,
            max_mutations=self.config.max_mutations,
        )
        accepted = []
        rejected: list[str] = []
        experiments = 0
        causal_findings = 0

        legal_actions = self.adapter.legal_actions(environment)
        for mutation in mutations:
            actions = legal_actions[: self.config.max_actions_per_mutation]
            for action in actions:
                experiments += 1
                try:
                    paired = self.paired_executor.run(
                        environment,
                        action=action,
                        mutation=mutation,
                        seed=self.config.causal.seeds[0],
                        initial_snapshot=initial_snapshot,
                    )
                except (UnsupportedMutationError, PreconditionMismatchError, RDLExecutionError) as exc:
                    rejected.append(f"{mutation.mutation_id}/{action}: {type(exc).__name__}: {exc}")
                    break

                delta = self.delta_extractor.compare(paired.baseline, paired.variant)
                if delta.semantic_distance <= self.config.causal.minimum_effect_distance:
                    continue
                if self.config.fail_on_variant_exception and paired.variant.exception is not None:
                    rejected.append(f"{mutation.mutation_id}/{action}: variant exception {paired.variant.exception}")
                    continue

                alternate_actions = tuple(a for a in legal_actions if a != action)[: self.config.causal.max_alternate_actions]
                try:
                    causal = self.causal_validator.validate(
                        environment=environment,
                        mutation=mutation,
                        action=action,
                        initial_snapshot=initial_snapshot,
                        adjacent_environments=adjacent_environments,
                        alternate_actions=alternate_actions,
                    )
                except (UnsupportedMutationError, PreconditionMismatchError, RDLExecutionError) as exc:
                    rejected.append(f"{mutation.mutation_id}/{action}: causal validation failed: {exc}")
                    continue
                if not causal.causal:
                    rejected.append(f"{mutation.mutation_id}/{action}: {causal.reason}")
                    continue
                causal_findings += 1

                adl_result = self.adl.evaluate_runtime_difference(
                    baseline_trace=paired.baseline,
                    variant_trace=paired.variant,
                    delta=delta,
                    causal_result=causal,
                )
                if not adl_result.winning:
                    rejected.append(f"{mutation.mutation_id}/{action}: ADL rejected: {adl_result.reason}")
                    continue

                # The experiment's exact precondition is by construction reachable
                # from the supplied environment state at cost zero. For callers
                # supplying later public checkpoints, this still records the real
                # path cost when a distinct root environment is used upstream.
                reach = self.reachability.shortest_path(
                    environment,
                    target=lambda snapshot, target_hash=initial_snapshot.state_hash: snapshot.state_hash == target_hash,
                    max_depth=self.config.reachability_max_depth,
                    max_nodes=self.config.reachability_max_nodes,
                )

                pair_hash = stable_hash(
                    {
                        "environment_id": environment_id,
                        "mutation_id": mutation.mutation_id,
                        "seed": paired.seed,
                        "action": repr(action),
                        "baseline_before": paired.baseline.before.state_hash,
                        "baseline_after": paired.baseline.after.state_hash,
                        "variant_before": paired.variant.before.state_hash,
                        "variant_after": paired.variant.after.state_hash,
                        "semantic_distance": delta.semantic_distance,
                    }
                )
                generalized_hypothesis = self.generalizer.generalized_hypothesis(mutation.family, delta)
                evidence = RuntimeDifferenceEvidence(
                    mutation_id=mutation.mutation_id,
                    mutation_family=mutation.family.value,
                    baseline=paired.baseline,
                    variant=paired.variant,
                    delta=delta,
                    causal_confidence=causal.causal_confidence,
                    reproducibility=causal.reproducibility,
                    reachable=reach.reachable,
                    minimum_reach_cost=reach.depth,
                    outcome_effect=adl_result.outcome_effect,
                    information_gain=adl_result.strategic_value,
                    generalized_hypothesis=generalized_hypothesis,
                    provenance_hash=pair_hash,
                )

                self.ghostbridge.observe_pair(
                    paired.baseline,
                    paired.variant,
                    mutation_family=mutation.family.value,
                )
                bridge = self.ghostbridge.construct_runtime_bridge(
                    environment_id=environment_id,
                    initial_state_hash=initial_snapshot.state_hash,
                    target_delta=delta,
                    mutation=mutation,
                    reachability=reach,
                    evidence_hashes=(pair_hash,),
                )

                execution_ns = paired.baseline.elapsed_ns + paired.variant.elapsed_ns
                # Wall-clock latency is a noisy proxy under shared notebook hosts.
                # Use a bounded asymptotic penalty so scheduler jitter cannot turn
                # an otherwise reproducible causal mechanic into a zero score.
                cost_ratio = execution_ns / self.config.execution_cost_reference_ns
                cost = min(0.50, cost_ratio / (1.0 + cost_ratio))
                score = self.scorer.score(
                    delta=delta,
                    causal=causal,
                    reachability=reach,
                    adl_result=adl_result,
                    execution_cost=cost,
                )
                if score.classification not in {
                    RDLClassification.CAUSAL_MECHANIC,
                    RDLClassification.TRANSFERABLE_MECHANIC,
                }:
                    rejected.append(f"{mutation.mutation_id}/{action}: non-durable class {score.classification.value}")
                    continue
                if score.score < self.config.acceptance_threshold:
                    rejected.append(
                        f"{mutation.mutation_id}/{action}: RDL score {score.score:.4f} < {self.config.acceptance_threshold:.4f}"
                    )
                    continue

                mechanic = self.generalizer.build_mechanic(
                    environment_id=environment_id,
                    mutation=mutation,
                    delta=delta,
                    causal=causal,
                    reachability=reach,
                    adl_result=adl_result,
                    bridge=bridge,
                    generality=score.generality,
                    utility=score.utility,
                    provenance_hashes=(pair_hash,),
                )
                glyph = self.glyph_encoder.encode_mechanic(mechanic)
                mechanic = replace(mechanic, glyph_id=glyph.glyph_id)
                self.knowledge_base.store(
                    environment_id=environment_id,
                    mechanic=mechanic,
                    glyph=glyph,
                    evidence={
                        "runtime_difference": asdict(evidence),
                        "causal": asdict(causal),
                        "adl": asdict(adl_result),
                        "bridge": asdict(bridge),
                        "score": asdict(score),
                        "glyph": asdict(glyph),
                    },
                    provenance_hash=pair_hash,
                )
                accepted.append(mechanic)

        dedup = {mechanic.mechanic_id: mechanic for mechanic in accepted}
        return RDLRunReport(
            environment_id=str(environment_id),
            mode=self.config.mode,
            mutations_considered=len(mutations),
            experiments_run=experiments,
            causal_findings=causal_findings,
            accepted_mechanics=tuple(sorted(dedup.values(), key=lambda m: m.mechanic_id)),
            rejected_reasons=tuple(rejected),
            elapsed_ns=time.perf_counter_ns() - start,
        )

    def observe_transition(self, transition: RDLTransition) -> float:
        """Observational-mode feedback. No source access or internal mutation occurs."""
        if self.config.mode not in {RDLMode.OBSERVATIONAL, RDLMode.COMPILED}:
            raise PermissionError("observe_transition is reserved for compiled/observational runtime use")
        discrepancy = self.ghostbridge.twin.discrepancy(transition)
        self.ghostbridge.graph.record(transition, mutation_family=None)
        self.ghostbridge.twin.record(transition)
        return discrepancy
