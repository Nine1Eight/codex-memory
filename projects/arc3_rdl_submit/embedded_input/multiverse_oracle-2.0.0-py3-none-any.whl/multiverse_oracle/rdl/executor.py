from __future__ import annotations

import copy
import random
import time
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

from .snapshot import SnapshotBuilder
from .types import MutationFamily, PairedExecution, RDLSnapshot, RDLTransition, SemanticMutation


class RDLExecutionError(RuntimeError):
    """Base exception for fail-closed RDL execution errors."""


class UnsupportedMutationError(RDLExecutionError):
    """Raised when a semantic intervention cannot be applied faithfully."""


class PreconditionMismatchError(RDLExecutionError):
    """Raised when paired runs do not share the exact observable precondition."""


def _enumish_name(value: Any) -> str:
    if hasattr(value, "name"):
        return str(value.name)
    return str(value)


@dataclass(slots=True)
class RDLEnvironmentAdapter:
    """Concrete, fail-closed adapter for clone/snapshot/execute semantic experiments.

    Every method has a working default for conventional Python stateful environments.
    Environment-specific callables can be supplied where the public runtime exposes
    a different API. Unsupported semantic intervention is an explicit error rather
    than an implicit no-op.
    """

    clone_fn: Callable[[Any], Any] | None = None
    snapshot_fn: Callable[[Any], RDLSnapshot | Mapping[str, Any]] | None = None
    restore_fn: Callable[[Any, RDLSnapshot], None] | None = None
    legal_actions_fn: Callable[[Any], Iterable[Any]] | None = None
    execute_fn: Callable[[Any, Any], Any] | None = None
    apply_mutation_fn: Callable[[Any, SemanticMutation], None] | None = None
    set_seed_fn: Callable[[Any, int], None] | None = None
    supported_families_fn: Callable[[Any], Iterable[MutationFamily]] | None = None

    def clone(self, environment: Any) -> Any:
        if self.clone_fn is not None:
            return self.clone_fn(environment)
        method = getattr(environment, "clone", None)
        if callable(method):
            return method()
        try:
            return copy.deepcopy(environment)
        except Exception as exc:
            raise RDLExecutionError(f"environment is not cloneable: {type(exc).__name__}: {exc}") from exc

    def snapshot(self, environment: Any) -> RDLSnapshot:
        if self.snapshot_fn is not None:
            raw = self.snapshot_fn(environment)
            return raw if isinstance(raw, RDLSnapshot) else SnapshotBuilder.from_mapping(raw)
        method = getattr(environment, "rdl_snapshot", None)
        if callable(method):
            raw = method()
            return raw if isinstance(raw, RDLSnapshot) else SnapshotBuilder.from_mapping(raw)

        grid = None
        for name in ("grid", "frame", "board", "state_grid"):
            if hasattr(environment, name):
                grid = getattr(environment, name)
                break
        if grid is None:
            observation = getattr(environment, "observation", None)
            if isinstance(observation, Mapping):
                grid = observation.get("grid", observation.get("frame", ()))
        if grid is None:
            grid = ()

        score = getattr(environment, "score", 0.0)
        level = getattr(environment, "level", getattr(environment, "levels_completed", 0))
        terminal = bool(
            getattr(environment, "terminal", False)
            or getattr(environment, "done", False)
            or getattr(environment, "won", False)
            or getattr(environment, "game_over", False)
        )
        legal = tuple(self.legal_actions(environment))
        position = getattr(environment, "player_position", getattr(environment, "position", None))
        objects = getattr(environment, "objects", ())
        counters = getattr(environment, "counters", {})
        events = getattr(environment, "events", ())
        metadata = getattr(environment, "metadata", {})
        rng_state = None
        for rng_name in ("rng", "random", "_rng"):
            rng = getattr(environment, rng_name, None)
            getstate = getattr(rng, "getstate", None)
            if callable(getstate):
                try:
                    rng_state = getstate()
                except Exception:
                    rng_state = None
                break
        return SnapshotBuilder.build(
            grid=grid,
            score=score,
            level=level,
            terminal=terminal,
            legal_actions=legal,
            player_position=position,
            objects=objects,
            counters=counters,
            events=events,
            rng_state=rng_state,
            metadata=metadata,
        )

    def restore(self, environment: Any, snapshot: RDLSnapshot) -> None:
        if self.restore_fn is not None:
            self.restore_fn(environment, snapshot)
            return
        method = getattr(environment, "rdl_restore", None)
        if callable(method):
            method(snapshot)
            return
        raise RDLExecutionError("environment does not expose restore semantics; clone from the exact source state instead")

    def legal_actions(self, environment: Any) -> tuple[Any, ...]:
        if self.legal_actions_fn is not None:
            return tuple(self.legal_actions_fn(environment))
        for name in ("legal_actions", "available_actions", "actions"):
            value = getattr(environment, name, None)
            if callable(value):
                return tuple(value())
            if value is not None:
                return tuple(value)
        raise RDLExecutionError("environment does not expose legal actions")

    def execute(self, environment: Any, action: Any, *, runtime_profile: str, mutation_id: str | None) -> RDLTransition:
        before = self.snapshot(environment)
        start = time.perf_counter_ns()
        exception: str | None = None
        try:
            if self.execute_fn is not None:
                self.execute_fn(environment, action)
            else:
                step = getattr(environment, "step", None)
                if not callable(step):
                    raise RDLExecutionError("environment does not expose step(action)")
                step(action)
        except Exception as exc:
            exception = f"{type(exc).__name__}: {exc}"
        elapsed = time.perf_counter_ns() - start
        try:
            after = self.snapshot(environment)
        except Exception:
            if exception is None:
                raise
            after = before
        return RDLTransition(
            before=before,
            action=action,
            after=after,
            runtime_profile=runtime_profile,
            mutation_id=mutation_id,
            elapsed_ns=elapsed,
            exception=exception,
        )

    def apply_mutation(self, environment: Any, mutation: SemanticMutation) -> None:
        if self.apply_mutation_fn is not None:
            self.apply_mutation_fn(environment, mutation)
            return
        method = getattr(environment, "apply_rdl_mutation", None)
        if callable(method):
            method(mutation)
            return
        raise UnsupportedMutationError(
            f"environment does not support controlled intervention {mutation.mutation_id}; refusing to treat it as applied"
        )

    def set_seed(self, environment: Any, seed: int) -> None:
        if self.set_seed_fn is not None:
            self.set_seed_fn(environment, int(seed))
            return
        method = getattr(environment, "set_seed", None)
        if callable(method):
            method(int(seed))
            return
        for rng_name in ("rng", "random", "_rng"):
            rng = getattr(environment, rng_name, None)
            seed_method = getattr(rng, "seed", None)
            if callable(seed_method):
                seed_method(int(seed))
                return
        # A deterministic environment without an RNG is valid. We only fail when
        # it advertises RNG state but no way to reset it.
        snap = self.snapshot(environment)
        if snap.rng_hash is not None:
            raise RDLExecutionError("environment has RNG state but exposes no deterministic seed/reset hook")

    def supported_families(self, environment: Any) -> tuple[MutationFamily, ...]:
        if self.supported_families_fn is not None:
            return tuple(self.supported_families_fn(environment))
        method = getattr(environment, "supported_rdl_mutations", None)
        if callable(method):
            raw = method()
            return tuple(value if isinstance(value, MutationFamily) else MutationFamily(str(value)) for value in raw)
        # If a generic mutation hook exists, it is responsible for rejecting
        # unsupported families. Advertising all families enables discovery while
        # still failing closed at application time.
        if self.apply_mutation_fn is not None or callable(getattr(environment, "apply_rdl_mutation", None)):
            return tuple(MutationFamily)
        return ()


class PairedDifferentialExecutor:
    def __init__(self, adapter: RDLEnvironmentAdapter, *, require_same_precondition_hash: bool = True) -> None:
        self.adapter = adapter
        self.require_same_precondition_hash = require_same_precondition_hash

    def _clone_at_precondition(self, environment: Any, initial_snapshot: RDLSnapshot | None) -> Any:
        clone = self.adapter.clone(environment)
        if initial_snapshot is None:
            return clone
        current = self.adapter.snapshot(clone)
        if current.state_hash == initial_snapshot.state_hash:
            return clone
        try:
            self.adapter.restore(clone, initial_snapshot)
        except RDLExecutionError as exc:
            raise PreconditionMismatchError(
                f"cloned environment precondition {current.state_hash[:12]} != requested {initial_snapshot.state_hash[:12]} and restore is unavailable"
            ) from exc
        restored = self.adapter.snapshot(clone)
        if restored.state_hash != initial_snapshot.state_hash:
            raise PreconditionMismatchError("restore did not reproduce the requested precondition exactly")
        return clone

    def run(
        self,
        environment: Any,
        *,
        action: Any,
        mutation: SemanticMutation,
        seed: int,
        initial_snapshot: RDLSnapshot | None = None,
    ) -> PairedExecution:
        baseline_env = self._clone_at_precondition(environment, initial_snapshot)
        variant_env = self._clone_at_precondition(environment, initial_snapshot)
        self.adapter.set_seed(baseline_env, seed)
        self.adapter.set_seed(variant_env, seed)

        baseline_pre = self.adapter.snapshot(baseline_env)
        variant_pre = self.adapter.snapshot(variant_env)
        if self.require_same_precondition_hash and baseline_pre.state_hash != variant_pre.state_hash:
            raise PreconditionMismatchError("baseline and variant differ before intervention")

        self.adapter.apply_mutation(variant_env, mutation)
        variant_after_mutation = self.adapter.snapshot(variant_env)
        if self.require_same_precondition_hash and baseline_pre.state_hash != variant_after_mutation.state_hash:
            raise PreconditionMismatchError("semantic intervention changed observable state before the paired action")

        baseline = self.adapter.execute(
            baseline_env,
            action,
            runtime_profile="baseline",
            mutation_id=None,
        )
        variant = self.adapter.execute(
            variant_env,
            action,
            runtime_profile=f"variant:{mutation.family.value}:{mutation.variant_name}",
            mutation_id=mutation.mutation_id,
        )
        return PairedExecution(baseline=baseline, variant=variant, seed=int(seed), mutation=mutation)

    def control_pair(
        self,
        environment: Any,
        *,
        action: Any,
        seed: int,
        initial_snapshot: RDLSnapshot | None = None,
    ) -> tuple[RDLTransition, RDLTransition]:
        left = self._clone_at_precondition(environment, initial_snapshot)
        right = self._clone_at_precondition(environment, initial_snapshot)
        self.adapter.set_seed(left, seed)
        self.adapter.set_seed(right, seed)
        if self.require_same_precondition_hash and self.adapter.snapshot(left).state_hash != self.adapter.snapshot(right).state_hash:
            raise PreconditionMismatchError("control pair differs before action")
        return (
            self.adapter.execute(left, action, runtime_profile="control:left", mutation_id=None),
            self.adapter.execute(right, action, runtime_profile="control:right", mutation_id=None),
        )
