from __future__ import annotations

from dataclasses import dataclass
import math

from .types import RDLMechanic


def _clamp_probability(value: float) -> float:
    return min(1.0 - 1e-9, max(1e-9, float(value)))


@dataclass(slots=True)
class MechanicBelief:
    mechanic_id: str
    probability: float
    confirmations: int = 0
    contradictions: int = 0
    observations: int = 0
    invalidated: bool = False

    def update(self, *, confirmed: bool, reliability: float = 0.90) -> float:
        if self.invalidated:
            return self.probability
        reliability = min(0.999999, max(0.500001, float(reliability)))
        prior = _clamp_probability(self.probability)
        odds = prior / (1.0 - prior)
        likelihood_ratio = reliability / (1.0 - reliability)
        odds = odds * likelihood_ratio if confirmed else odds / likelihood_ratio
        posterior = odds / (1.0 + odds)
        self.probability = _clamp_probability(posterior)
        self.observations += 1
        if confirmed:
            self.confirmations += 1
        else:
            self.contradictions += 1
        return self.probability

    def invalidate(self) -> None:
        self.invalidated = True
        self.probability = min(self.probability, 1e-6)

    @property
    def enabled(self) -> bool:
        return not self.invalidated and self.probability >= 0.55


class MechanicCompiler:
    """Final consistency gate before a mechanic can enter durable storage."""

    @staticmethod
    def validate(mechanic: RDLMechanic) -> None:
        if not mechanic.mechanic_id:
            raise ValueError("mechanic_id is required")
        if not mechanic.invariant.strip():
            raise ValueError("mechanic invariant is required")
        if mechanic.causal_confidence < 0.0 or mechanic.causal_confidence > 1.0:
            raise ValueError("causal_confidence must be in [0,1]")
        if mechanic.reproducibility < 0.0 or mechanic.reproducibility > 1.0:
            raise ValueError("reproducibility must be in [0,1]")
        if not mechanic.provenance_hashes:
            raise ValueError("persistent mechanics require provenance")
        if mechanic.invalidated:
            raise ValueError("invalidated mechanics cannot be compiled for durable use")
