from __future__ import annotations

import copy
import random
from typing import Any

from .types import MutationFamily, SemanticMutation


class SemanticValidationEnvironment:
    """Deterministic validation environment for the RDL transaction contract.

    It intentionally contains one useful boundary mechanic: baseline movement is
    bounded, while the RDL-03 ``wrap`` intervention makes a left move from the
    west edge arrive at the east-edge goal. Other semantic families are accepted
    as controlled profiles but are behaviorally inert, allowing no-effect
    rejection to be tested across the complete 16-family registry.
    """

    def __init__(self) -> None:
        self.grid = [[1, 0, 9]]
        self.position = (0, 0)
        self.score = 0.0
        self.level = 0
        self.terminal = False
        self.counters = {"moves": 0.0}
        self.events: list[str] = []
        self.metadata = {"environment": "semantic-validation"}
        self.rng = random.Random(918)
        self._profiles: dict[MutationFamily, str] = {}

    def clone(self) -> "SemanticValidationEnvironment":
        return copy.deepcopy(self)

    def set_seed(self, seed: int) -> None:
        self.rng.seed(int(seed))

    def legal_actions(self) -> tuple[str, ...]:
        return () if self.terminal else ("LEFT", "RIGHT", "WAIT")

    def supported_rdl_mutations(self) -> tuple[MutationFamily, ...]:
        return tuple(MutationFamily)

    def apply_rdl_mutation(self, mutation: SemanticMutation) -> None:
        self._profiles[mutation.family] = mutation.variant_name

    @property
    def player_position(self) -> tuple[int, int]:
        return self.position

    @property
    def objects(self) -> tuple[tuple[Any, ...], ...]:
        return (("agent", *self.position), ("goal", 0, 2))

    def step(self, action: str) -> None:
        if self.terminal:
            raise RuntimeError("cannot step terminal environment")
        if action not in self.legal_actions():
            raise ValueError(f"illegal action {action!r}")
        self.events = []
        self.counters["moves"] += 1.0
        row, col = self.position
        if action == "LEFT":
            proposed = col - 1
            mode = self._profiles.get(MutationFamily.NEGATIVE_INDEXING, "bounds")
            if proposed < 0:
                if mode == "wrap":
                    proposed %= len(self.grid[0])
                    self.events.append("boundary_wrap")
                elif mode == "clamp":
                    proposed = 0
                    self.events.append("boundary_clamp")
                else:
                    proposed = col
                    self.events.append("boundary_block")
            col = proposed
        elif action == "RIGHT":
            col = min(len(self.grid[0]) - 1, col + 1)
        elif action == "WAIT":
            self.events.append("wait")
        self.position = (row, col)
        self.grid = [[0, 0, 9]]
        self.grid[row][col] = 1
        if col == 2:
            self.score += 10.0
            self.level = 1
            self.terminal = True
            self.events.append("goal")
