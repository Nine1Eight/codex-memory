from __future__ import annotations

"""Receding-horizon observe-plan-act-learn-replan execution loop."""

import json
from typing import Any, Mapping

from .arcagi3_types import ARCActionPlan
from .arcagi3_policy import ARCAGI3Policy

class ARCPlanningLoop:
    """Actual observe-plan-act-learn-replan loop for ARC-AGI-3.

    The loop implements receding-horizon model-predictive control over the real
    EnvironmentWrapper contract:

      1. observe the latest real frame,
      2. ingest the previous action's real outcome exactly once,
      3. rebuild ADL/GhostBridge/causal beliefs,
      4. generate and collapse multiverse rollouts,
      5. rank legal actions and create an H-step provisional plan,
      6. execute only the first action,
      7. immediately ingest the returned frame, including terminal transitions,
      8. discard the simulated tail and replan from reality.

    ``game_action_factory`` must expose ``from_name(str)``. Real ``GameAction``
    does, and the test suite uses a faithful lightweight equivalent.
    """

    def __init__(self, policy: ARCAGI3Policy, game_action_factory: Any) -> None:
        self.policy = policy
        self.game_action_factory = game_action_factory

    def _action(self, plan: ARCActionPlan) -> Any:
        action = self.game_action_factory.from_name(plan.action_name)
        if hasattr(action, "set_data"):
            action.set_data(dict(plan.data))
        if hasattr(action, "reasoning"):
            action.reasoning = dict(plan.reasoning)
        return action

    def _execute(self, env: Any, plan: ARCActionPlan) -> Any:
        if plan.action_name == "RESET" and hasattr(env, "reset"):
            return env.reset()
        action = self._action(plan)
        return env.step(action, data=dict(plan.data), reasoning=dict(plan.reasoning))

    @staticmethod
    def _plan_report(plan: ARCActionPlan, actual_feedback: Mapping[str, Any] | None) -> dict[str, Any]:
        cycle = plan.planning_cycle
        return {
            "action_name": plan.action_name,
            "data": dict(plan.data),
            "candidate_id": plan.candidate_id,
            "oracle_score": plan.oracle_score,
            "expected_value": plan.expected_value,
            "phantom_risk": plan.phantom_risk,
            "replan_reason": cycle.replan_reason if cycle else None,
            "predicted_outcome_distribution": (
                dict(cycle.predicted_outcome_distribution) if cycle else {}
            ),
            "planned_sequence": (
                [
                    {
                        "depth": step.depth,
                        "candidate_id": step.candidate_id,
                        "action_name": step.action_name,
                        "data": dict(step.data),
                        "predicted_outcome": step.predicted_outcome,
                        "branch_support": step.branch_support,
                    }
                    for step in cycle.steps
                ]
                if cycle
                else []
            ),
            "actual_feedback": dict(actual_feedback) if actual_feedback else None,
        }

    def run(self, env: Any, *, max_actions: int = 400) -> dict[str, Any]:
        if max_actions < 1:
            raise ValueError("max_actions must be >= 1")
        self.policy.reset_episode(preserve_learning=True)
        frame = getattr(env, "observation_space", None)
        if frame is None:
            frame = env.reset()
        if frame is None:
            raise RuntimeError("ARC environment returned None from reset/observation_space")

        actions = 0
        replans = 0
        plan_reports: list[dict[str, Any]] = []
        while actions < max_actions:
            current = self.policy.frame_adapter.from_frame(
                frame, step=self.policy.step_index
            )
            if current.state_name == "WIN":
                break

            # Build a completely new plan from the latest real state. The policy
            # itself enforces legal-action and epistemic-boundary invariants.
            plan = self.policy.plan(frame, fallback_game_id=current.game_id)
            replans += 1

            next_frame = self._execute(env, plan)
            if next_frame is None:
                raise RuntimeError("ARC environment returned None from action")
            actions += 1

            # Crucial: commit the real result immediately. This records terminal
            # successes/failures and consumes pending_plan before any stop check.
            self.policy.ingest_result(next_frame, fallback_game_id=current.game_id)
            feedback = self.policy.feedback_history[-1] if self.policy.feedback_history else None
            plan_reports.append(self._plan_report(plan, feedback))
            frame = next_frame

            actual = self.policy.frame_adapter.from_frame(
                frame, step=self.policy.step_index, fallback_game_id=current.game_id
            )
            if actual.state_name == "WIN":
                break

        final = self.policy.frame_adapter.from_frame(
            frame, step=self.policy.step_index
        )
        return {
            "game_id": final.game_id,
            "actions": actions,
            "replans": replans,
            "state": final.state_name,
            "levels_completed": final.levels_completed,
            "win_levels": final.win_levels,
            "won": final.state_name == "WIN",
            "action_budget_exhausted": actions >= max_actions and final.state_name != "WIN",
            "policy": self.policy.summary(),
            "planning_loop": {
                "control": "receding_horizon_model_predictive_control",
                "horizon": self.policy.config.horizon,
                "branch_count": self.policy.config.branch_count,
                "actions_executed": actions,
                "replans": replans,
                "feedback_events": len(self.policy.feedback_history),
                "terminal_feedback_ingested": bool(
                    self.policy.feedback_history
                    and self.policy.feedback_history[-1].get("actual_outcome") in {"WIN", "GAME_OVER"}
                ),
            },
            "plans": plan_reports,
        }


class ARCEnvironmentRunner(ARCPlanningLoop):
    """Backward-compatible name for :class:`ARCPlanningLoop`."""


def write_report(path: str, report: Mapping[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, sort_keys=True)
        f.write("\n")
