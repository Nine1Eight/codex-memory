from __future__ import annotations

import math


def binary_entropy(probability: float) -> float:
    p = min(1.0 - 1e-12, max(1e-12, float(probability)))
    return -(p * math.log2(p) + (1.0 - p) * math.log2(1.0 - p))


def bayesian_posterior(prior: float, *, observation_supports: bool, reliability: float) -> float:
    p = min(1.0 - 1e-9, max(1e-9, float(prior)))
    r = min(1.0 - 1e-9, max(0.500000001, float(reliability)))
    odds = p / (1.0 - p)
    lr = r / (1.0 - r)
    odds = odds * lr if observation_supports else odds / lr
    return odds / (1.0 + odds)


def expected_binary_information_gain(prior: float, reliability: float) -> float:
    p = min(1.0 - 1e-9, max(1e-9, float(prior)))
    r = min(1.0 - 1e-9, max(0.500000001, float(reliability)))
    p_support = p * r + (1.0 - p) * (1.0 - r)
    post_support = bayesian_posterior(p, observation_supports=True, reliability=r)
    post_contra = bayesian_posterior(p, observation_supports=False, reliability=r)
    expected_after = p_support * binary_entropy(post_support) + (1.0 - p_support) * binary_entropy(post_contra)
    return max(0.0, binary_entropy(p) - expected_after)


def probe_value(
    *,
    information_gain: float,
    potential_reward: float,
    action_cost: float,
    failure_risk: float,
) -> float:
    denominator = max(1e-9, float(action_cost) + max(0.0, float(failure_risk)))
    return max(0.0, float(information_gain)) * max(0.0, float(potential_reward)) / denominator
