from __future__ import annotations

import json
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .causal import CausalTransitionGraph
from .gridworld import GridPursuitEnvironment, GridPursuitOracle, GridState
from .oracle import MultiverseOracleEngine, OracleConfig
from .persistence import SQLiteTelemetryStore
from .provenance import EpistemicBoundary, EpistemicLeakError
from .session import OracleSession
from .types import EpistemicSource, FeatureValue


@dataclass(frozen=True, slots=True)
class ValidationCheck:
    name: str
    passed: bool
    details: dict[str, Any]


def run_self_test() -> dict[str, Any]:
    checks: list[ValidationCheck] = []

    world = GridPursuitOracle()
    state = GridState(9, 7, (1, 3), (6, 3), frozenset({(4, 2), (4, 4)}))
    engine = MultiverseOracleEngine(
        world,
        world,
        config=OracleConfig(branch_count=256, horizon=8, seed=918),
    )
    prior = engine.step(state.snapshot(0))
    posterior = engine.step(state.snapshot(0), actual_observation={"target": (7, 3)})
    checks.append(
        ValidationCheck(
            "branch_generation_and_posterior",
            len(prior.branches) == 256
            and len(prior.collapse.surviving_branch_ids) > 1
            and posterior.collapse.entropy_bits < prior.collapse.entropy_bits,
            {
                "branches": len(prior.branches),
                "prior_entropy_bits": prior.collapse.entropy_bits,
                "posterior_entropy_bits": posterior.collapse.entropy_bits,
            },
        )
    )

    guard_passed = False
    try:
        EpistemicBoundary(strict=True).validate_action_features(
            {
                "future_door": FeatureValue(
                    True,
                    EpistemicSource.SIMULATED,
                    origin_branch_id="selftest",
                )
            }
        )
    except EpistemicLeakError:
        guard_passed = True
    checks.append(ValidationCheck("epistemic_boundary", guard_passed, {"blocked_simulated_fact": guard_passed}))

    graph = CausalTransitionGraph()
    graph.record_simulated("switch", "door_open", 10)
    graph.record_observed("switch", "door_open", False, 5)
    phantom = graph.phantom_edges(0.5)
    checks.append(
        ValidationCheck(
            "phantom_bridge_detection",
            bool(phantom),
            {"phantom_score": phantom[0].phantom_score if phantom else 0.0},
        )
    )

    corridor = GridState(9, 1, (0, 0), (6, 0))
    env = GridPursuitEnvironment(corridor, seed=2)
    episode_engine = MultiverseOracleEngine(
        world,
        world,
        config=OracleConfig(branch_count=128, horizon=8, seed=918),
    )
    with tempfile.TemporaryDirectory() as tmp:
        store = SQLiteTelemetryStore(Path(tmp) / "selftest.sqlite")
        session = OracleSession(episode_engine, run_id="selftest", store=store)
        captured = False
        trace: list[dict[str, Any]] = []
        for _ in range(20):
            actual = None if env.step_index == 0 else {"target": env.state.target}
            result = session.step(env.snapshot(), actual_observation=actual)
            outcome = env.step(result.decision.action)
            trace.append(
                {
                    "step": result.telemetry.step,
                    "action": result.decision.action.action_id,
                    "hunter": outcome.state.hunter,
                    "target": outcome.state.target,
                    "captured": outcome.captured,
                    "epistemic_leakage": result.telemetry.epistemic_leakage,
                }
            )
            if outcome.captured:
                captured = True
                break
        persisted_rows = len(store.load_run("selftest"))
        checks.append(
            ValidationCheck(
                "closed_loop_interception_and_persistence",
                captured
                and persisted_rows == len(trace)
                and session.summary().max_epistemic_leakage == 0.0,
                {
                    "captured": captured,
                    "steps": len(trace),
                    "persisted_rows": persisted_rows,
                    "max_epistemic_leakage": session.summary().max_epistemic_leakage,
                    "trace": trace,
                },
            )
        )

    return {
        "passed": all(c.passed for c in checks),
        "checks": [asdict(c) for c in checks],
    }


def main() -> int:
    report = run_self_test()
    print(json.dumps(report, indent=2, sort_keys=True, default=str))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
