from __future__ import annotations

"""ARC-AGI-3 public datatypes and policy configuration."""

from dataclasses import asdict, dataclass
from typing import Any, Mapping

Grid = tuple[tuple[int, ...], ...]

@dataclass(frozen=True, slots=True)
class DualStateKey:
    """Deterministic raw + invariant structural state identity.

    ``raw_hash`` changes with palette or orientation. ``canonical_hash`` is
    palette-invariant. ``structural_hash`` is palette + dihedral invariant.
    Python's randomized ``hash()`` is intentionally not used.
    """

    raw_hash: str
    canonical_hash: str
    structural_hash: str
    shape: tuple[int, int]
    color_count: int

    @property
    def compact(self) -> str:
        return f"{self.structural_hash[:16]}:{self.shape[0]}x{self.shape[1]}"


@dataclass(frozen=True, slots=True)
class ARCDifferenceHypothesis:
    source: DualStateKey
    target: DualStateKey
    changed_cells: int
    total_cells: int
    pixel_change_fraction: float
    palette_invariant_change: bool
    structural_change: bool
    color_count_delta: int
    changed_bbox: tuple[int, int, int, int] | None
    levels_delta: int
    win: bool
    game_over: bool
    outcome_class: str
    utility: float

    def as_mapping(self) -> dict[str, Any]:
        data = asdict(self)
        data["source"] = asdict(self.source)
        data["target"] = asdict(self.target)
        return data


@dataclass(frozen=True, slots=True)
class ARCObservation:
    game_id: str
    step: int
    frame_stack: tuple[Grid, ...]
    settled_grid: Grid
    state_name: str
    levels_completed: int
    win_levels: int
    available_action_names: tuple[str, ...]
    full_reset: bool
    key: DualStateKey
    motion_fraction: float


@dataclass(frozen=True, slots=True)
class ARCPlanStep:
    """One predicted step in the current receding-horizon plan."""

    depth: int
    candidate_id: str
    action_name: str
    data: Mapping[str, int]
    predicted_outcome: str
    branch_support: float


@dataclass(frozen=True, slots=True)
class ARCPlanAlternative:
    """Ranked executable first-action alternative for a planning cycle."""

    rank: int
    candidate_id: str
    action_name: str
    data: Mapping[str, int]
    robust_score: float
    expected_value: float
    variance: float
    worst_case: float
    phantom_risk: float


@dataclass(frozen=True, slots=True)
class ARCPlanCycle:
    """A concrete receding-horizon plan produced from one real observation.

    Only ``steps[0]`` is committed to the environment. Remaining steps are
    hypotheses and are discarded/rebuilt after the next real frame arrives.
    """

    cycle_id: int
    root_state_key: str
    replan_reason: str
    selected_candidate_id: str
    selected_score: float
    selected_expected_value: float
    predicted_outcome_distribution: Mapping[str, float]
    representative_path_support: float
    steps: tuple[ARCPlanStep, ...]
    alternatives: tuple[ARCPlanAlternative, ...]


@dataclass(frozen=True, slots=True)
class ARCActionPlan:
    action_name: str
    data: Mapping[str, int]
    candidate_id: str
    oracle_score: float
    expected_value: float
    phantom_risk: float
    stall_count: int
    reasoning: Mapping[str, Any]
    planning_cycle: ARCPlanCycle | None = None


@dataclass(slots=True)
class ARCPolicyConfig:
    branch_count: int = 96
    horizon: int = 5
    seed: int = 918
    soft_stall: int = 4
    hard_stall: int = 8
    max_click_candidates: int = 14
    phantom_fail_closed_threshold: float = 0.85
    action_cost: float = 0.35
    novelty_bonus: float = 0.9
    progress_reward: float = 12.0
    win_reward: float = 20.0
    game_over_penalty: float = 8.0
    no_change_penalty: float = 0.8
    visual_change_reward: float = 0.7
    risk_aversion: float = 0.18
    worst_case_weight: float = 0.08
    rollout_discount: float = 0.90
    simulation_evidence_scale: float = 4.0
    runtime_mechanics_enabled: bool = True
    runtime_probe_potential_reward: float = 1.0
    runtime_probe_action_cost: float = 1.0
    runtime_probe_failure_risk: float = 0.15

    def __post_init__(self) -> None:
        if self.branch_count < 8:
            raise ValueError("branch_count must be >= 8")
        if self.horizon < 1:
            raise ValueError("horizon must be >= 1")
        if not 1 <= self.max_click_candidates <= 64:
            raise ValueError("max_click_candidates must be in [1,64]")
        if self.soft_stall < 1 or self.hard_stall < self.soft_stall:
            raise ValueError("stall thresholds must satisfy 1 <= soft <= hard")
        if not 0.0 <= self.phantom_fail_closed_threshold <= 1.0:
            raise ValueError("phantom threshold must be in [0,1]")
        if not 0.0 < self.rollout_discount <= 1.0:
            raise ValueError("rollout_discount must be in (0,1]")
        if self.simulation_evidence_scale <= 0.0:
            raise ValueError("simulation_evidence_scale must be > 0")
        if self.runtime_probe_potential_reward < 0.0:
            raise ValueError("runtime_probe_potential_reward cannot be negative")
        if self.runtime_probe_action_cost <= 0.0:
            raise ValueError("runtime_probe_action_cost must be > 0")
        if not 0.0 <= self.runtime_probe_failure_risk <= 1.0:
            raise ValueError("runtime_probe_failure_risk must be in [0,1]")


@dataclass(slots=True)
class OutcomeStats:
    trials: int = 0
    progress: int = 0
    changed: int = 0
    no_change: int = 0
    failures: int = 0
    wins: int = 0
    total_utility: float = 0.0

    def record(self, outcome: str, utility: float) -> None:
        self.trials += 1
        self.total_utility += float(utility)
        if outcome in {"PROGRESS", "WIN"}:
            self.progress += 1
        if outcome in {"CHANGE", "PROGRESS", "WIN"}:
            self.changed += 1
        if outcome == "NO_CHANGE":
            self.no_change += 1
        if outcome == "GAME_OVER":
            self.failures += 1
        if outcome == "WIN":
            self.wins += 1

    @property
    def mean_utility(self) -> float:
        return self.total_utility / self.trials if self.trials else 0.0
