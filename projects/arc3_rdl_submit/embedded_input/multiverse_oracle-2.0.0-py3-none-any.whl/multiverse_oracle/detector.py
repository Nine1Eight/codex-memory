from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .drift import reality_drift
from .mathutils import js_divergence
from .types import ActionDecision, CollapseResult, OracleTelemetry


@dataclass(slots=True)
class AnomalyWeights:
    future_branch_influence: float = 0.15
    probability_ghosting: float = 0.20
    causal_inversion: float = 0.25
    reality_drift: float = 0.15
    epistemic_leakage: float = 0.25

    def normalized(self) -> dict[str, float]:
        raw = {
            "future_branch_influence": self.future_branch_influence,
            "probability_ghosting": self.probability_ghosting,
            "causal_inversion": self.causal_inversion,
            "reality_drift": self.reality_drift,
            "epistemic_leakage": self.epistemic_leakage,
        }
        if any(v < 0 for v in raw.values()) or sum(raw.values()) <= 0:
            raise ValueError("anomaly weights must be non-negative with a positive sum")
        total = sum(raw.values())
        return {k: v / total for k, v in raw.items()}


class MultiverseOracleAnomalyDetector:
    def __init__(self, weights: AnomalyWeights | None = None) -> None:
        self.weights = (weights or AnomalyWeights()).normalized()

    @staticmethod
    def _future_influence(decision: ActionDecision) -> float:
        vals = list(decision.branch_values.values())
        if not vals:
            return 0.0
        span = max(vals) - min(vals)
        scale = max(1.0, max(abs(v) for v in vals))
        return max(0.0, min(1.0, span / scale))

    def evaluate(
        self,
        *,
        step: int,
        decision: ActionDecision,
        collapse: CollapseResult,
        predicted_observation: Mapping[str, Any] | None,
        actual_observation: Mapping[str, Any] | None,
        causal_inversion_events: int = 0,
        action_condition_feature_count: int = 0,
        simulated_action_feature_count: int = 0,
        diagnostics: Mapping[str, Any] | None = None,
    ) -> OracleTelemetry:
        if causal_inversion_events < 0:
            raise ValueError("causal_inversion_events must be >= 0")
        if action_condition_feature_count < 0 or simulated_action_feature_count < 0:
            raise ValueError("feature counts must be >= 0")
        if simulated_action_feature_count > action_condition_feature_count:
            raise ValueError("simulated feature count cannot exceed total feature count")

        future = self._future_influence(decision)
        ghosting = js_divergence(decision.posterior_probabilities, decision.planner_weights)
        causal = min(1.0, causal_inversion_events / max(1, action_condition_feature_count))
        drift = reality_drift(predicted_observation or {}, actual_observation or {})
        leakage = (
            simulated_action_feature_count / action_condition_feature_count
            if action_condition_feature_count > 0
            else 0.0
        )
        components = {
            "future_branch_influence": future,
            "probability_ghosting": ghosting,
            "causal_inversion": causal,
            "reality_drift": drift,
            "epistemic_leakage": leakage,
        }
        score = sum(self.weights[k] * components[k] for k in self.weights)
        return OracleTelemetry(
            step=step,
            anomaly_score=max(0.0, min(1.0, score)),
            future_branch_influence=future,
            probability_ghosting=ghosting,
            causal_inversion=causal,
            reality_drift=drift,
            epistemic_leakage=leakage,
            posterior_entropy_bits=collapse.entropy_bits,
            effective_branch_count=collapse.effective_branch_count,
            selected_action_id=decision.action.action_id,
            collapsed_branch_id=collapse.collapsed_branch_id,
            diagnostics=dict(diagnostics or {}),
        )
