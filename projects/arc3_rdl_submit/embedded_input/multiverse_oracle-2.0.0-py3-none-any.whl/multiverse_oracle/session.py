from __future__ import annotations

from dataclasses import dataclass
from statistics import fmean
from typing import Any, Mapping, Protocol

from .oracle import MultiverseOracleEngine, OracleStepResult
from .persistence import SQLiteTelemetryStore
from .types import Branch, WorldSnapshot


class ForecastProvider(Protocol):
    def predict_next_observation(
        self,
        branches: tuple[Branch, ...] | list[Branch],
        probabilities: Mapping[str, float],
    ) -> Mapping[str, Any]:
        """Aggregate a concrete next-observation forecast from surviving branches."""
        raise TypeError("ForecastProvider is a structural protocol; use a concrete provider")


@dataclass(frozen=True, slots=True)
class SessionSummary:
    run_id: str
    steps: int
    mean_anomaly_score: float
    max_anomaly_score: float
    mean_reality_drift: float
    mean_probability_ghosting: float
    max_epistemic_leakage: float
    anomaly_steps: tuple[int, ...]


class OracleSession:
    """Stateful closed-loop coordinator for repeated observe → plan → verify cycles."""

    def __init__(
        self,
        engine: MultiverseOracleEngine,
        *,
        run_id: str,
        store: SQLiteTelemetryStore | None = None,
        anomaly_alert_threshold: float = 0.5,
    ) -> None:
        if not run_id:
            raise ValueError("run_id is required")
        if not 0 <= anomaly_alert_threshold <= 1:
            raise ValueError("anomaly_alert_threshold must be in [0,1]")
        self.engine = engine
        self.run_id = run_id
        self.store = store
        self.anomaly_alert_threshold = anomaly_alert_threshold
        self.previous_prediction: Mapping[str, Any] | None = None
        self.history: list[OracleStepResult] = []

    def step(
        self,
        snapshot: WorldSnapshot,
        *,
        actual_observation: Mapping[str, Any] | None = None,
        causal_inversion_events: int = 0,
    ) -> OracleStepResult:
        result = self.engine.step(
            snapshot,
            actual_observation=actual_observation,
            previous_prediction=self.previous_prediction,
            causal_inversion_events=causal_inversion_events,
        )
        predictor = getattr(self.engine.evaluator, "predict_next_observation", None)
        if callable(predictor):
            self.previous_prediction = dict(
                predictor(result.branches, result.collapse.probabilities)
            )
        else:
            self.previous_prediction = None
        self.history.append(result)
        if self.store is not None:
            self.store.record(self.run_id, result.decision, result.telemetry)
        return result

    def summary(self) -> SessionSummary:
        if not self.history:
            return SessionSummary(self.run_id, 0, 0.0, 0.0, 0.0, 0.0, 0.0, ())
        telemetry = [r.telemetry for r in self.history]
        return SessionSummary(
            run_id=self.run_id,
            steps=len(telemetry),
            mean_anomaly_score=fmean(t.anomaly_score for t in telemetry),
            max_anomaly_score=max(t.anomaly_score for t in telemetry),
            mean_reality_drift=fmean(t.reality_drift for t in telemetry),
            mean_probability_ghosting=fmean(t.probability_ghosting for t in telemetry),
            max_epistemic_leakage=max(t.epistemic_leakage for t in telemetry),
            anomaly_steps=tuple(
                t.step for t in telemetry if t.anomaly_score >= self.anomaly_alert_threshold
            ),
        )
