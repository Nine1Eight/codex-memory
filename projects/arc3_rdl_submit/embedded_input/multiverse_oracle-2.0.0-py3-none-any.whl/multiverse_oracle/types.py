from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from math import isfinite
from typing import Any, Mapping, Sequence


class EpistemicSource(str, Enum):
    OBSERVED = "observed"
    INFERRED = "inferred"
    SIMULATED = "simulated"


@dataclass(frozen=True, slots=True)
class FeatureValue:
    value: Any
    source: EpistemicSource
    confidence: float = 1.0
    origin_branch_id: str | None = None

    def __post_init__(self) -> None:
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be in [0, 1]")
        if self.source is EpistemicSource.SIMULATED and not self.origin_branch_id:
            raise ValueError("simulated values require origin_branch_id")
        if self.source is not EpistemicSource.SIMULATED and self.origin_branch_id is not None:
            raise ValueError("only simulated values may carry origin_branch_id")


@dataclass(frozen=True, slots=True)
class WorldSnapshot:
    step: int
    features: Mapping[str, FeatureValue]

    def observed_plain(self) -> dict[str, Any]:
        return {
            k: v.value
            for k, v in self.features.items()
            if v.source is EpistemicSource.OBSERVED
        }

    def safe_action_context(self, allow_inferred: bool = True) -> dict[str, Any]:
        allowed = {EpistemicSource.OBSERVED}
        if allow_inferred:
            allowed.add(EpistemicSource.INFERRED)
        return {k: v.value for k, v in self.features.items() if v.source in allowed}


@dataclass(frozen=True, slots=True)
class BranchObservation:
    step_offset: int
    features: Mapping[str, Any]

    def __post_init__(self) -> None:
        if self.step_offset < 1:
            raise ValueError("branch observations must be future observations")


@dataclass(frozen=True, slots=True)
class Branch:
    branch_id: str
    probability: float
    trajectory: Sequence[BranchObservation]
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.branch_id:
            raise ValueError("branch_id is required")
        if not isfinite(self.probability) or self.probability < 0:
            raise ValueError("branch probability must be finite and >= 0")


@dataclass(frozen=True, slots=True)
class ActionCandidate:
    action_id: str
    payload: Any

    def __post_init__(self) -> None:
        if not self.action_id:
            raise ValueError("action_id is required")


@dataclass(frozen=True, slots=True)
class CollapseResult:
    probabilities: Mapping[str, float]
    surviving_branch_ids: tuple[str, ...]
    entropy_bits: float
    effective_branch_count: float
    collapsed_branch_id: str | None


@dataclass(frozen=True, slots=True)
class ActionDecision:
    action: ActionCandidate
    score: float
    expected_value: float
    variance: float
    worst_case: float
    branch_values: Mapping[str, float]
    posterior_probabilities: Mapping[str, float]
    planner_weights: Mapping[str, float]
    reason: str


@dataclass(frozen=True, slots=True)
class OracleTelemetry:
    step: int
    anomaly_score: float
    future_branch_influence: float
    probability_ghosting: float
    causal_inversion: float
    reality_drift: float
    epistemic_leakage: float
    posterior_entropy_bits: float
    effective_branch_count: float
    selected_action_id: str
    collapsed_branch_id: str | None
    diagnostics: Mapping[str, Any] = field(default_factory=dict)
