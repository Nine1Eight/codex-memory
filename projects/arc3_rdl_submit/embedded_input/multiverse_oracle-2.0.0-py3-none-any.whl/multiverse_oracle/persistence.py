from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict
from pathlib import Path

from .types import ActionDecision, OracleTelemetry


class SQLiteTelemetryStore:
    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _initialize(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS oracle_steps (
                    run_id TEXT NOT NULL,
                    step INTEGER NOT NULL,
                    selected_action_id TEXT NOT NULL,
                    decision_score REAL NOT NULL,
                    expected_value REAL NOT NULL,
                    variance REAL NOT NULL,
                    anomaly_score REAL NOT NULL,
                    telemetry_json TEXT NOT NULL,
                    decision_json TEXT NOT NULL,
                    PRIMARY KEY (run_id, step)
                );
                CREATE INDEX IF NOT EXISTS idx_oracle_anomaly
                    ON oracle_steps(run_id, anomaly_score DESC);
                """
            )

    def record(self, run_id: str, decision: ActionDecision, telemetry: OracleTelemetry) -> None:
        if not run_id:
            raise ValueError("run_id is required")
        decision_json = json.dumps(asdict(decision), default=str, sort_keys=True)
        telemetry_json = json.dumps(asdict(telemetry), default=str, sort_keys=True)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO oracle_steps(
                    run_id, step, selected_action_id, decision_score, expected_value,
                    variance, anomaly_score, telemetry_json, decision_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(run_id, step) DO UPDATE SET
                    selected_action_id=excluded.selected_action_id,
                    decision_score=excluded.decision_score,
                    expected_value=excluded.expected_value,
                    variance=excluded.variance,
                    anomaly_score=excluded.anomaly_score,
                    telemetry_json=excluded.telemetry_json,
                    decision_json=excluded.decision_json
                """,
                (
                    run_id,
                    telemetry.step,
                    decision.action.action_id,
                    decision.score,
                    decision.expected_value,
                    decision.variance,
                    telemetry.anomaly_score,
                    telemetry_json,
                    decision_json,
                ),
            )

    def load_run(self, run_id: str) -> list[dict[str, object]]:
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM oracle_steps WHERE run_id=? ORDER BY step", (run_id,)
            ).fetchall()
        return [dict(row) for row in rows]
