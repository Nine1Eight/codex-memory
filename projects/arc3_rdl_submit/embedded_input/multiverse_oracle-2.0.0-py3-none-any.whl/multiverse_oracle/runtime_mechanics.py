from __future__ import annotations

from dataclasses import replace
from typing import Iterable, Mapping

from .glyphmatics.executor_registry import GlyphExecutorRegistry, MechanicExecutionContext
from .glyphmatics.mechanic_encoder import MechanicEncoder
from .information_gain import expected_binary_information_gain
from .rdl.knowledge_base import RDLKnowledgeBase
from .rdl.types import MechanicProbe, RDLMechanic
from .runtime_hypothesis import RuntimeMechanicHypothesis


class RuntimeMechanicOracle:
    """Observational-only mechanic retrieval and information-efficient probe control."""

    def __init__(
        self,
        knowledge_base: RDLKnowledgeBase,
        *,
        encoder: MechanicEncoder | None = None,
        executor_registry: GlyphExecutorRegistry | None = None,
        minimum_belief: float = 0.20,
    ) -> None:
        self.knowledge_base = knowledge_base
        self.encoder = encoder or MechanicEncoder()
        self.executor_registry = executor_registry or GlyphExecutorRegistry()
        self.minimum_belief = float(minimum_belief)

    @staticmethod
    def _relevance(mechanic: RDLMechanic, observation_terms: Iterable[str]) -> float:
        terms = {str(term).lower() for term in observation_terms if str(term).strip()}
        if not terms:
            return 0.5
        text = " ".join((mechanic.description, mechanic.invariant, *mechanic.preconditions, *mechanic.predicted_effects)).lower()
        hits = sum(1 for term in terms if term in text)
        return min(1.0, 0.35 + 0.15 * hits)

    def hypotheses(
        self,
        *,
        observation_terms: Iterable[str] = (),
        potential_reward: float = 1.0,
        failure_risk: float = 0.0,
        limit: int = 32,
    ) -> tuple[RuntimeMechanicHypothesis, ...]:
        mechanics = self.knowledge_base.query(min_belief=self.minimum_belief, limit=limit)
        hypotheses: list[RuntimeMechanicHypothesis] = []
        for mechanic in mechanics:
            belief = self.knowledge_base.belief(mechanic.mechanic_id)
            if belief is None or belief.invalidated:
                continue
            reliability = max(0.500001, mechanic.causal_confidence * mechanic.reproducibility)
            ig = expected_binary_information_gain(belief.probability, reliability)
            hypotheses.append(
                RuntimeMechanicHypothesis(
                    mechanic_id=mechanic.mechanic_id,
                    glyph_id=mechanic.glyph_id or self.encoder.encode_mechanic(mechanic).glyph_id,
                    belief=belief.probability,
                    information_gain=ig,
                    relevance=self._relevance(mechanic, observation_terms),
                    potential_reward=max(0.0, float(potential_reward)),
                    failure_risk=max(0.0, min(1.0, float(failure_risk))),
                )
            )
        hypotheses.sort(key=lambda h: (h.expected_probe_gain, h.belief, h.mechanic_id), reverse=True)
        return tuple(hypotheses)

    def recommend_probe(
        self,
        context: MechanicExecutionContext,
        *,
        observation_terms: Iterable[str] = (),
    ) -> MechanicProbe | None:
        hypotheses = self.hypotheses(
            observation_terms=observation_terms,
            potential_reward=context.potential_reward,
            failure_risk=context.failure_risk,
        )
        best: MechanicProbe | None = None
        for hypothesis in hypotheses:
            mechanic = self.knowledge_base.get(hypothesis.mechanic_id)
            if mechanic is None or mechanic.invalidated:
                continue
            encoded = self.encoder.encode_mechanic(mechanic)
            local_context = replace(context, information_gain=hypothesis.information_gain * hypothesis.relevance)
            probe = self.executor_registry.propose(encoded, mechanic, local_context)
            if probe is None:
                continue
            if probe.probe_value <= context.planner_value:
                continue
            if best is None or (probe.probe_value, probe.mechanic_id) > (best.probe_value, best.mechanic_id):
                best = probe
        return best

    def record_probe_result(self, mechanic_id: str, *, confirmed: bool, reliability: float = 0.90) -> float:
        return self.knowledge_base.record_observation(mechanic_id, confirmed=confirmed, reliability=reliability)
