from __future__ import annotations

import math
from typing import Callable

from ..rdl.types import CausalValidationResult, RDLDelta, RDLTransition, RuntimeADLResult


class RuntimeADLAdapter:
    """Outcome-aligned ADL validator for RDL paired runtime transitions."""

    def __init__(
        self,
        *,
        outcome_utility: Callable[[RDLTransition], float] | None = None,
        minimum_winning_effect: float = 1e-9,
    ) -> None:
        self.outcome_utility = outcome_utility or self._default_utility
        self.minimum_winning_effect = float(minimum_winning_effect)

    @staticmethod
    def _default_utility(transition: RDLTransition) -> float:
        before = transition.before
        after = transition.after
        score_gain = after.score - before.score
        level_gain = after.level - before.level
        progress = score_gain + 2.0 * level_gain
        # Terminal is not automatically positive: without an explicit WIN label,
        # terminating merely reduces future options. A positive score/level change
        # can still outweigh this penalty.
        if after.terminal and level_gain <= 0 and score_gain <= 0:
            progress -= 1.0
        if transition.exception is not None:
            progress -= 2.0
        return float(progress)

    def evaluate_runtime_difference(
        self,
        *,
        baseline_trace: RDLTransition,
        variant_trace: RDLTransition,
        delta: RDLDelta,
        causal_result: CausalValidationResult,
    ) -> RuntimeADLResult:
        baseline_utility = self.outcome_utility(baseline_trace)
        variant_utility = self.outcome_utility(variant_trace)
        outcome_effect = variant_utility - baseline_utility

        # Strategic value includes state/action information even when immediate
        # reward is unchanged, but it cannot make an outcome "winning" by itself.
        informative = max(
            delta.action_distance,
            delta.object_distance,
            delta.counter_distance,
            delta.state_distance,
            delta.event_rng_distance,
        )
        strategic_value = min(1.0, 0.6 * delta.semantic_distance + 0.4 * informative)
        winning = (
            causal_result.causal
            and outcome_effect > self.minimum_winning_effect
            and baseline_trace.exception is None
            and variant_trace.exception is None
        )
        if not causal_result.causal:
            reason = "runtime difference is not causally validated"
        elif baseline_trace.exception is not None or variant_trace.exception is not None:
            reason = "exception-bearing pair is retained as evidence but not promoted as a winning mechanic"
        elif outcome_effect <= self.minimum_winning_effect:
            reason = "causal runtime difference did not improve measured outcome"
        else:
            reason = "causal runtime difference improved measured outcome"
        return RuntimeADLResult(
            winning=winning,
            outcome_effect=outcome_effect,
            causal_confidence=causal_result.causal_confidence,
            strategic_value=strategic_value,
            reason=reason,
            metrics=(
                ("baseline_utility", baseline_utility),
                ("variant_utility", variant_utility),
                ("semantic_distance", delta.semantic_distance),
                ("information_value", strategic_value),
            ),
        )
