from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Mapping

from .mathutils import effective_count, entropy_bits, normalize
from .types import Branch, CollapseResult


@dataclass(slots=True)
class ProbabilityCollapseEngine:
    prune_threshold: float = 0.01
    hard_collapse_threshold: float = 0.97
    min_likelihood: float = 1e-9

    def __post_init__(self) -> None:
        if not 0 <= self.prune_threshold < 1:
            raise ValueError("prune_threshold must be in [0,1)")
        if not 0 < self.hard_collapse_threshold <= 1:
            raise ValueError("hard_collapse_threshold must be in (0,1]")
        if not 0 < self.min_likelihood <= 1:
            raise ValueError("min_likelihood must be in (0,1]")

    def posterior(
        self,
        branches: list[Branch],
        observation_likelihoods: Mapping[str, float] | None = None,
    ) -> CollapseResult:
        if not branches:
            raise ValueError("at least one branch is required")
        ids = [b.branch_id for b in branches]
        if len(ids) != len(set(ids)):
            raise ValueError("branch ids must be unique")

        priors = normalize({b.branch_id: b.probability for b in branches})
        if observation_likelihoods is None:
            likelihoods = {k: 1.0 for k in priors}
        else:
            unknown = set(observation_likelihoods) - set(priors)
            if unknown:
                raise ValueError(f"likelihoods include unknown branches: {sorted(unknown)}")
            likelihoods = {}
            for k in priors:
                value = float(observation_likelihoods.get(k, 1.0))
                if not isfinite(value) or value < 0 or value > 1:
                    raise ValueError("likelihoods must be finite and in [0,1]")
                likelihoods[k] = max(self.min_likelihood, value)

        unnormalized = {k: priors[k] * likelihoods[k] for k in priors}
        posterior = normalize(unnormalized)
        winner = max(posterior, key=posterior.get)
        max_probability = posterior[winner]
        # Relative pruning is stable for Monte-Carlo particle sets: 256 equally
        # plausible branches each have p≈0.0039 and must not all be discarded by
        # an absolute 0.01 threshold.
        relative_floor = max_probability * self.prune_threshold
        survivors = tuple(k for k, v in posterior.items() if v >= relative_floor)
        if not survivors:
            survivors = (winner,)

        collapsed = winner if posterior[winner] >= self.hard_collapse_threshold else None
        return CollapseResult(
            probabilities=posterior,
            surviving_branch_ids=survivors,
            entropy_bits=entropy_bits(posterior),
            effective_branch_count=effective_count(posterior),
            collapsed_branch_id=collapsed,
        )
