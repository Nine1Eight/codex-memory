from __future__ import annotations

"""Optional bridge into the official ARC-AGI-3-Agents repository.

The multiverse_oracle package itself remains installable without arc_agi.  When
used inside the official agents repo, ``OracleARCAGI3Agent`` subclasses the real
``agents.agent.Agent`` and returns real ``arcengine.GameAction`` objects.
"""

from typing import Any

from .arcagi3 import ARCAGI3Policy, ARCPolicyConfig

_IMPORT_ERROR: Exception | None = None
try:  # pragma: no cover - exercised when the official SDK is installed.
    from agents.agent import Agent as _Agent
    from arcengine import GameAction, GameState
except Exception as exc:  # keep core package importable outside ARC runtime
    _IMPORT_ERROR = exc
    _Agent = object  # type: ignore[assignment,misc]
    GameAction = None  # type: ignore[assignment]
    GameState = None  # type: ignore[assignment]


class OracleARCAGI3Agent(_Agent):  # type: ignore[misc,valid-type]
    """Drop-in ARC-AGI-3 Agents-repo agent backed by Multiverse Oracle."""

    MAX_ACTIONS = 400

    def __init__(self, *args: Any, oracle_config: ARCPolicyConfig | None = None, **kwargs: Any) -> None:
        if _IMPORT_ERROR is not None:
            raise RuntimeError(
                "OracleARCAGI3Agent requires the official ARC-AGI-3-Agents/arcengine runtime"
            ) from _IMPORT_ERROR
        super().__init__(*args, **kwargs)
        self.oracle_policy = ARCAGI3Policy(oracle_config)

    def is_done(self, frames: list[Any], latest_frame: Any) -> bool:
        if latest_frame is None:
            return False
        # The framework may stop immediately on WIN and never call choose_action
        # again. Ingest here so the terminal action/outcome is learned exactly once.
        self.oracle_policy.ingest_result(
            latest_frame, fallback_game_id=getattr(self, "game_id", "")
        )
        state = getattr(latest_frame, "state", None)
        state_name = getattr(state, "name", str(state)).upper()
        return state_name == "WIN"

    def choose_action(self, frames: list[Any], latest_frame: Any) -> Any:
        plan = self.oracle_policy.plan(latest_frame, fallback_game_id=getattr(self, "game_id", ""))
        action = GameAction.from_name(plan.action_name)
        # Official Agent.do_action_request serializes action.action_data and then
        # sends it to EnvironmentWrapper.step(). This is required for ACTION6.
        action.set_data(dict(plan.data))
        action.reasoning = dict(plan.reasoning)
        return action
