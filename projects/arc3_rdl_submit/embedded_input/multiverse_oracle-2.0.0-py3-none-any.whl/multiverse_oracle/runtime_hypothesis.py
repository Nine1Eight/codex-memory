from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RuntimeMechanicHypothesis:
    mechanic_id: str
    glyph_id: int
    belief: float
    information_gain: float
    relevance: float
    potential_reward: float
    failure_risk: float

    @property
    def expected_probe_gain(self) -> float:
        return self.information_gain * self.relevance * self.potential_reward * (1.0 - self.failure_risk)
