from __future__ import annotations

from dataclasses import dataclass
from math import isfinite, sqrt
from typing import Mapping

from .mathutils import normalize, weighted_stats
from .types import ActionCandidate, ActionDecision


@dataclass(slots=True)
class PlannerConfig:
    risk_aversion: float = 0.15
    worst_case_weight: float = 0.05
    weight_temperature: float = 1.0

    def __post_init__(self) -> None:
        if self.risk_aversion < 0:
            raise ValueError("risk_aversion must be >= 0")
        if not 0 <= self.worst_case_weight <= 1:
            raise ValueError("worst_case_weight must be in [0,1]")
        if self.weight_temperature <= 0:
            raise ValueError("weight_temperature must be > 0")


class CrossWorldPlanner:
    def __init__(self, config: PlannerConfig | None = None) -> None:
        self.config = config or PlannerConfig()

    def planner_weights(self, posterior: Mapping[str, float]) -> dict[str, float]:
        posterior = normalize(posterior)
        inv_temp = 1.0 / self.config.weight_temperature
        transformed = {k: p ** inv_temp for k, p in posterior.items()}
        return normalize(transformed)

    def rank(
        self,
        candidates: list[ActionCandidate],
        branch_action_values: Mapping[str, Mapping[str, float]],
        posterior: Mapping[str, float],
    ) -> list[ActionDecision]:
        """Return every candidate ranked by cross-world robust utility.

        Keeping the complete ranking is important for receding-horizon agents:
        the execution loop can inspect alternatives, detect strategy collapse,
        and deliberately switch to the next safe option after contradictory real
        feedback without fabricating another environment observation.
        """
        if not candidates:
            raise ValueError("at least one action candidate is required")
        posterior = normalize(posterior)
        weights = self.planner_weights(posterior)
        candidate_ids = {c.action_id for c in candidates}
        if len(candidate_ids) != len(candidates):
            raise ValueError("action candidate ids must be unique")
        if set(branch_action_values) != set(posterior):
            raise ValueError("branch_action_values must exactly match posterior branches")

        for branch_id, action_values in branch_action_values.items():
            missing = candidate_ids - set(action_values)
            if missing:
                raise ValueError(f"branch {branch_id} missing action values: {sorted(missing)}")

        ranked: list[ActionDecision] = []
        for candidate in candidates:
            values: dict[str, float] = {}
            for branch_id, action_values in branch_action_values.items():
                value = float(action_values[candidate.action_id])
                if not isfinite(value):
                    raise ValueError("action values must be finite")
                values[branch_id] = value

            mean, variance, worst = weighted_stats(values, weights)
            robust_mean = (1.0 - self.config.worst_case_weight) * mean + self.config.worst_case_weight * worst
            score = robust_mean - self.config.risk_aversion * sqrt(variance)
            ranked.append(
                ActionDecision(
                    action=candidate,
                    score=score,
                    expected_value=mean,
                    variance=variance,
                    worst_case=worst,
                    branch_values=values,
                    posterior_probabilities=dict(posterior),
                    planner_weights=weights,
                    reason=(
                        f"cross-world robust score={score:.6f}; expected={mean:.6f}; "
                        f"variance={variance:.6f}; worst={worst:.6f}"
                    ),
                )
            )

        ranked.sort(key=lambda d: (-d.score, d.action.action_id))
        return ranked

    def choose(
        self,
        candidates: list[ActionCandidate],
        branch_action_values: Mapping[str, Mapping[str, float]],
        posterior: Mapping[str, float],
    ) -> ActionDecision:
        return self.rank(candidates, branch_action_values, posterior)[0]
