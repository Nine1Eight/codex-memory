from __future__ import annotations

"""ARC-AGI-3 compatibility facade for the Multiverse Oracle subsystem.

Implementation is split into focused modules so the production source remains
auditable and connector-safe while preserving the original public API.
"""

from .arcagi3_types import (
    Grid, DualStateKey, ARCDifferenceHypothesis, ARCObservation, ARCPlanStep,
    ARCPlanAlternative, ARCPlanCycle, ARCActionPlan, ARCPolicyConfig, OutcomeStats,
)
from .arcagi3_state import ARCStateEncoder, ARCFrameAdapter, ARCOnlineDifferenceLearner
from .arcagi3_model import (
    ARCClickCandidateGenerator, ARCTransitionModel, ARCBranchGenerator, ARCBranchEvaluator,
)
from .arcagi3_policy import ARCAGI3Policy
from .arcagi3_loop import ARCPlanningLoop, ARCEnvironmentRunner, write_report

__all__ = [
    "Grid", "DualStateKey", "ARCDifferenceHypothesis", "ARCObservation",
    "ARCPlanStep", "ARCPlanAlternative", "ARCPlanCycle", "ARCActionPlan",
    "ARCPolicyConfig", "OutcomeStats", "ARCStateEncoder", "ARCFrameAdapter",
    "ARCOnlineDifferenceLearner", "ARCClickCandidateGenerator", "ARCTransitionModel",
    "ARCBranchGenerator", "ARCBranchEvaluator", "ARCAGI3Policy", "ARCPlanningLoop",
    "ARCEnvironmentRunner", "write_report",
]
