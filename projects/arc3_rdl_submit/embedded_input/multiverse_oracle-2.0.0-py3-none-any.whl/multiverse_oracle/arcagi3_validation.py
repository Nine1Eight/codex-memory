from __future__ import annotations

"""Executable dependency-free ARC integration validation.

This validates the complete ARC policy loop against EnvironmentWrapper-shaped
contract environments.  It does not claim an ARC competition score; real game
execution additionally requires the official SDK and environment files.
"""

from dataclasses import dataclass
import argparse
import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from .arcagi3 import ARCAGI3Policy, ARCEnvironmentRunner, ARCPolicyConfig


class _Action:
    def __init__(self, name: str) -> None:
        self.name = name
        self.data: dict[str, int] = {}

    def set_data(self, data: dict[str, int]) -> None:
        self.data = dict(data)


class _ActionFactory:
    @staticmethod
    def from_name(name: str) -> _Action:
        return _Action(name)


@dataclass
class _Frame:
    game_id: str
    frame: list[list[list[int]]]
    state: Any
    levels_completed: int
    win_levels: int
    available_actions: list[int]
    full_reset: bool = False


def _state(name: str) -> Any:
    return SimpleNamespace(name=name)


class _Corridor:
    def __init__(self) -> None:
        self.x = 0
        self.goal = 5
        self.s = "NOT_FINISHED"
        self.levels = 0
        self.observation_space = None

    def _grid(self) -> list[list[int]]:
        g = [[0] * 8 for _ in range(8)]
        g[4][self.goal] = 14
        g[4][self.x] = 9
        return g

    def _frame(self) -> _Frame:
        return _Frame("validation-corridor", [self._grid()], _state(self.s), self.levels, 1, [1, 2, 3, 4, 5] if self.s == "NOT_FINISHED" else [])

    def reset(self) -> _Frame:
        self.x, self.s, self.levels = 0, "NOT_FINISHED", 0
        self.observation_space = self._frame()
        return self.observation_space

    def step(self, action: _Action, data=None, reasoning=None) -> _Frame:
        if action.name == "ACTION4":
            self.x = min(self.goal, self.x + 1)
        elif action.name == "ACTION3":
            self.x = max(0, self.x - 1)
        if self.x == self.goal:
            self.s, self.levels = "WIN", 1
        self.observation_space = self._frame()
        return self.observation_space


class _Click:
    def __init__(self) -> None:
        self.target = (6, 2)
        self.s = "NOT_FINISHED"
        self.levels = 0
        self.observation_space = None

    def _grid(self) -> list[list[int]]:
        g = [[0] * 8 for _ in range(8)]
        g[self.target[1]][self.target[0]] = 14
        return g

    def _frame(self) -> _Frame:
        return _Frame("validation-click", [self._grid()], _state(self.s), self.levels, 1, [6] if self.s == "NOT_FINISHED" else [])

    def reset(self) -> _Frame:
        self.s, self.levels = "NOT_FINISHED", 0
        self.observation_space = self._frame()
        return self.observation_space

    def step(self, action: _Action, data=None, reasoning=None) -> _Frame:
        if action.name != "ACTION6":
            raise RuntimeError("illegal action in click validation")
        payload = dict(data or {})
        x, y = int(payload["x"]), int(payload["y"])
        if not 0 <= x <= 63 or not 0 <= y <= 63:
            raise RuntimeError("out-of-range ACTION6 coordinate")
        if (x, y) == self.target:
            self.s, self.levels = "WIN", 1
        self.observation_space = self._frame()
        return self.observation_space


def run_validation() -> dict[str, Any]:
    corridor_policy = ARCAGI3Policy(ARCPolicyConfig(branch_count=32, soft_stall=2, hard_stall=5))
    corridor = ARCEnvironmentRunner(corridor_policy, _ActionFactory).run(_Corridor(), max_actions=40)
    click_policy = ARCAGI3Policy(ARCPolicyConfig(branch_count=24, soft_stall=2, hard_stall=4, max_click_candidates=10))
    click = ARCEnvironmentRunner(click_policy, _ActionFactory).run(_Click(), max_actions=20)
    checks = {
        "corridor_win": corridor["won"],
        "click_win": click["won"],
        "corridor_zero_epistemic_leakage": corridor["policy"]["max_epistemic_leakage"] == 0.0,
        "click_zero_epistemic_leakage": click["policy"]["max_epistemic_leakage"] == 0.0,
        "corridor_replans_every_action": corridor["replans"] == corridor["actions"],
        "click_replans_every_action": click["replans"] == click["actions"],
        "corridor_feedback_every_action": corridor["planning_loop"]["feedback_events"] == corridor["actions"],
        "click_feedback_every_action": click["planning_loop"]["feedback_events"] == click["actions"],
        "corridor_terminal_feedback_ingested": corridor["planning_loop"]["terminal_feedback_ingested"],
        "click_terminal_feedback_ingested": click["planning_loop"]["terminal_feedback_ingested"],
        "corridor_terminal_outcome_learned": corridor["policy"]["last_difference"]["outcome_class"] == "WIN",
        "click_terminal_outcome_learned": click["policy"]["last_difference"]["outcome_class"] == "WIN",
        "plans_have_horizon_sequences": all(bool(p["planned_sequence"]) for p in corridor["plans"] + click["plans"]),
        "click_payloads_bounded": all(
            p["action_name"] != "ACTION6"
            or (0 <= p["data"]["x"] <= 63 and 0 <= p["data"]["y"] <= 63)
            for p in click["plans"]
        ),
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "corridor": corridor,
        "click": click,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="")
    args = parser.parse_args()
    report = run_validation()
    text = json.dumps(report, indent=2, sort_keys=True)
    print(text)
    if args.output:
        Path(args.output).write_text(text + "\n", encoding="utf-8")
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
