from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import tempfile

from .rdl.config import CausalValidationConfig, RDLConfig
from .rdl.executor import RDLEnvironmentAdapter
from .rdl.knowledge_base import RDLKnowledgeBase
from .rdl.orchestrator import RDLOrchestrator
from .rdl.reference_env import SemanticValidationEnvironment
from .rdl.types import RDLMode
from .glyphmatics.canon333 import CANON333


def run_validation() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="multiverse-rdl-") as tmp:
        db_path = Path(tmp) / "rdl.sqlite3"
        kb = RDLKnowledgeBase(db_path)
        config = RDLConfig(
            mode=RDLMode.DEEP_PUBLIC,
            acceptance_threshold=0.30,
            max_mutations=64,
            max_actions_per_mutation=3,
            causal=CausalValidationConfig(seeds=(918, 919, 920), causal_threshold=0.66, reproducibility_threshold=0.66),
        )
        orchestrator = RDLOrchestrator(
            adapter=RDLEnvironmentAdapter(),
            knowledge_base=kb,
            config=config,
        )
        env = SemanticValidationEnvironment()
        report = orchestrator.run_deep(environment=env, environment_id="semantic-validation")
        mechanics = kb.query(min_belief=0.0, include_invalidated=True)
        wrap = [m for m in mechanics if m.mutation_family == "RDL-03"]
        checks = {
            "canon_exactly_333": len(CANON333.definitions()) == 333,
            "all_16_families_available": len(env.supported_rdl_mutations()) == 16,
            "deep_run_executed": report.experiments_run > 0,
            "causal_finding_found": report.causal_findings > 0,
            "durable_mechanic_stored": bool(mechanics),
            "boundary_mechanic_found": bool(wrap),
            "glyph_compiled": bool(wrap and wrap[0].glyph_id is not None),
            "provenance_retained": bool(wrap and wrap[0].provenance_hashes),
        }
        if not all(checks.values()):
            raise RuntimeError(f"RDL validation failed: {checks}")
        return {
            "status": "PASS",
            "checks": checks,
            "report": {
                "mutations_considered": report.mutations_considered,
                "experiments_run": report.experiments_run,
                "causal_findings": report.causal_findings,
                "accepted_mechanics": [m.mechanic_id for m in report.accepted_mechanics],
            },
            "mechanics": [asdict(m) for m in mechanics],
        }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate MigrationBridge / Runtime Difference Learning")
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args(argv)
    result = run_validation()
    payload = json.dumps(result, indent=2, sort_keys=True, default=str)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
