from __future__ import annotations

"""ARC frame normalization, invariant state keys, and online difference learning."""

from collections import Counter, defaultdict
from hashlib import sha256
import json
from typing import Any, Sequence

from .arcagi3_types import (
    Grid, DualStateKey, ARCDifferenceHypothesis, ARCObservation, ARCPolicyConfig,
)

class ARCStateEncoder:
    @staticmethod
    def normalize_grid(grid: Any) -> Grid:
        if grid is None:
            return ()
        # numpy arrays and similar objects expose tolist().
        if hasattr(grid, "tolist"):
            grid = grid.tolist()
        rows: list[tuple[int, ...]] = []
        for row in grid:
            if hasattr(row, "tolist"):
                row = row.tolist()
            vals = tuple(int(v) for v in row)
            if vals and any(v < 0 or v > 15 for v in vals):
                raise ValueError("ARC grid values must be in [0,15]")
            rows.append(vals)
        if rows:
            width = len(rows[0])
            if width == 0 or any(len(r) != width for r in rows):
                raise ValueError("grid must be a non-empty rectangular matrix")
            if len(rows) > 64 or width > 64:
                raise ValueError("ARC grid dimensions must not exceed 64x64")
        return tuple(rows)

    @staticmethod
    def _serialize(grid: Grid) -> bytes:
        if not grid:
            return b"0x0:"
        h, w = len(grid), len(grid[0])
        body = bytes(v for row in grid for v in row)
        return f"{h}x{w}:".encode() + body

    @classmethod
    def palette_canonical_grid(cls, grid: Grid) -> Grid:
        if not grid:
            return ()
        positions: dict[int, list[tuple[int, int]]] = defaultdict(list)
        for y, row in enumerate(grid):
            for x, color in enumerate(row):
                positions[color].append((y, x))
        # Color labels never participate in ordering.  Count, first position and
        # complete spatial mask are palette-invariant tie breakers.
        ordering = sorted(
            positions,
            key=lambda c: (
                -len(positions[c]),
                positions[c][0],
                tuple(positions[c]),
            ),
        )
        mapping = {color: rank for rank, color in enumerate(ordering)}
        return tuple(tuple(mapping[v] for v in row) for row in grid)

    @staticmethod
    def _rot90(grid: Grid) -> Grid:
        if not grid:
            return ()
        return tuple(tuple(row) for row in zip(*grid[::-1]))

    @staticmethod
    def _reflect(grid: Grid) -> Grid:
        return tuple(tuple(reversed(row)) for row in grid)

    @classmethod
    def _dihedral(cls, grid: Grid) -> tuple[Grid, ...]:
        variants: list[Grid] = []
        cur = grid
        for _ in range(4):
            variants.append(cur)
            variants.append(cls._reflect(cur))
            cur = cls._rot90(cur)
        # Deduplicate symmetric grids while keeping deterministic order.
        unique: dict[bytes, Grid] = {}
        for variant in variants:
            unique.setdefault(cls._serialize(variant), variant)
        return tuple(unique[k] for k in sorted(unique))

    @classmethod
    def key(cls, grid: Grid) -> DualStateKey:
        raw = cls._serialize(grid)
        canonical = cls.palette_canonical_grid(grid)
        structural_serializations = [
            cls._serialize(cls.palette_canonical_grid(v)) for v in cls._dihedral(grid)
        ] or [b"0x0:"]
        shape = (len(grid), len(grid[0]) if grid else 0)
        colors = len({v for row in grid for v in row})
        return DualStateKey(
            raw_hash=sha256(raw).hexdigest(),
            canonical_hash=sha256(cls._serialize(canonical)).hexdigest(),
            structural_hash=sha256(min(structural_serializations)).hexdigest(),
            shape=shape,
            color_count=colors,
        )

    @classmethod
    def frame_stack(cls, raw_frame: Any) -> tuple[Grid, ...]:
        if raw_frame is None:
            return ()
        if hasattr(raw_frame, "tolist"):
            raw_frame = raw_frame.tolist()
        data = list(raw_frame)
        if not data:
            return ()
        # A raw 2-D grid can appear in custom wrappers; official FrameData uses
        # a stack. Detect 2-D by checking whether the first row contains scalars.
        first = data[0]
        if hasattr(first, "tolist"):
            first = first.tolist()
        if first and isinstance(first[0], (int, float)):
            return (cls.normalize_grid(data),)
        return tuple(cls.normalize_grid(frame) for frame in data)

    @staticmethod
    def motion_fraction(stack: Sequence[Grid]) -> float:
        if len(stack) < 2:
            return 0.0
        changed = 0
        total = 0
        for before, after in zip(stack, stack[1:]):
            if not before or not after or len(before) != len(after) or len(before[0]) != len(after[0]):
                changed += max(sum(map(len, before)), sum(map(len, after)))
                total += max(sum(map(len, before)), sum(map(len, after)))
                continue
            for r1, r2 in zip(before, after):
                for a, b in zip(r1, r2):
                    total += 1
                    changed += a != b
        return changed / total if total else 0.0


class ARCFrameAdapter:
    """Converts official FrameData/FrameDataRaw or equivalent objects."""

    def __init__(self, encoder: ARCStateEncoder | None = None) -> None:
        self.encoder = encoder or ARCStateEncoder()

    @staticmethod
    def _state_name(value: Any) -> str:
        if value is None:
            return "NOT_STARTED"
        name = getattr(value, "name", None)
        return str(name if name is not None else value).upper()

    @staticmethod
    def _action_name(value: Any) -> str:
        if isinstance(value, int):
            return "RESET" if value == 0 else f"ACTION{value}"
        name = getattr(value, "name", None)
        if name:
            return str(name).upper()
        text = str(value).upper()
        if text.isdigit():
            n = int(text)
            return "RESET" if n == 0 else f"ACTION{n}"
        if "." in text:
            text = text.rsplit(".", 1)[-1]
        return text

    def from_frame(self, frame: Any, *, step: int = 0, fallback_game_id: str = "") -> ARCObservation:
        if frame is None:
            empty = self.encoder.key(())
            return ARCObservation(
                game_id=fallback_game_id,
                step=step,
                frame_stack=(),
                settled_grid=(),
                state_name="NOT_STARTED",
                levels_completed=0,
                win_levels=0,
                available_action_names=("RESET",),
                full_reset=False,
                key=empty,
                motion_fraction=0.0,
            )
        stack = self.encoder.frame_stack(getattr(frame, "frame", None))
        settled = stack[-1] if stack else ()
        actions_raw = getattr(frame, "available_actions", ()) or ()
        names = tuple(dict.fromkeys(self._action_name(a) for a in actions_raw))
        state_name = self._state_name(getattr(frame, "state", None))
        if state_name in {"GAME_OVER", "NOT_STARTED", "NOT_PLAYED"}:
            names = ("RESET",)
        return ARCObservation(
            game_id=str(getattr(frame, "game_id", fallback_game_id) or fallback_game_id),
            step=step,
            frame_stack=stack,
            settled_grid=settled,
            state_name=state_name,
            levels_completed=int(getattr(frame, "levels_completed", 0) or 0),
            win_levels=int(getattr(frame, "win_levels", 0) or 0),
            available_action_names=names,
            full_reset=bool(getattr(frame, "full_reset", False)),
            key=self.encoder.key(settled),
            motion_fraction=self.encoder.motion_fraction(stack),
        )


class ARCOnlineDifferenceLearner:
    def __init__(self, config: ARCPolicyConfig) -> None:
        self.config = config

    @staticmethod
    def _changed_bbox(before: Grid, after: Grid) -> tuple[int, int, int, int] | None:
        if not before or not after or len(before) != len(after) or len(before[0]) != len(after[0]):
            return None
        pts = [
            (x, y)
            for y, (r1, r2) in enumerate(zip(before, after))
            for x, (a, b) in enumerate(zip(r1, r2))
            if a != b
        ]
        if not pts:
            return None
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        return min(xs), min(ys), max(xs), max(ys)

    def compare(self, before: ARCObservation, after: ARCObservation) -> ARCDifferenceHypothesis:
        b, a = before.settled_grid, after.settled_grid
        if b and a and len(b) == len(a) and len(b[0]) == len(a[0]):
            changed = sum(x != y for r1, r2 in zip(b, a) for x, y in zip(r1, r2))
            total = len(b) * len(b[0])
        else:
            total = max(sum(map(len, b)), sum(map(len, a)), 1)
            changed = total if b != a else 0
        frac = changed / total
        level_delta = after.levels_completed - before.levels_completed
        win = after.state_name == "WIN"
        game_over = after.state_name == "GAME_OVER"
        if win:
            outcome = "WIN"
        elif level_delta > 0:
            outcome = "PROGRESS"
        elif game_over:
            outcome = "GAME_OVER"
        elif changed > 0 or after.motion_fraction > 0:
            outcome = "CHANGE"
        else:
            outcome = "NO_CHANGE"
        utility = -self.config.action_cost
        utility += level_delta * self.config.progress_reward
        utility += self.config.win_reward if win else 0.0
        utility -= self.config.game_over_penalty if game_over else 0.0
        utility += min(1.0, frac + after.motion_fraction) * self.config.visual_change_reward
        utility -= self.config.no_change_penalty if outcome == "NO_CHANGE" else 0.0
        return ARCDifferenceHypothesis(
            source=before.key,
            target=after.key,
            changed_cells=changed,
            total_cells=total,
            pixel_change_fraction=frac,
            palette_invariant_change=before.key.canonical_hash != after.key.canonical_hash,
            structural_change=before.key.structural_hash != after.key.structural_hash,
            color_count_delta=after.key.color_count - before.key.color_count,
            changed_bbox=self._changed_bbox(b, a),
            levels_delta=level_delta,
            win=win,
            game_over=game_over,
            outcome_class=outcome,
            utility=utility,
        )
